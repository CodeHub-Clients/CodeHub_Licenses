Config = {}

Config.OpenKey             = 20
Config.Command             = 'playtime'
Config.ShowCountdown       = true
Config.CountdownUpdateInterval = 1000
Config.DiscordWebhook      = ''
Config.DailyMissionCount   = 3
Config.WeeklyMissionCount  = 3

Config.VehicleSettings = {
    garage = 'central',
    job    = 'civ',
    vtype  = 'car',
}

Config.Rewards = {
    {
        id = 1,
        label = '300 ألف شرعي',
        hours = 1,
        rewards = {
            { type = 'bank', value = 300000 },
        },
        icon = 'bank',
    },
    {
        id = 2,
        label = '300 ألف غير شرعي',
        hours = 15,
        rewards = {
            { type = 'black_money', value = 300000 },
        },
        icon = 'black',
    },
    {
        id = 3,
        label = '800 ألف + 2000 خبرة',
        hours = 30,
        rewards = {
            { type = 'bank', value = 800000 },
            { type = 'xp',   value = 2000   },
        },
        icon = 'bank',
    },
    {
        id = 4,
        label = 'ضعف الخبرة 3 ساعات',
        hours = 60,
        rewards = {
            { type = 'xp_buff', value = 180 },
        },
        icon = 'xp',
    },
    {
        id = 5,
        label = '1.5 مليون شرعي',
        hours = 90,
        rewards = {
            { type = 'bank', value = 1500000 },
        },
        icon = 'bank',
    },
    {
        id = 6,
        label = 'حمولة 250',
        hours = 120,
        rewards = {
            { label = 'حمولة 250', type = 'vehicle', value = 'benson', garage = 'central', job = 'civ', vtype = 'truck' },
        },
        icon = 'special',
    },
    {
        id = 7,
        label = 'راعي ذهبي 30 يوم',
        hours = 250,
        rewards = {
            { type = 'notify_admin', value = 'gold_vip_30' },
        },
        icon = 'vip',
    },
    {
        id = 8,
        label = '60,000 خبرة + مليون',
        hours = 400,
        rewards = {
            { type = 'xp',   value = 60000   },
            { type = 'bank', value = 1000000 },
        },
        icon = 'xp',
    },
    {
        id = 9,
        label = 'البوجاتي + فلوس',
        hours = 500,
        rewards = {
            { label = 'البوجاتي', type = 'vehicle', value = 'relax890', garage = 'central', job = 'civ', vtype = 'car' },
            { type = 'bank', value = 500000 },
        },
        icon = 'vehicle',
    },
    {
        id = 10,
        label = 'ورشة / بقالة / فود ترك',
        hours = 600,
        rewards = {
            { type = 'notify_admin', value = 'business_choice' },
        },
        icon = 'special',
    },
}

Config.StreakRewards = {
    [3]  = { rewards = { { type = 'bank', value = 50000 },  { type = 'xp', value = 1000 } }, label = '3 أيام متتالية' },
    [7]  = { rewards = { { type = 'bank', value = 150000 }, { type = 'xp', value = 3000 } }, label = 'أسبوع كامل' },
    [30] = { rewards = { { type = 'xp_buff', value = 180 }, { type = 'bank', value = 500000 } }, label = '30 يوم متواصل' },
}

Config.ChainBonus = {
    daily  = { rewards = { { type = 'bank', value = 75000 },  { type = 'xp', value = 2000 } }, label = '🔗 مكافأة السلسلة اليومية' },
    weekly = { rewards = { { type = 'bank', value = 300000 }, { type = 'xp', value = 8000 } }, label = '🔗 مكافأة السلسلة الأسبوعية' },
}

Config.Combos = {
    {
        id       = 'combo_trader',
        label    = 'التاجر المتكامل',
        missions = { 'daily_sell_legal', 'daily_sell_drugs' },
        rewards  = { { type = 'bank', value = 100000 }, { type = 'black_money', value = 50000 } },
        icon     = '💼',
    },
}

Config.Missions = {
    {
        id = 'daily_sell_legal',
        label = 'بيع بضاعة قانونية',
        description = 'قم ببيع أي بضاعة قانونية',
        category = 'daily',
        goal = 1000,
        icon = 'bank',
        first_bonus = { count = 30, rewards = { { type = 'bank', value = 1500000 } } },
        rewards = {
            { type = 'bank', value = 1000000 },
        },
    },
    {
        id = 'daily_sell_drugs',
        label = 'بيع مخدرات',
        description = 'بيع المخدرات في أي نقطة',
        category = 'daily',
        goal = 300,
        icon = 'black',
        time_limit_hours = 6,
        time_bonus = { { type = 'black_money', value = 800000 } },
        rewards = {
            { type = 'black_money', value = 500000 },
            { type = 'xp',         value = 5000    },
        },
    },
    {
        id = 'weekly_sell_legal',
        label = 'تاجر الأسبوع',
        description = 'بيع بضاعة قانونية بكميات كبيرة',
        category = 'weekly',
        goal = 10000,
        icon = 'bank',
        first_bonus = { count = 10, rewards = { { type = 'bank', value = 2500000 } } },
        rewards = {
            { type = 'bank', value = 2000000 },
            { type = 'xp',   value = 3000   },
        },
    },
    {
        id = 'weekly_sell_drugs',
        label = 'ملك الشوارع',
        description = 'تسيطر على سوق المخدرات هذا الأسبوع',
        category = 'weekly',
        goal = 1000,
        icon = 'black',
        rewards = {
            { type = 'black_money', value = 1000000 },
            { type = 'xp',         value = 7000   },
        },
    },
    {
        id = 'weekly_playtime',
        label = 'لاعب مخلص',
        description = 'العب 40 ساعات هذا الأسبوع',
        category = 'weekly',
        goal = 40,
        icon = 'xp',
        autotrack = 'playtime_hours',
        rewards = {
            { type = 'xp',   value = 5000   },
            { type = 'bank', value = 850000 },
        },
    },
}
