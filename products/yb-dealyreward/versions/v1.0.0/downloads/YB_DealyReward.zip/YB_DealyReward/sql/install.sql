CREATE TABLE IF NOT EXISTS `yb_playtime_rewards` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `identifier` VARCHAR(64) NOT NULL,
    `reward_id` INT(11) NOT NULL,
    `claimed_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `unique_claim` (`identifier`, `reward_id`),
    INDEX `idx_identifier` (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `yb_missions_progress` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `identifier` VARCHAR(64) NOT NULL,
    `mission_id` VARCHAR(64) NOT NULL,
    `progress` INT(11) NOT NULL DEFAULT 0,
    `reward_claimed` TINYINT(1) NOT NULL DEFAULT 0,
    `reset_date` DATE NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `unique_mission` (`identifier`, `mission_id`, `reset_date`),
    INDEX `idx_ident` (`identifier`),
    INDEX `idx_mission_date` (`mission_id`, `reset_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `yb_streaks` (
    `identifier` VARCHAR(64) NOT NULL,
    `streak_count` INT(11) NOT NULL DEFAULT 0,
    `last_claim_date` DATE DEFAULT NULL,
    PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `yb_chain_bonus` (
    `identifier` VARCHAR(64) NOT NULL,
    `category` VARCHAR(16) NOT NULL,
    `reset_date` DATE NOT NULL,
    `claimed` TINYINT(1) NOT NULL DEFAULT 0,
    PRIMARY KEY (`identifier`, `category`, `reset_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `yb_combo_claimed` (
    `identifier` VARCHAR(64) NOT NULL,
    `combo_id` VARCHAR(64) NOT NULL,
    `reset_date` DATE NOT NULL,
    PRIMARY KEY (`identifier`, `combo_id`, `reset_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `yb_playtime_offset` (
    `identifier` VARCHAR(64) NOT NULL,
    `offset_seconds` BIGINT NOT NULL DEFAULT 0,
    PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
