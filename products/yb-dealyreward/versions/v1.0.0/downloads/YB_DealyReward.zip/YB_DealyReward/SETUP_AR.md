# YB_DealyReward — التثبيت والربط

## المتطلبات

- FiveM (Lua 5.4)، **ESX Legacy** مع `getPlayTime()` وحقل `users.metadata` (لأمر تصفير الشامل).
- **oxmysql** على نفس قاعدة البيانات.
- `owned_vehicles` إذا استخدمت جوائز سيارات.
- اختياري: **YB_Level** (`xp`)، **esx_misc** (`xp_buff`)، **Discord webhook** (`notify_admin`) — إن لم تكن موجودة عطّل هذه الأنواع في `config.lua` أو عدّل `server/reward_delivery.lua`.

## التثبيت

1. انسخ المجلد إلى `resources/` ويفضّل الاسم **`YB_DealyReward`** (لأن الـ export يعتمد عليه).
2. في `server.cfg`:

```cfg
ensure oxmysql
ensure es_extended
ensure YB_DealyReward
```

3. الجداول تُنشأ تلقائياً عند أول تشغيل، أو نفّذ يدوياً: `sql/install.sql`.

## ملفات يعدّلها العميل (غير مشفّرة عادة)

| ملف | الغرض |
|-----|--------|
| `config.lua` | المفاتيح، الجوائز، المهمات، العدد اليومي/الأسبوعي |
| `server/reward_delivery.lua` | تسليم الفلوس، الخبرة، السيارات، الديسكورد حسب سيرفرك |

بعد التعديل: `ensure YB_DealyReward` أو إعادة تشغيل الريسورس.

## تصدير المهمات (من سكربتات أخرى)

للمهمات **بدون** `autotrack` زد التقدم من سكربت البيع/الوظيفة:

```lua
exports['YB_DealyReward']:addMissionProgress(source, missionId, amount)
```

| معامل | الوصف |
|--------|--------|
| `source` | رقم اللاعب في السيرفر |
| `missionId` | نفس `id` المهمة في `Config.Missions` |
| `amount` | كمية الزيادة (افتراضي 1) |

- **يرجع `true`** إذا المهمة موجودة وليست `autotrack`.
- **يرجع `false`** إذا اللاعب غير موجود، أو المهمة غير معرّفة، أو المهمة `autotrack` (مثل `playtime_hours`).

مثال:

```lua
exports['YB_DealyReward']:addMissionProgress(source, 'daily_sell_legal', 1)
exports['YB_DealyReward']:addMissionProgress(source, 'daily_sell_legal', 50)
```

المهمات اليومية مربوطة بتاريخ اليوم؛ الأسبوعية تبدأ أسبوع السيرفر من **الإثنين** (حسب منطق السكربت).

## أوامر السيرفر (كونسول فقط — `source == 0`)

| أمر | الصيغة | ماذا يفعل |
|-----|--------|-----------|
| **resetallplaytime** | `resetallplaytime` | يصفّر وقت اللعب الظاهر للجميع: يخزّن أوفست في `yb_playtime_offset` (للمتصلين من ESX، ولغير المتصلين من `metadata.lastPlaytime` إن وُجد)، ويمسح كل سجلات `yb_playtime_rewards` فيعاد سلم الجوائز من ناحية الاستلام. |
| **setplaytime** | `setplaytime [server id] [hours]` | يضبط وقتاً ظاهراً للاعب المتصل: يحسب أوفست بحيث يصبح `getPlayTime()` بعد الطرح ≈ الساعات المطلوبة، ويحدّث `yb_playtime_offset`. يُستعمل للاختبار أو التصحيح اليدوي. |

لا تعمل من شات اللاعب؛ مُعلَمة الأمر `true` (صلاحية).

## أحداث مفيدة (مرجع)

- سيرفر: `YB_DealyReward:claimReward`, `YB_DealyReward:claimMission`
- كلاينت: `YB_DealyReward:refreshData`, `YB_DealyReward:refreshMissions`, `YB_DealyReward:notify`

يفضّل الربط عبر الـ **export** لزيادة التقدم بدلاً من استدعاء الأحداث مباشرة.

## استكشاف سريع

- القائمة لا تفتح: تحقق من تحميل ESX و F8.
- المهمة لا تتحرك: `missionId` صحيح؟ المهمة `autotrack`؟ اسم الريسورس `YB_DealyReward`؟
- سيارة لا تُعطى: طابق `owned_vehicles` مع `server/reward_delivery.lua`.

---

## للبائع (تشفير)

شفّر عادة: `server/main.lua`, `client/main.lua`. **لا** تشفّر: `config.lua`, `server/reward_delivery.lua`, `fxmanifest.lua`, `nui/`, `SETUP_AR.md`, `sql/`.
