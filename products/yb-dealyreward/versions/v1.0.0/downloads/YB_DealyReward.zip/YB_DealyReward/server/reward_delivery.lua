YB_DealyRewardBridge = YB_DealyRewardBridge or {}

local function generatePlate()
    local letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    local plate = ''
    for i = 1, 3 do
        local idx = math.random(1, #letters)
        plate = plate .. letters:sub(idx, idx)
    end
    return plate .. ' ' .. string.format('%03d', math.random(0, 999))
end

function YB_DealyRewardBridge.GiveVehicleToPlayer(identifier, model, label, r)
    if not model or model == '' then return nil, nil end
    local plate = generatePlate()
    local vehicleData = json.encode({ model = joaat(model), plate = plate })
    local def = Config.VehicleSettings
    local garage = (r and r.garage) or def.garage
    local job = (r and r.job) or def.job
    local vtype = (r and r.vtype) or def.vtype
    local name = label or model
    MySQL.insert([[
        INSERT INTO owned_vehicles
        (owner, plate, vehicle, type, job, stored, name, priceold, levelold, category, modelname, trunkkg, higherprice, lowerprice, storedhouse, damages, garage, mileage)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ]], { identifier, plate, vehicleData, vtype, job, 1, name, '0', '0', '1', model, 0, 0, 0, nil, nil, garage, 0 })
    return name, plate
end

function YB_DealyRewardBridge.GiveSingleReward(xPlayer, r, reasonLabel)
    local identifier = xPlayer.getIdentifier()
    local src = xPlayer.source

    if r.type == 'bank' then
        xPlayer.addAccountMoney('bank', r.value, reasonLabel)
        return ('💵 %s$'):format(r.value)
    elseif r.type == 'money' then
        xPlayer.addMoney(r.value, reasonLabel)
        return ('💰 %s$'):format(r.value)
    elseif r.type == 'black_money' then
        xPlayer.addAccountMoney('black_money', r.value, reasonLabel)
        return ('💸 %s$'):format(r.value)
    elseif r.type == 'xp' then
        TriggerEvent('YB_Level:updateCurrentPlayerXP', src, 'addnoduble', r.value or 0, reasonLabel)
        return ('⭐ %s خبرة'):format(r.value or 0)
    elseif r.type == 'xp_buff' then
        exports['esx_misc']:givePlayerDoubleXP(identifier, r.value)
        return ('⭐ ضعف خبرة %d دقيقة'):format(r.value or 60)
    elseif r.type == 'vehicle' then
        local model = tostring(r.value)
        local label = tostring(r.label)
        local vname, vplate = YB_DealyRewardBridge.GiveVehicleToPlayer(identifier, model, label, r)
        if vname and vplate then
            return ('🚗 %s (لوحة: %s) كراج: %s'):format(vname, vplate, r.garage or Config.VehicleSettings.garage)
        end
        return nil
    elseif r.type == 'notify_admin' then
        if Config.DiscordWebhook and Config.DiscordWebhook ~= '' then
            local embed = {{
                title = '🎁 طلب جائزة',
                description = ('**اللاعب:** %s\n**الطلب:** %s\n**المعرف:** %s'):format(
                    xPlayer.getName(), tostring(r.value), identifier),
                color = 16766720,
                footer = { text = 'YB_DealyReward' },
            }}
            PerformHttpRequest(Config.DiscordWebhook, function() end, 'POST',
                json.encode({ username = 'YB Rewards', embeds = embed }),
                { ['Content-Type'] = 'application/json' })
        end
        return '📩 طلب أدمن مُسجّل'
    end
    return nil
end

function YB_DealyRewardBridge.GiveRewards(xPlayer, rewardsArr, reasonLabel)
    if not rewardsArr or #rewardsArr == 0 then return false, {}, 'لا توجد جوائز' end
    local parts = {}
    local anySuccess = false
    for _, reward in ipairs(rewardsArr) do
        local result = YB_DealyRewardBridge.GiveSingleReward(xPlayer, reward, reasonLabel)
        if result then
            anySuccess = true
            parts[#parts + 1] = result
        end
    end
    if anySuccess then
        return true, parts, 'تم استلام الجوائز'
    end
    return false, {}, 'حدث خطأ في تسليم الجوائز'
end
