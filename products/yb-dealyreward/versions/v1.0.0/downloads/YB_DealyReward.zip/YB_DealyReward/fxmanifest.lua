fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'YBv10'
description 'نظام مكافآت وقت اللعب - Playtime Rewards System'
version '1.0.0'

shared_scripts {
    '@es_extended/imports.lua',
    'config.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/reward_delivery.lua',
    'server/main.lua',
}

client_scripts {
    'client/main.lua',
}

ui_page 'nui/index.html'

files {
    'nui/index.html',
    'nui/assets/app.js',
    'nui/assets/index.css',
}

escrow_ignore {
    'config.lua',
    'server/reward_delivery.lua',
}

dependencies {
    'es_extended',
    'oxmysql',
}
