INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES
('drone', 'طائرة درون', 1000, 0, 1),
('drone_lspd', 'طائرة درون حكومية', 1000, 0, 1);
