fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'Eslam Ashref'
description 'Advanced Drone - Made by CodeHub - Discord: https://discord.gg/5cc'
version '1.0.0'

shared_script "config.lua"

client_scripts {
	'client/functions.lua',
	'client/client.lua',
}

server_scripts {
	-- ملاحظة: فعّل السطر الخاص بمكتبة قاعدة البيانات المستخدمة فقط
	-- '@mysql-async/lib/MySQL.lua',  -- فعّل إذا تستخدم mysql-async
	'@oxmysql/lib/MySQL.lua',         -- فعّل إذا تستخدم oxmysql (الافتراضي)
	'server/server.lua',
}

ui_page 'html/index.html'

files {
	'html/index.html',
	'html/css/**',
	'html/js/**',
	'html/sounds/*',
}

escrow_ignore {
	"config.lua"
}