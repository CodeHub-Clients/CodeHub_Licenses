Config = {}

-- ─────────────────────────────────────────────────────────────
--  إطار العمل (Framework)
--  قم بتحديد الإطار المستخدم على سيرفرك
-- ─────────────────────────────────────────────────────────────
Config.Framework = "esx" -- حدد الإطار: "qbcore" أو "esx" أو "" للوضع المستقل (Standalone) مع أمر /drone 1 أو 2
Config.QBCoreName = "qb-core" -- اسم سكربت QBCore (يجب أن يكون صحيحاً تماماً - يُستخدم فقط مع QBCore)
Config.QBCoreGetCoreObjectFunctionName = "GetCoreObject" -- اسم دالة الحصول على QBCore (يجب أن يكون صحيحاً تماماً)

Config.IsESXLegacy = true -- اجعلها true إذا كنت تستخدم ESX Legacy (يُستخدم فقط مع ESX)
Config.ESXLegacyName = "es_extended" -- اسم سكربت ESX Legacy (يجب أن يكون صحيحاً تماماً)
Config.ESXGetSharedObject = "esx:getSharedObject" -- اسم حدث الحصول على ESX للإصدارات القديمة (يجب أن يكون صحيحاً تماماً)
Config.ESXGetSharedObjectFunctionName = "getSharedObject" -- اسم دالة الحصول على ESX للإصدارات الجديدة (يجب أن يكون صحيحاً تماماً)
Config.SQL = "oxmysql" -- نوع قاعدة البيانات: "oxmysql" أو "mysql-async" (حسب ما تستخدمه مع ESX)

-- ─────────────────────────────────────────────────────────────
--  أزرار التحكم بالطائرة المسيّرة
--  مرجع أكواد الأزرار: https://docs.fivem.net/docs/game-references/controls/
-- ─────────────────────────────────────────────────────────────
Config.Controls = {
	Forward			= 35,	-- W   - للأمام
	Backward		= 34,	-- S   - للخلف
	Left			= 33,	-- A   - يساراً
	Right			= 32,	-- D   - يميناً
	Up				= 51,	-- E   - للأعلى
	Down			= 52,	-- Q   - للأسفل (Q في لوحة QWERTY / A في لوحة AZERTY)
	Stop			= 22,	-- Space - توقف
	ZoomOut			= 16,	-- عجلة الماوس للأسفل - تقليل التكبير
	ZoomIn			= 17,	-- عجلة الماوس للأعلى - زيادة التكبير
	Nightvision		= 140,	-- R   - الرؤية الليلية
	Heatvision		= 75,	-- F   - رؤية الحرارة
	Spotlight		= 47,	-- G   - المصباح الضوئي
	ReleaseDrone	= 168,	-- F7  - تحرير الطائرة / إعادة الاتصال
	Scanner			= 24,	-- زر الفأرة الأيسر - مسح اللاعبين
	SoundBoard		= 29,	-- B   - فتح لوحة الأصوات
	Cancel			= 200,	-- ESC - إلغاء وإيقاف الطائرة
}

Config.SyncDroneSound = true -- مزامنة صوت الطائرة مع اللاعبين الآخرين (قد يؤثر قليلاً على الأداء)
Config.DroneInitAnimations = true -- تفعيل رسوم الإقلاع عند بدء تشغيل الطائرة

Config.ScannerRange = 50.0     -- مدى الماسح الضوئي بالمتر
Config.ScannerIgnoreMask = false  -- تجاهل الأقنعة عند المسح (true = يمسح حتى مع القناع)
Config.NoMaskComponentId = 0   -- معرّف مكوّن الوجه بدون قناع

-- معلومات تظهر تلقائياً عندما يمرّ خط البصر (منتصف الشاشة) على لاعب أو مركبة
Config.ReticleIntel = true
Config.ReticleIntelRange = 90.0
Config.ReticleIntelRefreshMs = 220

Config.TextFont = 4 -- نوع الخط المستخدم في النصوص
Config.TextCustomFont = { -- هذا الخيار للسيرفرات التي تستخدم خطوطاً مخصصة أو لغات أخرى
	UseCustomFont = true, -- اجعلها true لتفعيل الخط المخصص
	FontName = 'A9eelsh', -- اسم ملف الخط المخصص
}

Config.DroneSettings = {
	["droneForCiv"] = { -- الدرون للاعبين
		enabled = true, -- تفعيل الدرون
		speed = 2, -- سرعة تحرك الدرون
		range = 350, -- اقصى مسافة للدرون
		health = 100, -- صحة الدرون
		sphere = true, -- دائرة حمراء تظهر عند اقصى مسافة
		explode = true, -- انفجار الدرون عند الموت
		heatvision = true, -- رؤية حرارية
		nightvision = false, -- رؤية ليلية
		spotlight = true, -- مصباح ضوئي (زر G أثناء التحكم)
		sound = false, -- صوت الدرون
		scanner = false, -- ماسح اللاعبين
		release = false, -- تحرير الدرون
		soundboard = false, -- لوحة الأصوات
		dronModel = "ch_prop_casino_drone_02a", -- الموديل الاساسي للدرون لو عايز تغيره
	},

	["droneForLspd"] = { -- الدرون للشرطة
		enabled = true, -- تفعيل الدرون
		speed = 2, -- سرعة تحرك الدرون
		range = 350, -- اقصى مسافة للدرون
		health = 100, -- صحة الدرون
		sphere = true, -- دائرة حمراء تظهر عند اقصى مسافة
		explode = true, -- انفجار الدرون عند الموت
		heatvision = true, -- رؤية حرارية
		nightvision = true, -- رؤية ليلية
		spotlight = true, -- مصباح ضوئي
		sound = true, -- صوت الدرون
		scanner = true, -- ماسح اللاعبين
		release = true, -- تحرير الدرون
		soundboard = true, -- لوحة الأصوات
		dronModel = "ch_prop_casino_drone_02a", -- الموديل الاساسي للدرون لو عايز تغيره
		LeoJobs = { -- الوظائف التي يمكنها استخدام الدرون
			"police",
			"agent",
			"ambulance"
		}
	},
}

Config.Transition = {
	['direction']       	= 'الاتجاه',
	['height']          	= 'الارتفاع',
	['camera']          	= 'الكاميرا',
	['zoom']            	= 'التكبير',
	['nightvision']     	= 'الرؤية الليلية',
	['heatvision']      	= 'رؤية الحرارة',
	['spotlight']       	= 'المصباح الضوئي',
	['scan_player']     	= 'مسح اللاعب',
	['soundboard']    	 	= 'لوحة الأصوات',
	['cancel']          	= 'إلغاء',
	['cant_use_drone']  	= 'لا يمكنك استخدام الطائرة',
	['release_drone']  		= 'تحرير الطائرة',
	['reconnect_drone']  	= 'إعادة الاتصال بالطائرة',
	['scan_searching']  	= 'جاري البحث...',
	['scan_searching_db']	= 'جاري البحث في قاعدة البيانات...',
	['scan_unknown']		= 'مجهول',
	['scan_not_recognized']	= 'لا يمكن التعرف على الهدف',
	["drone_destroyed"] = "تم تدمير الطائرة",
	["drone_exploded"] = "انفجرت الطائرة",
	["drone_lost_signal"] = "فقدت إشارة الطائرة",
	["drone_returned"] = "تم إرجاع الطائرة",
	["return_drone"] = "إرجاع الطائرة",
	["drone_not_authorized"] = "غير مصرح لك باستخدام هذه الطائرة",
	["civ_name"] = "اسم المواطن: ",
	["civ_id"] = "رقم الهوية: ",
	["civ_birthdate"] = "تاريخ الميلاد: ",
	["civ_gender"] = "الجنس: ",
	["civ_nationality"] = "الجنسية: ",
	["civ_job"] = "وظيفة المواطن: ",
	["height"] = "الطول: ",
	["reticle_player"]= "لاعب",
	["reticle_vehicle"]= "مركبة",
	["reticle_plate"]= "لوحة: ",
	["reticle_model"]= "الطراز: ",
	["reticle_owner"]= "المالك / المسجّل: ",
	["reticle_owner_unknown"]= "غير مسجّل / غير معروف",
	["reticle_server_id"]= "سيرفر ID: ",
	["reticle_vehicle_unregistered"]= "مركبة غير مسجّلة",
}

Config.UseDroneInVehicle = true -- السماح باستخدام الطائرة أثناء الجلوس في مركبة

Config.SoundsRange = 50.0 -- المدى الذي يُسمع فيه الصوت المُشغَّل بالمتر

-- قائمة الأصوات المتاحة في لوحة الأصوات
-- Text = النص الذي يظهر على الزر
-- File = اسم ملف الصوت داخل مجلد html/sounds/
Config.SoundsList = {
	{
		Text = "أوقف السيارة",
		File = "car_over.ogg",
	},
	{
		Text = "LSPD! أوقف سيارتك فوراً",
		File = "pull_imm.ogg",
	},
	{
		Text = "دورية طريق سان أندرياس، أوقف السيارة",
		File = "sahp_stop.ogg",
	},
	{
		Text = "الفرصة الأخيرة! أوقف السيارة",
		File = "last_chance.ogg",
	},
	{
		Text = "شرطة لوس سانتوس، أوقف المركبة",
		File = "los_santos.ogg",
	},
	{
		Text = "أطفئ محرك مركبتك",
		File = "engine_off.ogg",
	},
	{
		Text = "أوقف المركبة وانزل",
		File = "get_out.ogg",
	},
	{
		Text = "لا تتحرك! LSPD",
		File = "freeze_lspd.ogg",
	},
	{
		Text = "لن تفلت بهذه السهولة",
		File = "away_easy.ogg",
	},
	{
		Text = "التحذير التالي سيكون رصاصة، أوقف",
		File = "bullet_ass.ogg",
	},
	{
		Text = "لا مكان تختبئ فيه، سنتتبعك",
		File = "cant_hide_boi.ogg",
	},
	{
		Text = "قف! لا تجبرني على إطلاق النار، استسلم",
		File = "dont_make_me.ogg",
	},
	{
		Text = "LSPD! استسلم",
		File = "give_up.ogg",
	},
	{
		Text = "هذه الشرطة، تفرقوا الآن",
		File = "disperse_now.ogg",
	},
	{
		Text = "ابتعد من هنا الآن، هذه الشرطة",
		File = "get_out_of_here_now.ogg",
	},
	{
		Text = "هذه الشرطة، أخلوا المنطقة الآن",
		File = "clear_the_area.ogg",
	},
	{
		Text = "تفرقوا! لا نريد مشاكل",
		File = "move_along_people.ogg",
	},
	{
		Text = "هذه الشرطة، ابتعدوا أو ستكون هناك عواقب",
		File = "this_is_the_lspd.ogg",
	},
}

Config.DevDebug = false -- وضع المطوّر: يطبع رسائل تشخيصية في الكونسول (للاختبار فقط)

Config.UIColors = {
    Primary   = "#00ff88",          -- اللون الأساسي (بوصلة، إطار الماسح، soundboard)
    Danger    = "#ff3030",          -- لون الخطر (حلقة الهدف، إشارة ضعيفة)
    Warning   = "#ff8800",          -- لون التحذير (إشارة متوسطة)
    HPGood    = "#00ff88",          -- صحة الطائرة — ممتازة
    HPMed     = "#ff8800",          -- صحة الطائرة — متوسطة
    HPLow     = "#ff3030",          -- صحة الطائرة — خطر
    Crosshair = "255, 255, 255",    -- لون شعاع التصويب (R, G, B — بدون #)
}
