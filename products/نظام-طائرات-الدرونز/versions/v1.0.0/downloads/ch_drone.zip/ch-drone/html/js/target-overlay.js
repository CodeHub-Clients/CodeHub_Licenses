(function () {
  var panel = null;
  var loadingBar = null;

  function ensureDom() {
    if (panel) return;
    panel = document.createElement("div");
    panel.id = "ch-drone-reticle-panel";
    panel.innerHTML =
      '<div class="ch-drone-reticle__box">' +
      '<div class="ch-drone-reticle__loading-bar" style="display:none"></div>' +
      '<div class="ch-drone-reticle__head">' +
      '<span class="ch-drone-reticle__kind" id="ch-drone-reticle-kind">—</span>' +
      '<span class="ch-drone-reticle__pulse"></span>' +
      "</div>" +
      '<div class="ch-drone-reticle__title" id="ch-drone-reticle-title"></div>' +
      '<div class="ch-drone-reticle__sub" id="ch-drone-reticle-sub"></div>' +
      '<div class="ch-drone-reticle__rows" id="ch-drone-reticle-rows"></div>' +
      "</div>";
    document.body.appendChild(panel);
    loadingBar = panel.querySelector(".ch-drone-reticle__loading-bar");
  }

  function hide() {
    if (!panel) return;
    panel.classList.remove("ch-drone-reticle--visible", "ch-drone-reticle--loading");
    if (loadingBar) loadingBar.style.display = "none";
  }

  function setLoading(on) {
    if (!panel) return;
    if (on) {
      panel.classList.add("ch-drone-reticle--loading");
      if (loadingBar) loadingBar.style.display = "block";
    } else {
      panel.classList.remove("ch-drone-reticle--loading");
      if (loadingBar) loadingBar.style.display = "none";
    }
  }

  function render(data) {
    ensureDom();
    var kindEl = document.getElementById("ch-drone-reticle-kind");
    var titleEl = document.getElementById("ch-drone-reticle-title");
    var subEl = document.getElementById("ch-drone-reticle-sub");
    var rowsEl = document.getElementById("ch-drone-reticle-rows");

    kindEl.textContent = data.kindLabel || "—";
    titleEl.textContent = data.title || "";
    subEl.textContent = data.subtitle || "";
    rowsEl.innerHTML = "";

    var rows = data.rows || [];
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i];
      if (!r || !r.label) continue;
      var row = document.createElement("div");
      row.className = "ch-drone-reticle__row";
      var k = document.createElement("kbd");
      k.textContent = r.label;
      var s = document.createElement("span");
      s.textContent = r.value != null ? String(r.value) : "—";
      row.appendChild(k);
      row.appendChild(s);
      rowsEl.appendChild(row);
    }

    panel.classList.add("ch-drone-reticle--visible");
    setLoading(!!data.loading);
  }

  window.addEventListener("message", function (ev) {
    var d = ev.data;
    if (!d || !d.action) return;
    if (d.action === "reticleIntel") {
      if (!d.visible) {
        hide();
        return;
      }
      ensureDom();
      if (d.loading) {
        panel.classList.add("ch-drone-reticle--visible");
        setLoading(true);
        var kl = document.getElementById("ch-drone-reticle-kind");
        if (kl) kl.textContent = d.kind === "vehicle" ? "مركبة" : d.kind === "player" ? "لاعب" : "—";
        return;
      }
      if (d.data) render(d.data);
      else hide();
    }
    if (d.action === "hideDroneHUD") {
      hide();
    }
  });
})();
