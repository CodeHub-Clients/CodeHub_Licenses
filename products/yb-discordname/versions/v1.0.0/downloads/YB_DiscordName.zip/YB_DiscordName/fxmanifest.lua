author 'YBv10#0001'
description 'Discord Changer Name By YBv10#0001'
version '1.0'
game 'gta5'
lua54 'yes'
fx_version 'bodacious'

server_scripts {
    '@mysql-async/lib/MySQL.lua',
    "config.lua",
    "logs.lua",
    "server.lua",
}

client_scripts {
    "config.lua",
    "client.lua",
}

ui_page 'html/index.html'

files {
    'html/index.html',
}


escrow_ignore {
	'config.lua',
    "logs.lua",
    'html/index.html',
    'SETUP_AR.md',
}
dependency '/assetpacks'