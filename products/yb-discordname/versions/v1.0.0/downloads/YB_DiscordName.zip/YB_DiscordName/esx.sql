ALTER TABLE users ADD COLUMN passport VARCHAR(10) DEFAULT NULL;

-- إذا احتجت جوازاً أطول من لوحة الإدارة، غيّر MaxPassportLength في config.lua ثم نفّذ مثلاً:
-- ALTER TABLE users MODIFY COLUMN passport VARCHAR(32) DEFAULT NULL;