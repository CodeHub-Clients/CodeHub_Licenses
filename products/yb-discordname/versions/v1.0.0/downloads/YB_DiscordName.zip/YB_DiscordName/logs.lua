Config_s = {}
-- إعدادات ديسكورد
-- استخدم نفس القيم في server.cfg:
-- setr discord_guild_id "سيرفر_الديسكورد_الخاص_بك"
-- setr discord_token "توكن_البوت"
-- setr discord_required_tag "TAG"  -- التاج المطلوب (نفس سيرفر التاج في الديسكورد)


Config_s = {
    EnableSync = true,
    GuildId = GetConvar("discord_guild_id", "0"),
    BotToken = GetConvar("discord_token", "none"),
    -- يجب أن يطابق GuildId أعلاه (لا تستخدم ID سيرفر آخر)
    EnableTagCheck = true,
    RequiredTag = GetConvar("discord_required_tag", "RAS"),
    -- الرولات الي ممنوع تتعدل اسمائها بالديسكورد
    ExcludedRoles = {
        '1305900962992492645',
        '1305900949482766346',
        '1305900961365102594',
        '1305900992902074458',
        '1305901160028442635',
        '1305901135080456266',
        '1305901110544044133',
        '1305901032340983850',
    }
}