Config = {}

-- إعدادات الجواز
Config.Passport = {
    Length = 5, -- عدد خانات رمز الجواز
    Charset = 'abcdefghijklmnopqrstuvwxyz0123456789', -- الحروف المسموحة
    Display = true, -- عرض الجواز على الشاشة
    Position = { x = 0.22, y = 0.968 }, -- مكان عرض الجواز (0.0 - 1.0)
    Font = 0,
    Scale = 0.18,
    Text = "جوازك : ~y~%s~w~",
    FontFace = "sharlock",
    -- true = واجهة NUI (بدون DrawText كل فريم — أخف على الكلاينت)
    -- false = الرسم القديم بـ DrawText
    UseNUI = true,
    NUI = {
        fontSize = nil, -- إذا nil يُحسب من Scale × fontSizeScale
        fontSizeScale = 85,
        fontWeight = 500,
        direction = "rtl",
        textAlign = "right",
    },
}

-- لوحة الإدارة: تغيير جواز لاعب متصل (يحدّث الداتا + الشاشة + مزامنة الديسكورد إن كانت مفعّلة)
-- الصلاحية: أي شرط يتحقق يكفي (مجموعة ESX أو ستيم أو ديسكورد آي دي)
Config.AdminPanel = {
    Enabled = true,
    OpenCommand = "passportadmin", -- أمر فتح اللوحة
    -- true = من اللوحة يمكن وضع أي نص جواز (أحرف كبيرة/صغيرة/أرقام/رموز) ضمن الحد أدناه
    -- false = نفس قواعد الجواز التلقائي (Length + Charset)
    AllowAnyPassportText = true,
    -- أقصى طول للنص (يجب أن لا يتجاوز عمود passport في قاعدة البيانات — الافتراضي VARCHAR(10) في esx.sql)
    MaxPassportLength = 10,
    -- مجموعات ESX المسموحة (مثال: admin) — اتركها فارغة {} إذا ما تبي تقييد بالمجموعة
    AllowedGroups = {
        "admin",
    },
    -- ستيم hex (يمكن steam:1100... أو بدون البادئة)
    AllowedSteamHex = {
        -- "steam:110000105000000",
    },
    -- ديسكورد آي دي رقمي بدون discord:
    AllowedDiscordIds = {
        "1305900962992492645",
    },
}

-- رسائل الإشعارات بصيغة HTML (للأنظمة التي تدعم HTML في الإشعارات)
-- عدّل الألوان و font-family كما يناسب سكربت الإشعارات عندك — استخدم {id} {passport} {reason} حيث ينطبق
-- نمط افتراضي: dir=rtl، خط Segoe/Tahoma، ألوان مميزة للنجاح/الخطأ/المعلومات
Config.Messages = {
    -- لوحة الإدارة (سيرفر)
    admin_invalid_player_id = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;color:#e74c3c;">رقم اللاعب غير صالح</span>]],
    admin_passport_too_long = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;color:#e74c3c;">الجواز أطول من المسموح (عدّل MaxPassportLength أو عمود الداتا)</span>]],
    admin_passport_strict_invalid = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;color:#e74c3c;">صيغة الجواز غير صحيحة (الطول والأحرف من الكونفج)</span>]],
    admin_passport_invalid = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;color:#e74c3c;">الجواز فارغ أو غير صالح</span>]],
    admin_target_offline = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;color:#e74c3c;">اللاعب غير متصل</span>]],
    admin_updated_success = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;"><span style="color:#2ecc71;">تم تحديث جواز اللاعب</span> <span style="color:#3498db;font-weight:600;">{id}</span></span>]],
    admin_target_changed = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;color:#f39c12;">تم تغيير جوازك من الإدارة</span>]],
    -- لوحة الإدارة (كلاينت)
    admin_no_permission = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;color:#e74c3c;">لا تملك صلاحية لوحة الجواز</span>]],
    -- أمر تجربة مزامنة الديسكورد
    test_discord_sync_running = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;"><span style="color:#ecf0f1;">🧪 جاري تجربة تغيير الاسم إلى: </span><span style="color:#3498db;font-weight:600;">{passport}</span></span>]],
    test_discord_sync_new = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;"><span style="color:#ecf0f1;">🧪 تم إنشاء جواز جديد وتجربة تغيير الاسم: </span><span style="color:#3498db;font-weight:600;">{passport}</span></span>]],
    -- اختبار تاج ديسكورد
    test_tag_disabled = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;"><span style="color:#3498db;font-weight:600;">[تاج ديسكورد]</span> <span style="color:#bdc3c7;">فحص التاج معطّل (EnableTagCheck) — لا علاقة له بجواز اللعبة</span></span>]],
    test_tag_no_discord = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;"><span style="color:#e74c3c;font-weight:600;">[تاج ديسكورد]</span> <span style="color:#ecf0f1;">لم يُربط ديسكورد بالفايف إم</span></span>]],
    test_tag_no_config = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;"><span style="color:#e74c3c;font-weight:600;">[تاج ديسكورد]</span> <span style="color:#ecf0f1;">ناقص Guild/Token في الإعدادات</span></span>]],
    test_tag_ok = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;"><span style="color:#2ecc71;font-weight:600;">[تاج ديسكورد]</span> <span style="color:#ecf0f1;">تاج السيرفر في الديسكورد مطابق للإعدادات</span></span>]],
    test_tag_fail = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;"><span style="color:#e74c3c;font-weight:600;">[تاج ديسكورد]</span> <span style="color:#ecf0f1;">غير مطابق — ليس خطأ في جواز اللعبة</span></span>]],
    test_tag_http_fail = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;"><span style="color:#e74c3c;font-weight:600;">[تاج ديسكورد]</span> <span style="color:#ecf0f1;">فشل API أو لا يوجد primary_guild في الرد</span></span>]],
    test_tag_wrong_guild = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;"><span style="color:#e74c3c;font-weight:600;">[تاج ديسكورد]</span> <span style="color:#ecf0f1;">سيرفر التاج في الديسكورد لا يطابق discord_guild_id</span></span>]],
    test_tag_identity_off = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;"><span style="color:#e74c3c;font-weight:600;">[تاج ديسكورد]</span> <span style="color:#ecf0f1;">عطّلت عرض التاج في إعدادات الديسكورد (identity غير مفعّل)</span></span>]],
    test_tag_wrong_tag = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;"><span style="color:#e74c3c;font-weight:600;">[تاج ديسكورد]</span> <span style="color:#ecf0f1;">نص التاج لا يطابق discord_required_tag</span></span>]],
    -- اختبار تطابق الجواز كلاينت/سيرفر
    test_verify_ok = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;"><span style="color:#2ecc71;font-weight:600;">[جواز اللعبة]</span> <span style="color:#ecf0f1;">متطابق بين الداتا والكلاينت</span></span>]],
    test_verify_mismatch = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;"><span style="color:#e74c3c;font-weight:600;">[جواز]</span> <span style="color:#ecf0f1;">عدم تطابق بين الداتا والكلاينت</span></span>]],
    test_verify_no_server_passport = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;"><span style="color:#e74c3c;font-weight:600;">[جواز]</span> <span style="color:#ecf0f1;">لا يوجد جواز في الداتا</span></span>]],
    test_verify_no_client_passport = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;"><span style="color:#e74c3c;font-weight:600;">[جواز]</span> <span style="color:#ecf0f1;">الكلاينت لا يعرض جوازاً</span></span>]],
    test_verify_timeout = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;"><span style="color:#e74c3c;font-weight:600;">[جواز]</span> <span style="color:#ecf0f1;">انتهى الانتظار (timeout)</span></span>]],
    test_verify_no_player = [[<span style="font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;"><span style="color:#e74c3c;font-weight:600;">[جواز]</span> <span style="color:#ecf0f1;">خطأ لاعب</span></span>]],
}

-- أوامر اختبار (للتأكد من التاج والجواز)
Config.TestCommands = {
    Enabled = true,
    -- تاج سيرفر Discord فقط (ليس جواز اللعبة)
    Tag = "testdiscordtag",
    -- نفس فحص Tag — الاسم القديم الذي كان يلبس على «الجواز»؛ اتركه "" لتعطيله
    TagAlias = "testpassporttag",
    -- يتحقق من تطابق الجواز بين قاعدة البيانات والكلاينت
    PassportVerify = "testpassportverify",
}


