-- ============================================================
--  CodeHub AdvancedDealership | Config Shared
-- ============================================================

Config = {}

Config.state = {
	locale = "ar", -- لغة الإشعارات والسكربت
	fontFace = "A9eelsh", -- نوع الفونت

	XP_LEVEL = "YB_Level", -- سكربت الليفل
	XP_GET_RANK = "ESXP_GetRank", -- اسم الدالة للحصول على رانك اللاعب
	XP_System = true, -- تفعيل نظام الخبرة

	extendedScriptName = "es_extended",
	extendedEventName = "esx:getSharedObject",
	extendedSharedFunction = "getSharedObject",

	JOB_EVENT = "esx:setJob", -- اسم تريجر تغيير الوظيفة
	defaultColor = { r = 22, g = 24, b = 29 }, -- اللون الافتراضي للمركبات

	adminCommand = "dealerAdmin", -- أمر فتح قائمة الإدارة
	adminFromGroup = true, -- true = عبر الجروبات | false = عبر الـ identifier
	adminIdentifiers = { -- identifiers الإداريين المخصصين
		"000013cae9415",
	},

	openDealerShipText = "يمكنك فتح قائمة المعرض عبر زر [E]",
	openDealerShipKey = 38,
	openInstallementText = "يمكنك فتح قائمة الاقساط عبر زر [F]",
	openInstallementKey = 23,

	DEBUGING = true, -- تفعيل الـ Debug

	showDealerJobAll = false, -- true = تظهر معارض الوظيفة للجميع
	enableSpawnerAfterBuy = true, -- true = ترسبن المركبة بعد الشراء
	showCarsJobNotInGrade = true, -- true = تظهر السيارات لكل الرتب

	vehicleColor = true, -- تطبيق اللون عند الشراء

	-- إعدادات الأقساط
	increment = 100000, -- زيادة الدفعة بكل 100,000
	baseInstallment = 50000, -- أدنى سعر لبدء الأقساط
	nextPaymentInHours = 0.01, -- وقت دفع القسط بالساعات
	checkInstallment = 1000, -- وقت التحقق من الأقساط بـ ms

	-- إعدادات اللوحة
	PlateLetters = 3,
	PlateNumbers = 3,
	PlateUseSpace = true,

	-- وقت اختبار القيادة بالثواني
	testDriveTime = 60,

	spawneDealersSetting = { -- إعدادات السباون
		spawningType = "",
	},

	colors = {
		black = {
			{ index = 0, label = L("black"), hex = "#0d1116", rgb = { 13, 17, 22 } },
			{ index = 1, label = L("graphite"), hex = "#1c1d21", rgb = { 28, 29, 33 } },
			{ index = 2, label = L("black_metallic"), hex = "#32383d", rgb = { 50, 56, 61 } },
			{ index = 3, label = L("caststeel"), hex = "#454b4f", rgb = { 69, 75, 79 } },
			{ index = 11, label = L("black_anth"), hex = "#11141a", rgb = { 17, 20, 26 } },
			{ index = 12, label = L("matteblack"), hex = "#1e2429", rgb = { 30, 36, 41 } },
			{ index = 15, label = L("darknight"), hex = "#1d2128", rgb = { 29, 33, 40 } },
			{ index = 16, label = L("deepblack"), hex = "#000000", rgb = { 0, 0, 0 } },
			{ index = 21, label = L("oil"), hex = "#12181c", rgb = { 18, 24, 28 } },
			{ index = 147, label = L("carbon"), hex = "#1f2226", rgb = { 31, 34, 38 } },
		},
		white = {
			{ index = 106, label = L("vanilla"), hex = "#f7edd5", rgb = { 247, 237, 213 } },
			{ index = 107, label = L("creme"), hex = "#f2e8d8", rgb = { 242, 232, 216 } },
			{ index = 111, label = L("white"), hex = "#f0f0f0", rgb = { 240, 240, 240 } },
			{ index = 112, label = L("polarwhite"), hex = "#ffffff", rgb = { 255, 255, 255 } },
			{ index = 113, label = L("beige"), hex = "#e6d7c1", rgb = { 230, 215, 193 } },
			{ index = 121, label = L("mattewhite"), hex = "#f2f2f2", rgb = { 242, 242, 242 } },
			{ index = 122, label = L("snow"), hex = "#fafafa", rgb = { 250, 250, 250 } },
			{ index = 131, label = L("cotton"), hex = "#f7f3f0", rgb = { 247, 243, 240 } },
			{ index = 132, label = L("alabaster"), hex = "#f5f5f5", rgb = { 245, 245, 245 } },
			{ index = 134, label = L("purewhite"), hex = "#ffffff", rgb = { 255, 255, 255 } },
		},
		grey = {
			{ index = 4, label = L("silver"), hex = "#bec0c2", rgb = { 190, 192, 194 } },
			{ index = 5, label = L("metallicgrey"), hex = "#a1a6a8", rgb = { 161, 166, 168 } },
			{ index = 6, label = L("laminatedsteel"), hex = "#5a6268", rgb = { 90, 98, 104 } },
			{ index = 7, label = L("darkgray"), hex = "#575d63", rgb = { 87, 93, 99 } },
			{ index = 8, label = L("rockygray"), hex = "#4d5258", rgb = { 77, 82, 88 } },
			{ index = 9, label = L("graynight"), hex = "#3a3e43", rgb = { 58, 62, 67 } },
			{ index = 10, label = L("aluminum"), hex = "#8c9095", rgb = { 140, 144, 149 } },
			{ index = 13, label = L("graymat"), hex = "#73787d", rgb = { 115, 120, 125 } },
			{ index = 14, label = L("lightgrey"), hex = "#d4d7da", rgb = { 212, 215, 218 } },
			{ index = 17, label = L("asphaltgray"), hex = "#5b626a", rgb = { 91, 98, 106 } },
			{ index = 18, label = L("grayconcrete"), hex = "#6a7177", rgb = { 106, 113, 119 } },
			{ index = 19, label = L("darksilver"), hex = "#9ba0a8", rgb = { 155, 160, 168 } },
			{ index = 20, label = L("magnesite"), hex = "#8a8d91", rgb = { 138, 141, 145 } },
			{ index = 22, label = L("nickel"), hex = "#a2a5a8", rgb = { 162, 165, 168 } },
			{ index = 23, label = L("zinc"), hex = "#7a7f85", rgb = { 122, 127, 133 } },
			{ index = 24, label = L("dolomite"), hex = "#6b7178", rgb = { 107, 113, 120 } },
			{ index = 25, label = L("bluesilver"), hex = "#939ba1", rgb = { 147, 155, 161 } },
			{ index = 26, label = L("titanium"), hex = "#565e65", rgb = { 86, 94, 101 } },
			{ index = 66, label = L("steelblue"), hex = "#58677e", rgb = { 88, 103, 126 } },
			{ index = 93, label = L("champagne"), hex = "#c2b399", rgb = { 194, 179, 153 } },
			{ index = 144, label = L("grayhunter"), hex = "#51545b", rgb = { 81, 84, 91 } },
			{ index = 156, label = L("grey"), hex = "#8e9093", rgb = { 142, 144, 147 } },
		},
		red = {
			{ index = 27, label = L("red"), hex = "#c00e1a", rgb = { 192, 14, 26 } },
			{ index = 28, label = L("torino_red"), hex = "#da1918", rgb = { 218, 25, 24 } },
			{ index = 29, label = L("poppy"), hex = "#b6111b", rgb = { 182, 17, 27 } },
			{ index = 30, label = L("copper_red"), hex = "#a94744", rgb = { 169, 71, 68 } },
			{ index = 31, label = L("cardinal"), hex = "#7c1c1d", rgb = { 124, 28, 29 } },
			{ index = 32, label = L("brick"), hex = "#7a2429", rgb = { 122, 36, 41 } },
			{ index = 33, label = L("garnet"), hex = "#8e1b1f", rgb = { 142, 27, 31 } },
			{ index = 34, label = L("cabernet"), hex = "#621c21", rgb = { 98, 28, 33 } },
			{ index = 35, label = L("candy"), hex = "#9c1016", rgb = { 156, 16, 22 } },
			{ index = 39, label = L("matte_red"), hex = "#cf1f21", rgb = { 207, 31, 33 } },
			{ index = 40, label = L("dark_red"), hex = "#732021", rgb = { 115, 32, 33 } },
			{ index = 43, label = L("red_pulp"), hex = "#b22318", rgb = { 178, 35, 24 } },
			{ index = 44, label = L("bril_red"), hex = "#de0f18", rgb = { 222, 15, 24 } },
			{ index = 46, label = L("pale_red"), hex = "#f78616", rgb = { 247, 134, 22 } },
			{ index = 143, label = L("wine_red"), hex = "#5b1e2e", rgb = { 91, 30, 46 } },
			{ index = 150, label = L("volcano"), hex = "#a33535", rgb = { 163, 53, 53 } },
		},
		pink = {
			{ index = 135, label = L("electricpink"), hex = "#f21f99", rgb = { 242, 31, 153 } },
			{ index = 136, label = L("salmon"), hex = "#ffc0cb", rgb = { 255, 192, 203 } },
			{ index = 137, label = L("sugarplum"), hex = "#9d4e87", rgb = { 157, 78, 135 } },
		},
		blue = {
			{ index = 54, label = L("topaz"), hex = "#375773", rgb = { 55, 87, 115 } },
			{ index = 60, label = L("light_blue"), hex = "#5b7c8d", rgb = { 91, 124, 141 } },
			{ index = 61, label = L("galaxy_blue"), hex = "#2354a1", rgb = { 35, 84, 161 } },
			{ index = 62, label = L("dark_blue"), hex = "#293c49", rgb = { 41, 60, 73 } },
			{ index = 63, label = L("azure"), hex = "#1e395f", rgb = { 30, 57, 95 } },
			{ index = 64, label = L("navy_blue"), hex = "#21304e", rgb = { 33, 48, 78 } },
			{ index = 65, label = L("lapis"), hex = "#2f5b7c", rgb = { 47, 91, 124 } },
			{ index = 67, label = L("blue_diamond"), hex = "#4271e1", rgb = { 66, 113, 225 } },
			{ index = 68, label = L("surfer"), hex = "#4997d1", rgb = { 73, 151, 209 } },
			{ index = 69, label = L("pastel_blue"), hex = "#76afbe", rgb = { 118, 175, 190 } },
			{ index = 70, label = L("celeste_blue"), hex = "#4d8aaa", rgb = { 77, 138, 170 } },
			{ index = 73, label = L("rally_blue"), hex = "#1b4f78", rgb = { 27, 79, 120 } },
			{ index = 74, label = L("blue_paradise"), hex = "#2354a1", rgb = { 35, 84, 161 } },
			{ index = 75, label = L("blue_night"), hex = "#21314d", rgb = { 33, 49, 77 } },
			{ index = 77, label = L("cyan_blue"), hex = "#1293ce", rgb = { 18, 147, 206 } },
			{ index = 78, label = L("cobalt"), hex = "#1d4d8f", rgb = { 29, 77, 143 } },
			{ index = 79, label = L("electric_blue"), hex = "#0089ff", rgb = { 0, 137, 255 } },
			{ index = 80, label = L("horizon_blue"), hex = "#3b7f9d", rgb = { 59, 127, 157 } },
			{ index = 82, label = L("metallic_blue"), hex = "#2f5a7c", rgb = { 47, 90, 124 } },
			{ index = 83, label = L("aquamarine"), hex = "#2e8b8e", rgb = { 46, 139, 142 } },
			{ index = 84, label = L("blue_agathe"), hex = "#26495c", rgb = { 38, 73, 92 } },
			{ index = 85, label = L("zirconium"), hex = "#5a7e8f", rgb = { 90, 126, 143 } },
			{ index = 86, label = L("spinel"), hex = "#2354a1", rgb = { 35, 84, 161 } },
			{ index = 87, label = L("tourmaline"), hex = "#173753", rgb = { 23, 55, 83 } },
			{ index = 127, label = L("paradise"), hex = "#63b5cd", rgb = { 99, 181, 205 } },
			{ index = 140, label = L("bubble_gum"), hex = "#9f1d5a", rgb = { 159, 29, 90 } },
			{ index = 141, label = L("midnight_blue"), hex = "#192945", rgb = { 25, 41, 69 } },
			{ index = 146, label = L("forbidden_blue"), hex = "#2f3f4f", rgb = { 47, 63, 79 } },
			{ index = 157, label = L("glacier_blue"), hex = "#aacdd9", rgb = { 170, 205, 217 } },
		},
		yellow = {
			{ index = 42, label = L("yellow"), hex = "#ffc91f", rgb = { 255, 201, 31 } },
			{ index = 88, label = L("wheat"), hex = "#e0d397", rgb = { 224, 211, 151 } },
			{ index = 89, label = L("raceyellow"), hex = "#ffcf20", rgb = { 255, 207, 32 } },
			{ index = 91, label = L("paleyellow"), hex = "#ffe8a1", rgb = { 255, 232, 161 } },
			{ index = 126, label = L("lightyellow"), hex = "#fff799", rgb = { 255, 247, 153 } },
		},
		green = {
			{ index = 49, label = L("met_dark_green"), hex = "#1d3625", rgb = { 29, 54, 37 } },
			{ index = 50, label = L("rally_green"), hex = "#17a845", rgb = { 23, 168, 69 } },
			{ index = 51, label = L("pine_green"), hex = "#214c3d", rgb = { 33, 76, 61 } },
			{ index = 52, label = L("olive_green"), hex = "#68751a", rgb = { 104, 117, 26 } },
			{ index = 53, label = L("light_green"), hex = "#8bb320", rgb = { 139, 179, 32 } },
			{ index = 55, label = L("lime_green"), hex = "#b7e947", rgb = { 183, 233, 71 } },
			{ index = 56, label = L("forest_green"), hex = "#22383e", rgb = { 34, 56, 62 } },
			{ index = 57, label = L("lawn_green"), hex = "#60a814", rgb = { 96, 168, 20 } },
			{ index = 58, label = L("imperial_green"), hex = "#1a4228", rgb = { 26, 66, 40 } },
			{ index = 59, label = L("green_bottle"), hex = "#234135", rgb = { 35, 65, 53 } },
			{ index = 92, label = L("citrus_green"), hex = "#8eb819", rgb = { 142, 184, 25 } },
			{ index = 125, label = L("green_anis"), hex = "#94b97f", rgb = { 148, 185, 127 } },
			{ index = 128, label = L("khaki"), hex = "#9f9e8a", rgb = { 159, 158, 138 } },
			{ index = 133, label = L("army_green"), hex = "#5e6e3d", rgb = { 94, 110, 61 } },
			{ index = 151, label = L("dark_green"), hex = "#26543b", rgb = { 38, 84, 59 } },
			{ index = 152, label = L("hunter_green"), hex = "#2f583a", rgb = { 47, 88, 58 } },
			{ index = 155, label = L("matte_foliage_green"), hex = "#556052", rgb = { 85, 96, 82 } },
		},
		orange = {
			{ index = 36, label = L("tangerine"), hex = "#f78616", rgb = { 247, 134, 22 } },
			{ index = 38, label = L("orange"), hex = "#f27d0c", rgb = { 242, 125, 12 } },
			{ index = 41, label = L("matteorange"), hex = "#f27d0c", rgb = { 242, 125, 12 } },
			{ index = 123, label = L("lightorange"), hex = "#ffa550", rgb = { 255, 165, 80 } },
			{ index = 124, label = L("peach"), hex = "#ffc1a4", rgb = { 255, 193, 164 } },
			{ index = 130, label = L("pumpkin"), hex = "#ff7b00", rgb = { 255, 123, 0 } },
			{ index = 138, label = L("orangelambo"), hex = "#ff6600", rgb = { 255, 102, 0 } },
		},
		brown = {
			{ index = 45, label = L("copper"), hex = "#b66325", rgb = { 182, 99, 37 } },
			{ index = 47, label = L("lightbrown"), hex = "#6a4b3c", rgb = { 106, 75, 60 } },
			{ index = 48, label = L("darkbrown"), hex = "#402e2b", rgb = { 64, 46, 43 } },
			{ index = 90, label = L("bronze"), hex = "#6c5048", rgb = { 108, 80, 72 } },
			{ index = 94, label = L("brownmetallic"), hex = "#6e5544", rgb = { 110, 85, 68 } },
			{ index = 95, label = L("Expresso"), hex = "#46352a", rgb = { 70, 53, 42 } },
			{ index = 96, label = L("chocolate"), hex = "#3d2917", rgb = { 61, 41, 23 } },
			{ index = 97, label = L("terracotta"), hex = "#c47a53", rgb = { 196, 122, 83 } },
			{ index = 98, label = L("marble"), hex = "#a89985", rgb = { 168, 153, 133 } },
			{ index = 99, label = L("sand"), hex = "#cdb299", rgb = { 205, 178, 153 } },
			{ index = 100, label = L("sepia"), hex = "#ac9682", rgb = { 172, 150, 130 } },
			{ index = 101, label = L("bison"), hex = "#876b52", rgb = { 135, 107, 82 } },
			{ index = 102, label = L("palm"), hex = "#756c61", rgb = { 117, 108, 97 } },
			{ index = 103, label = L("caramel"), hex = "#a0826d", rgb = { 160, 130, 109 } },
			{ index = 104, label = L("rust"), hex = "#9f6652", rgb = { 159, 102, 82 } },
			{ index = 105, label = L("chestnut"), hex = "#634330", rgb = { 99, 67, 48 } },
			{ index = 108, label = L("brown"), hex = "#6f5848", rgb = { 111, 88, 72 } },
			{ index = 109, label = L("hazelnut"), hex = "#9a7e6f", rgb = { 154, 126, 111 } },
			{ index = 110, label = L("shell"), hex = "#b5a690", rgb = { 181, 166, 144 } },
			{ index = 114, label = L("mahogany"), hex = "#431d18", rgb = { 67, 29, 24 } },
			{ index = 115, label = L("cauldron"), hex = "#593a2f", rgb = { 89, 58, 47 } },
			{ index = 116, label = L("blond"), hex = "#d5cab3", rgb = { 213, 202, 179 } },
			{ index = 129, label = L("gravel"), hex = "#7b736c", rgb = { 123, 115, 108 } },
			{ index = 153, label = L("darkearth"), hex = "#4a3c31", rgb = { 74, 60, 49 } },
			{ index = 154, label = L("desert"), hex = "#b6996b", rgb = { 182, 153, 107 } },
		},
		purple = {
			{ index = 71, label = L("indigo"), hex = "#4b00e5", rgb = { 75, 0, 229 } },
			{ index = 72, label = L("deeppurple"), hex = "#360a77", rgb = { 54, 10, 119 } },
			{ index = 76, label = L("darkviolet"), hex = "#3c1c4c", rgb = { 60, 28, 76 } },
			{ index = 81, label = L("amethyst"), hex = "#9b59b6", rgb = { 155, 89, 182 } },
			{ index = 142, label = L("mysticalviolet"), hex = "#6c3b7d", rgb = { 108, 59, 125 } },
			{ index = 145, label = L("purplemetallic"), hex = "#6b1f7b", rgb = { 107, 31, 123 } },
			{ index = 148, label = L("matteviolet"), hex = "#5f3e6f", rgb = { 95, 62, 111 } },
			{ index = 149, label = L("mattedeeppurple"), hex = "#281a39", rgb = { 40, 26, 57 } },
		},
		chrome = {
			{ index = 117, label = L("brushedchrome"), hex = "#9e9e9e", rgb = { 158, 158, 158 } },
			{ index = 118, label = L("blackchrome"), hex = "#1e2429", rgb = { 30, 36, 41 } },
			{ index = 119, label = L("brushedaluminum"), hex = "#9fa1a4", rgb = { 159, 161, 164 } },
			{ index = 120, label = L("chrome"), hex = "#c9c9c9", rgb = { 201, 201, 201 } },
		},
		gold = {
			{ index = 37, label = L("gold"), hex = "#cda941", rgb = { 205, 169, 65 } },
			{ index = 158, label = L("puregold"), hex = "#d4af37", rgb = { 212, 175, 55 } },
			{ index = 159, label = L("brushedgold"), hex = "#b8860b", rgb = { 184, 134, 11 } },
			{ index = 160, label = L("lightgold"), hex = "#f0e68c", rgb = { 240, 230, 140 } },
		},
	},

	coords = {}, -- معارض الكونفج الثابتة
}

Config.mechanical = {
	{ name = "armour", title = "قوة الهيكل", mainID = 16 },
	{ name = "engine", title = "قوة المحرك", mainID = 11 },
	{ name = "break", title = "نوع المكابح", mainID = 12 },
	{ name = "transmission", title = "نظام ناقل الحركة", mainID = 13 },
	{ name = "suspension", title = "نظام التعليق", mainID = 15 },
	{ name = "frontBumper", title = "الصدام الأمامي", mainID = 1 },
	{ name = "grille", title = "الشبك الأمامي", mainID = 6 },
	{ name = "hood", title = "غطاء المحرك", mainID = 7 },
	{ name = "roof", title = "تغيير السقف", mainID = 10 },
	{ name = "turbo", title = "التوربين (Turbo)", mainID = 18 },
	{ name = "rollCage", title = "القفص الداخلي", mainID = 5 },
	{ name = "skirt", title = "الدواسة الجانبية", mainID = 3 },
	{ name = "rearBumper", title = "الصدام الخلفي", mainID = 2 },
	{ name = "spoiler", title = "شكل الجناح", mainID = 0 },
	{ name = "exhaust", title = "شكل العادم", mainID = 4 },
	{ name = "horn", title = "صوت البوق", mainID = 14 },
	{ name = "wheel", title = "شكل العجلات", mainID = 23 },
	{ name = "wheel2", title = "شكل العجلات الإضافي", mainID = 24 },
}

Config.classification = {
	Cars = { type = "car", job = "civ" },
	Trucks = { type = "truck", job = "civ" },
	Motorbike = { type = "car", job = "civ" },
	Helicopters = { type = "helicopter", job = "civ" },
	Boats = { type = "boat", job = "civ" },
	PoliceCars = { type = "car", job = "police" },
	agentCars = { type = "car", job = "agent" },
	AdminCars = { type = "car", job = "admin" },
	AmbulanceCars = { type = "car", job = "ambulance" },
	MechanicCars = { type = "car", job = "mechanic" },
	PoliceBoats = { type = "boat", job = "police" },
	agentBoats = { type = "boat", job = "agent" },
	PoliceHelicopters = { type = "helicopter", job = "police" },
	agentHelicopters = { type = "helicopter", job = "agent" },
}
