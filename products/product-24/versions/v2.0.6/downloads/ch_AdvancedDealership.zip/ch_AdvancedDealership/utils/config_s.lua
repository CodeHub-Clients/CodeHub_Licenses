-- ============================================================
--  CodeHub AdvancedDealership | Server Config
-- ============================================================

Config_s = {

	-- ─── إعدادات MySQL ────────────────────────────────────────
	-- اسم ريسورس قاعدة البيانات (غيّره لو تستخدم مكتبة غير oxmysql)
	-- oxmysql | mysql-async | ghmattimysql
	MYSQL = {
		resource = "oxmysql", -- اسم الريسورس

		-- أسماء الدوال (لا تغيّر إلا لو غيّرت المكتبة)
		fn_query = "query_async", -- استعلام يرجع rows (SELECT)
		fn_execute = "execute", -- إدخال بدون نتيجة (INSERT)
		fn_update = "update", -- تحديث صف (UPDATE)
	},

	DISCORD_WEBHOOK = "https://discord.com/api/webhooks/1399607993384964106/1svR2nIiNA8YROnAp4eMPBzmX_lsyImKVGaDwU5eqqNVMnrTdDK5DxNF84y0I8kqUcMB", -- لوجات التفاعل العام
	DISCORD_WEBHOOK_ADMIN = "https://discord.com/api/webhooks/1399600496817340426/_K11W8AGjNcQYzmQ8k5BeE4QiBKt-K2AYhaQTxzM0cCuewlL8oPIGLHhWu8HGnGrBBvH", -- لوجات الأدمن

	-- ─── إعدادات قاعدة البيانات ───────────────────────────────
	-- يمكنك تغيير اسم الجدول والأعمدة لتناسب قاعدة البيانات الخاصة بك

	DB = {
		-- اسم الجدول الذي تُحفظ فيه المركبات المشتراة
		table = "owned_vehicles",

		-- أعمدة جدول owned_vehicles
		col_owner = "owner", -- معرف مالك السيارة
		col_plate = "plate", -- رقم اللوحة
		col_vehicle = "vehicle", -- بيانات المركبة (JSON)
		col_type = "type", -- نوع المركبة
		col_job = "job", -- الوظيفة
		col_category = "category", -- الفئة
		col_name = "name", -- اسم المركبة
		col_priceold = "priceold", -- السعر الأصلي
		col_levelold = "levelold", -- المستوى المطلوب
		col_stored = "stored", -- هل مخزنة؟
		col_installments = "installments", -- بيانات الأقساط (JSON)
	},
}

-- ─── SQL Queries (مبنية تلقائياً من DB أعلاه) ──────────────
-- يمكنك تجاهل هذا القسم إذا غيّرت DB فقط
-- أو تعديل الـ Queries مباشرة إذا أردت تخصيصاً أكثر

local DB = Config_s.DB

Config_s.SQL = {
	-- التحقق من وجود أقساط نشطة
	check_installments = string.format(
		"SELECT %s FROM %s WHERE %s = ? AND %s IS NOT NULL",
		DB.col_installments,
		DB.table,
		DB.col_owner,
		DB.col_installments
	),

	-- إدخال مركبة مشتراة كاش
	insert_buy_now = string.format(
		"INSERT INTO %s (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
		DB.table,
		DB.col_owner,
		DB.col_plate,
		DB.col_vehicle,
		DB.col_type,
		DB.col_job,
		DB.col_category,
		DB.col_name,
		DB.col_priceold,
		DB.col_levelold,
		DB.col_stored
	),

	-- إدخال مركبة مشتراة بالتقسيط
	insert_installments = string.format(
		"INSERT INTO %s (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
		DB.table,
		DB.col_owner,
		DB.col_plate,
		DB.col_vehicle,
		DB.col_type,
		DB.col_job,
		DB.col_category,
		DB.col_name,
		DB.col_priceold,
		DB.col_levelold,
		DB.col_stored,
		DB.col_installments
	),

	-- التحقق من تكرار اللوحة
	check_plate = string.format("SELECT 1 FROM %s WHERE %s = ?", DB.table, DB.col_plate),

	-- جلب قائمة الأقساط للاعب
	list_installments = string.format(
		"SELECT %s, %s, %s FROM %s WHERE %s = ? AND %s IS NOT NULL",
		DB.col_plate,
		DB.col_name,
		DB.col_installments,
		DB.table,
		DB.col_owner,
		DB.col_installments
	),

	-- جلب عقد أقساط محدد بالبلاكة
	get_installment_by_plate = string.format(
		"SELECT %s, %s, %s FROM %s WHERE %s = ? AND %s = ? AND %s IS NOT NULL LIMIT 1",
		DB.col_plate,
		DB.col_name,
		DB.col_installments,
		DB.table,
		DB.col_owner,
		DB.col_plate,
		DB.col_installments
	),

	-- تحديث بيانات الأقساط
	update_installments = string.format(
		"UPDATE %s SET %s = ? WHERE %s = ?",
		DB.table,
		DB.col_installments,
		DB.col_plate
	),

	-- حذف مركبة (سحب السيارة عند التقصير)
	delete_vehicle = string.format("DELETE FROM %s WHERE %s = ?", DB.table, DB.col_plate),

	-- جلب سجل أقساط لاعب عند تسجيل الدخول
	load_player_installments = string.format(
		"SELECT * FROM %s WHERE %s = ? AND %s IS NOT NULL",
		DB.table,
		DB.col_owner,
		DB.col_installments
	),
}
