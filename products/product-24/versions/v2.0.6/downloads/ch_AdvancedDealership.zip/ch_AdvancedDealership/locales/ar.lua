-- ============================================================
--  CodeHub AdvancedDealership | Locale: Arabic (ar)
-- ============================================================

Locales = Locales or {}

Locales["ar"] = {

	-- ─── إشعارات الشراء ───────────────────────────────────────
	buy_vehicle_owned = "السيارة برقم %s أصبحت ملكك الآن",
	buy_vehicle_failed = "حدث مشكلة أثناء شراء السيارة: ربما لا يوجد لديك مال كافي أو لديك أقساط سابقة",
	buy_vehicle_not_found = "المركبة غير موجودة أو تم إزالتها.",
	buy_vehicle_low_level = "مستواك الحالى غير كافي لشراء هذه المركبة!",
	buy_vehicle_low_rank = "رتبتك الحالية لا تصلح لشراء المركبة!",

	-- ─── إشعارات الأقساط ──────────────────────────────────────
	inst_paid_one = "تم دفع %s$ بنجاح",
	inst_paid_all = "تم سداد كامل الأقساط للوحة %s",
	inst_paid_full = "تم سداد كامل المتبقي (%s$) — السيارة أصبحت ملكك بالكامل",

	inst_auto_paid = "شركة تأمين السيارات: تم دفع %s$\n<br>متبقي %s/%s قسط",
	inst_auto_complete = "شركة تأمين السيارات: تم دفع جميع الأقساط، السيارة أصبحت ملكك بالكامل.\n<br>لوحتها: %s",
	inst_warn_1 = "شركة تأمين السيارة: تنبيه أول — لا يوجد مبلغ كافٍ لدفع القسط %s\n<br>المبلغ: %s$",
	inst_warn_2 = "شركة تأمين السيارة: تنبيه ثاني — لا يوجد مبلغ كافٍ لدفع القسط %s\n<br>المبلغ: %s$",
	inst_repo = "شركة تأمين السيارات: تم سحب سيارتك من الكراج.\n<br>اللوحة: %s",

	-- ─── أخطاء الأقساط (server → client) ────────────────────
	err_player_not_found = "اللاعب غير موجود",
	err_contract_not_found = "العقد غير موجود",
	err_contract_corrupt = "بيانات العقد تالفة",
	err_contract_not_active = "العقد غير نشط",
	err_no_installments_left = "لا توجد أقساط متبقية",
	err_bank_insufficient = "رصيد البنك غير كافٍ (%s$)",

	-- ─── إشعارات كلايانت (finance) ───────────────────────────
	client_paid_one_ok = "تم دفع القسط بنجاح",
	client_paid_one_err = "تعذر دفع القسط",
	client_paid_full_ok = "تم السداد الكامل",
	client_paid_full_err = "تعذر السداد المبكر",

	-- ─── عناوين Discord Logs ──────────────────────────────────
	log_buy_cash = "🛒 شراء سيارة كاش",
	log_buy_installment = "🧾 شراء سيارة بالتقسيط",
	log_pay_one_manual = "💳 دفع قسط (يدوي)",
	log_pay_one_auto = "💳 دفع قسط (تلقائي)",
	log_pay_full = "✅ سداد مبكر كامل",
	log_complete_manual = "🎉 اكتمال الأقساط (يدوي)",
	log_complete_auto = "🎉 اكتمال الأقساط (تلقائي)",
	log_repo = "🚫 سيارة مسحوبة (تقصير بالأقساط)",
	log_admin_open = "🔓 فتح لوحة الأدمن",
	log_admin_save = "🧷 حفظ إعدادات النظام",
	log_admin_restart = "🔁 Restart Resource",
	log_edit_vehicle = "✏️ تعديل مركبة",
	log_delete_vehicle = "🗑️ حذف مركبة",

	-- ─── حقول Discord (field names) ──────────────────────────
	field_player = "👤 اللاعب",
	field_identifier = "🪪 المعرّف",
	field_discord = "💬 Discord",
	field_job = "💼 الوظيفة",
	field_group = "🔰 الجروب",
	field_bank = "🏦 رصيد البنك",
	field_cash = "💵 رصيد الكاش",
	field_vehicle = "🚗 المركبة",
	field_model = "⚙️ الموديل",
	field_plate = "🔖 اللوحة",
	field_price = "💰 السعر",
	field_category = "📂 الفئة",
	field_required_job = "👔 وظيفة مطلوبة",
	field_down_payment = "💳 المقدم",
	field_installment_value = "💸 قيمة القسط",
	field_installment_count = "📅 عدد الأقساط",
	field_installment_every = "⏰ كل كم ساعة",
	field_payment_method = "🏧 وسيلة الدفع",
	field_amount = "💰 المبلغ",
	field_amount_total = "💰 المبلغ الإجمالي",
	field_progress = "📊 التقدم",
	field_status = "✅ الحالة",
	field_result = "🏁 النتيجة",
	field_reason = "⚠️ السبب",
	field_action = "📛 الإجراء",
	field_no_discord = "❌ لا يوجد",

	-- ─── قيم حقول Discord ────────────────────────────────────
	val_paid_all_manual = "تم سداد جميع الأقساط يدوياً",
	val_paid_all_auto = "تمت جميع الأقساط تلقائياً",
	val_paid_full_result = "سيارة مدفوعة بالكامل",
	val_repo_reason = "تجاوز 3 تحذيرات",
	val_repo_action = "حذف من قاعدة البيانات",
	val_admin_save_details = "تم تحديث الإعدادات في الذاكرة",
}
