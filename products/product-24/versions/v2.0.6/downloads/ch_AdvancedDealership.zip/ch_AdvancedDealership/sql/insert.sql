ALTER TABLE `owned_vehicles`
ADD COLUMN `installments` LONGTEXT DEFAULT NULL;