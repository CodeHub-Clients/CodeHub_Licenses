fx_version("cerulean")
game("gta5")
author("CodeHub AdvancedDealerShip | By Eslam Ashref")
description("سكربت المعرض المحدث بمميزات رائعة")
version("2.0.0")

shared_scripts({
	"@es_extended/imports.lua",
	"locales/main.lua",
	"locales/*.lua",
	"utils/config.lua",
})

client_scripts({
	"utils/theme.lua",
	"client/client.lua",
})

server_scripts({
	"utils/config_s.lua",
	"server/server.lua",
})

ui_page("ui/dist/index.html")
files({
	"ui/dist/**/*",
})

dependencies({ "es_extended", "oxmysql" })
