-- ═══════════════════════════════════════════════════════════════
--  YB MDT v2.1  |  Full Database Schema
--
--  Run this file on a FRESH installation.
--  For upgrades from v1, the resource auto-runs column migrations
--  via AddColumnIfMissing() on every server start.
--
--  All tables:
--    • ENGINE=InnoDB
--    • utf8mb4 / utf8mb4_unicode_ci  (full Arabic + emoji support)
--    • Indexes on every WHERE / ORDER BY / GROUP BY column
-- ═══════════════════════════════════════════════════════════════

SET NAMES utf8mb4;
SET time_zone = '+00:00';

-- ── user_violations  (traffic tickets) ───────────────────────
CREATE TABLE IF NOT EXISTS `user_violations` (
    `id`                 INT          NOT NULL AUTO_INCREMENT,
    `identifier`         VARCHAR(60)  NOT NULL,
    `reason`             VARCHAR(255) NOT NULL,
    `amount`             INT          NOT NULL DEFAULT 0,
    `officer`            VARCHAR(100) NOT NULL DEFAULT '',
    `officer_identifier` VARCHAR(60)  NOT NULL DEFAULT '',
    `note`               VARCHAR(500)     NULL DEFAULT NULL,
    `paid`               TINYINT(1)   NOT NULL DEFAULT 0,
    `paid_at`            TIMESTAMP        NULL DEFAULT NULL,
    `date`               TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_uv_identifier` (`identifier`),
    INDEX `idx_uv_paid`       (`paid`),
    INDEX `idx_uv_date`       (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── user_criminal_record ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS `user_criminal_record` (
    `id`                 INT           NOT NULL AUTO_INCREMENT,
    `identifier`         VARCHAR(60)   NOT NULL,
    `charge`             VARCHAR(255)  NOT NULL,
    `officer`            VARCHAR(100)  NOT NULL DEFAULT '',
    `officer_identifier` VARCHAR(60)   NOT NULL DEFAULT '',
    `description`        VARCHAR(1000)     NULL DEFAULT NULL,
    `sentence`           VARCHAR(255)      NULL DEFAULT NULL,
    `date`               TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_cr_identifier` (`identifier`),
    INDEX `idx_cr_date`       (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── user_services_stop  (service suspension) ─────────────────
CREATE TABLE IF NOT EXISTS `user_services_stop` (
    `id`                 INT          NOT NULL AUTO_INCREMENT,
    `identifier`         VARCHAR(60)  NOT NULL,
    `expire`             BIGINT       NOT NULL DEFAULT 0,
    `reason`             VARCHAR(255) NOT NULL DEFAULT '',
    `officer`            VARCHAR(100) NOT NULL DEFAULT '',
    `officer_identifier` VARCHAR(60)  NOT NULL DEFAULT '',
    `date`               TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_ss_identifier` (`identifier`),
    INDEX `idx_ss_expire`     (`expire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── yb_warrants ───────────────────────────────────────────────
--  warrant_type: arrest | investigation | wanted | search
--  danger_level: 1 (low) – 4 (extremely dangerous)
--  expires_at:   0 = no expiry
CREATE TABLE IF NOT EXISTS `yb_warrants` (
    `id`                    INT           NOT NULL AUTO_INCREMENT,
    `identifier`            VARCHAR(60)   NOT NULL,
    `name`                  VARCHAR(150)  NOT NULL DEFAULT '',
    `description`           VARCHAR(1000) NOT NULL DEFAULT '',
    `warrant_type`          VARCHAR(30)   NOT NULL DEFAULT 'wanted',
    `danger_level`          TINYINT(1)    NOT NULL DEFAULT 1,
    `expires_at`            BIGINT        NOT NULL DEFAULT 0,
    `issued_by`             VARCHAR(100)  NOT NULL DEFAULT '',
    `issued_by_identifier`  VARCHAR(60)   NOT NULL DEFAULT '',
    `status`                ENUM('active','executed','expired','cancelled')
                                          NOT NULL DEFAULT 'active',
    `created_at`            TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`            TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                          ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_w_identifier` (`identifier`),
    INDEX `idx_w_status`     (`status`),
    INDEX `idx_w_created`    (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── yb_dispatch ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `yb_dispatch` (
    `id`                      INT           NOT NULL AUTO_INCREMENT,
    `title`                   VARCHAR(150)  NOT NULL,
    `description`             VARCHAR(1000) NOT NULL DEFAULT '',
    `location`                VARCHAR(255)  NOT NULL DEFAULT '',
    `priority`                TINYINT(1)    NOT NULL DEFAULT 1,
    `status`                  ENUM('open','assigned','closed')
                                            NOT NULL DEFAULT 'open',
    `created_by`              VARCHAR(100)  NOT NULL DEFAULT '',
    `created_by_identifier`   VARCHAR(60)   NOT NULL DEFAULT '',
    `assigned_to`             VARCHAR(100)      NULL DEFAULT NULL,
    `created_at`              TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `closed_at`               TIMESTAMP         NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    INDEX `idx_d_status`      (`status`),
    INDEX `idx_d_priority`    (`priority`),
    INDEX `idx_d_created_at`  (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── mdt_jail_records  (NEW in v2.1) ──────────────────────────
CREATE TABLE IF NOT EXISTS `mdt_jail_records` (
    `id`                 INT          NOT NULL AUTO_INCREMENT,
    `identifier`         VARCHAR(60)  NOT NULL,
    `officer_identifier` VARCHAR(60)  NOT NULL DEFAULT '',
    `officer_name`       VARCHAR(100) NOT NULL DEFAULT '',
    `reason`             VARCHAR(255) NOT NULL,
    `jail_time`          INT          NOT NULL DEFAULT 0,
    `fine`               INT          NOT NULL DEFAULT 0,
    `released`           TINYINT(1)   NOT NULL DEFAULT 0,
    `created_at`         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_jr_identifier` (`identifier`),
    INDEX `idx_jr_released`   (`released`),
    INDEX `idx_jr_created`    (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── impounded_vehicles  (NEW in v2.1) ────────────────────────
--  release_time = 0 means manual release only
CREATE TABLE IF NOT EXISTS `impounded_vehicles` (
    `id`                 INT          NOT NULL AUTO_INCREMENT,
    `plate`              VARCHAR(10)  NOT NULL,
    `owner_identifier`   VARCHAR(60)  NOT NULL,
    `officer_identifier` VARCHAR(60)  NOT NULL DEFAULT '',
    `officer_name`       VARCHAR(100) NOT NULL DEFAULT '',
    `reason`             VARCHAR(255) NOT NULL DEFAULT '',
    `release_time`       BIGINT       NOT NULL DEFAULT 0,
    `released`           TINYINT(1)   NOT NULL DEFAULT 0,
    `released_at`        TIMESTAMP        NULL DEFAULT NULL,
    `created_at`         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_iv_plate`    (`plate`),
    INDEX `idx_iv_owner`    (`owner_identifier`),
    INDEX `idx_iv_released` (`released`),
    INDEX `idx_iv_created`  (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── mdt_reports  (NEW in v2.1) ────────────────────────────────
--  type: arrest | incident | raid | patrol | traffic | general
--  involved_players: comma-separated identifiers
CREATE TABLE IF NOT EXISTS `mdt_reports` (
    `id`                 INT           NOT NULL AUTO_INCREMENT,
    `title`              VARCHAR(150)  NOT NULL,
    `type`               VARCHAR(50)   NOT NULL DEFAULT 'general',
    `description`        TEXT          NOT NULL,
    `officer_identifier` VARCHAR(60)   NOT NULL DEFAULT '',
    `officer_name`       VARCHAR(100)  NOT NULL DEFAULT '',
    `involved_players`   TEXT              NULL DEFAULT NULL,
    `created_at`         TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`         TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP
                         ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_rep_officer` (`officer_identifier`),
    INDEX `idx_rep_type`    (`type`),
    INDEX `idx_rep_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── yb_audit_log ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `yb_audit_log` (
    `id`                 INT          NOT NULL AUTO_INCREMENT,
    `action`             VARCHAR(100) NOT NULL,
    `officer_identifier` VARCHAR(60)  NOT NULL,
    `officer_name`       VARCHAR(150) NOT NULL DEFAULT '',
    `officer_job`        VARCHAR(60)  NOT NULL DEFAULT '',
    `target_identifier`  VARCHAR(60)      NULL DEFAULT NULL,
    `target_name`        VARCHAR(150)     NULL DEFAULT NULL,
    `details`            TEXT             NULL DEFAULT NULL,
    `timestamp`          TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_al_officer`   (`officer_identifier`),
    INDEX `idx_al_target`    (`target_identifier`),
    INDEX `idx_al_action`    (`action`),
    INDEX `idx_al_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────
--  mdt_camera_logs   (Surveillance cameras)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `mdt_camera_logs` (
    `id`            INT           NOT NULL AUTO_INCREMENT,
    `location_id`   VARCHAR(60)   NOT NULL DEFAULT '',
    `location_name` VARCHAR(150)  NOT NULL DEFAULT '',
    `event_type`    VARCHAR(60)   NOT NULL DEFAULT 'alert',
    `description`   VARCHAR(500)  NOT NULL DEFAULT '',
    `suspect_name`  VARCHAR(150)  NOT NULL DEFAULT '',
    `created_at`    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_cl_location`  (`location_id`),
    INDEX `idx_cl_created`   (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────
--  weapon_licenses
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `weapon_licenses` (
    `id`             INT           NOT NULL AUTO_INCREMENT,
    `identifier`     VARCHAR(60)   NOT NULL,
    `status`         ENUM('active','revoked') NOT NULL DEFAULT 'active',
    `issued_at`      TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `revoked_at`     TIMESTAMP         NULL DEFAULT NULL,
    `revoked_by`     VARCHAR(60)       NULL DEFAULT NULL,
    `revoke_reason`  VARCHAR(255)      NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    INDEX `idx_wl_identifier` (`identifier`),
    INDEX `idx_wl_status`     (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────
--  vehicle_warnings
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `vehicle_warnings` (
    `id`                 INT          NOT NULL AUTO_INCREMENT,
    `plate`              VARCHAR(12)  NOT NULL,
    `owner_identifier`   VARCHAR(60)  NOT NULL DEFAULT '',
    `warning_type`       VARCHAR(60)  NOT NULL DEFAULT 'other',
    `description`        VARCHAR(500) NOT NULL DEFAULT '',
    `officer_identifier` VARCHAR(60)  NOT NULL DEFAULT '',
    `officer_name`       VARCHAR(100) NOT NULL DEFAULT '',
    `created_at`         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_vw_plate`    (`plate`),
    INDEX `idx_vw_owner`    (`owner_identifier`),
    INDEX `idx_vw_created`  (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ═══════════════════════════════════════════════════════════════
--  Upgrade notes for existing v2.0 installations
--  (run these manually if upgrading — auto-migration also runs
--   these on server start via AddColumnIfMissing())
-- ═══════════════════════════════════════════════════════════════

-- ALTER TABLE `yb_warrants` ADD COLUMN IF NOT EXISTS `warrant_type` VARCHAR(30) NOT NULL DEFAULT 'wanted';
-- ALTER TABLE `yb_warrants` ADD COLUMN IF NOT EXISTS `danger_level`  TINYINT(1)  NOT NULL DEFAULT 1;
-- ALTER TABLE `yb_warrants` ADD COLUMN IF NOT EXISTS `expires_at`    BIGINT      NOT NULL DEFAULT 0;
