fx_version 'cerulean'
game 'gta5'

author 'YB Scripts'
description 'YB MDT v2 — Absher & Basher Government Digital Portal'
version '3.0.0'

shared_scripts {
    '@es_extended/imports.lua',
    'config.lua',
    'shared/utils.lua',
    'shared/permissions.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/config_private.lua', -- ⚠️ بيانات حساسة — server only
    'server/main.lua',      -- DB init, RateLimit(), GetNameByIdentifier(), exports
    'server/discord.lua',   -- DiscordLog() webhook helper (must load before audit)
    'server/audit.lua',     -- AuditLog(), retention cleanup
    'server/absher.lua',    -- Citizen portal callbacks
    'server/police.lua',    -- Core MDT callbacks (search, violations, warrants, tracking, warnings)
    'server/jail.lua',      -- Jail system
    'server/impound.lua',   -- Vehicle impound system
    'server/reports.lua',   -- Police reports
    'server/services.lua',  -- Service stop expiry + hook + exports
    'server/dashcam.lua',   -- Dash cam tracking
    'server/cameras.lua',   -- Surveillance camera alerts
    'server/licenses.lua',  -- Weapon license system
}

client_scripts {
    'client/main.lua',      -- Commands, hotkey, animation, exports, net events
    'client/absher.lua',    -- Citizen NUI callbacks
    'client/police.lua',    -- Police NUI callbacks (all MDT actions)
    'client/cameras.lua',   -- Surveillance camera viewer (must load before dashcam)
    'client/dashcam.lua',   -- Dash cam position broadcaster + feed viewer
    'client/tracking.lua',  -- Wanted person tracking
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/assets/*.js',
    'html/assets/*.css',
}

lua54 'yes'


escrow_ignore {
    'config.lua',
    'server/config_private.lua',
}

dependency '/assetpacks'