Config = {}

-- ═══════════════════════════════════════════════════════════════
--  Commands & Controls
-- ═══════════════════════════════════════════════════════════════

-- Single command for all players:
--   Civilian → opens Absher only
--   Police   → opens Absher + Basher (MDT)
Config.Command       = 'mdt'
Config.PoliceKey     = 'F6'
Config.PoliceKeyCode = 117

-- ═══════════════════════════════════════════════════════════════
--  Jail Integration
--  Set to the server-side event your jail resource uses.
--  Common examples:
--    esx_jail       → 'esx_jail:sendToJail'
--    qb-jail        → 'qb-jail:server:sendToJail'
--    es_jail        → 'es_jail:putPlayerInJail'
-- ═══════════════════════════════════════════════════════════════

Config.JailEvent = 'esx_jail:sendToJail'

-- ═══════════════════════════════════════════════════════════════
--  Job Permissions
--
--  Grade thresholds per job per action.
--  Set to 0  → all grades of that job can perform the action.
--  Set to N  → only grade N and above.
--
--  Grade bands (suggested ESX convention):
--    0-1  : رقيب / رقيب أول    (patrol officers   – lookup only)
--    2-3  : ملازم / نقيب       (field supervisor  – tickets, reports, impound)
--    4-5  : رائد / مقدم        (command           – jail, warrants, suspensions)
--    6+   : عقيد / لواء        (high command      – audit logs, full remove)
-- ═══════════════════════════════════════════════════════════════

Config.Jobs = {
    ['police'] = {
        label     = 'الشرطة',
        canAccess = true,
        grades    = {
            canLookup              = 0,
            canDispatch            = 0,
            canAddViolation        = 2,
            canAddReport           = 2,
            canImpoundVehicle      = 2,
            canAddCriminal         = 2,
            canIssueVehicleWarning = 2,
            canTrackWanted         = 2,
            canRevokeLicense       = 3,
            canReleaseImpound      = 3,
            canJailPlayer          = 4,
            canIssueWarrant        = 4,
            canStopServices        = 4,
            canRemoveCriminal      = 4,
            canRemoveServiceStop   = 4,
            canViewAuditLog        = 6,
        },
    },
    ['agent'] = {
        label     = 'حرس الحدود',
        canAccess = true,
        grades    = {
            canLookup              = 0,
            canDispatch            = 0,
            canAddViolation        = 2,
            canAddReport           = 2,
            canImpoundVehicle      = 2,
            canAddCriminal         = 2,
            canIssueVehicleWarning = 2,
            canTrackWanted         = 2,
            canRevokeLicense       = 3,
            canReleaseImpound      = 3,
            canJailPlayer          = 4,
            canIssueWarrant        = 4,
            canStopServices        = 4,
            canRemoveCriminal      = 4,
            canRemoveServiceStop   = 4,
            canViewAuditLog        = 6,
        },
    },
}

-- ─────────────────────────────────────────────────────────────
--  وظائف أبشر فقط — يرون أبشر الأفراد لكن ليس باشر MDT
--  أضف هنا أي وظيفة لا تريدها ترى لوحة باشر
-- ─────────────────────────────────────────────────────────────
Config.AbsherOnlyJobs = {

}

-- Jobs that bypass every grade check — full access to all actions.
Config.AdminJobs = {
    ['admin']      = true,
    ['superadmin'] = true,
}

-- ═══════════════════════════════════════════════════════════════
--  Wanted System
-- ═══════════════════════════════════════════════════════════════

Config.WantedThreshold = 5   -- unpaid violations before player is flagged wanted

-- ═══════════════════════════════════════════════════════════════
--  Rate Limiting  (max actions per player per 60 seconds)
-- ═══════════════════════════════════════════════════════════════

Config.RateLimits = {
    lookupPlayer        = 30,
    searchPlayer        = 30,
    addViolation        = 10,
    addCriminal         = 10,
    stopServices        =  5,
    issueWarrant        =  5,
    jailPlayer          =  5,
    impoundVehicle      = 10,
    releaseImpound      = 10,
    createReport        = 10,
    createDispatch      = 10,
    payViolation        = 20,
    trackWanted         =  1,
    revokeLicense       =  5,
    buyWeaponLicense    =  3,
    issueVehicleWarning = 10,
}

-- ═══════════════════════════════════════════════════════════════
--  Input Validation Bounds
-- ═══════════════════════════════════════════════════════════════

Config.Validation = {
    maxReasonLength     = 255,
    maxNoteLength       = 500,
    maxDescLength       = 1000,
    maxTitleLength      = 150,
    minViolationAmount  = 100,
    maxViolationAmount  = 50000,
    minServiceDuration  = 5,
    maxServiceDuration  = 2880,    -- 48 hours
    minJailTime         = 1,
    maxJailTime         = 10080,   -- 7 days in minutes
    maxPlateLength      = 10,
    maxImpoundDuration  = 43200,   -- 30 days in minutes (0 = indefinite)
    maxInvolvedPlayers  = 10,
    maxReportTypes      = 50,
}

-- ═══════════════════════════════════════════════════════════════
--  Service Stop Durations
-- ═══════════════════════════════════════════════════════════════

Config.ServiceStopDurations = {
    { label = '15 دقيقة', value = 15   },
    { label = '30 دقيقة', value = 30   },
    { label = 'ساعة',     value = 60   },
    { label = 'ساعتين',   value = 120  },
    { label = '6 ساعات',  value = 360  },
    { label = '12 ساعة',  value = 720  },
    { label = '24 ساعة',  value = 1440 },
    { label = '48 ساعة',  value = 2880 },
}

-- ═══════════════════════════════════════════════════════════════
--  Jail Time Presets
-- ═══════════════════════════════════════════════════════════════

Config.JailDurations = {
    { label = '5 دقائق',   value = 5    },
    { label = '10 دقائق',  value = 10   },
    { label = '15 دقيقة',  value = 15   },
    { label = '30 دقيقة',  value = 30   },
    { label = 'ساعة',      value = 60   },
    { label = '2 ساعة',    value = 120  },
    { label = '4 ساعات',   value = 240  },
    { label = '8 ساعات',   value = 480  },
}

-- ═══════════════════════════════════════════════════════════════
--  Impound Release Time Presets
-- ═══════════════════════════════════════════════════════════════

Config.ImpoundDurations = {
    { label = 'فوري (مع غرامة)',  value = 0    },
    { label = 'ساعة',             value = 60   },
    { label = '6 ساعات',          value = 360  },
    { label = '24 ساعة',          value = 1440 },
    { label = '3 أيام',           value = 4320 },
    { label = '7 أيام',           value = 10080 },
}

-- ═══════════════════════════════════════════════════════════════
--  Violation Reasons
-- ═══════════════════════════════════════════════════════════════

Config.ViolationReasons = {
    'تجاوز السرعة',
    'قطع إشارة',
    'قيادة عكسية',
    'قيادة متهورة',
    'عدم حمل رخصة',
    'وقوف خاطئ',
    'تشويش على الطريق',
    'عدم ربط حزام الأمان',
    'استخدام الجوال أثناء القيادة',
    'مقاومة رجال الأمن',
    'سياقة تحت تأثير',
    'تجاوز تقاطع',
    'مخالفة نظام المرور',
    'قيادة بدون لوحة',
    'سرعة زائدة في منطقة مدرسية',
}

-- ═══════════════════════════════════════════════════════════════
--  Violation Amounts
-- ═══════════════════════════════════════════════════════════════

Config.ViolationAmounts = {
    500, 1000, 2000, 3000, 5000, 10000, 15000, 20000,
}

-- ═══════════════════════════════════════════════════════════════
--  Criminal Charges
-- ═══════════════════════════════════════════════════════════════

Config.CriminalCharges = {
    'سرقة',
    'اعتداء',
    'حيازة مخدرات',
    'ترويج مخدرات',
    'حيازة سلاح بدون ترخيص',
    'قتل',
    'شروع في قتل',
    'تزوير',
    'احتيال',
    'غسيل أموال',
    'إطلاق نار في مناطق عامة',
    'خطف',
    'تهريب',
    'مقاومة اعتقال',
    'هروب من الشرطة',
    'ترهيب وتهديد',
    'انتهاك أمر القضاء',
    'حيازة متفجرات',
    'سطو مسلح',
    'اختراق نظام معلوماتي',
}

-- ═══════════════════════════════════════════════════════════════
--  Warrant Types
-- ═══════════════════════════════════════════════════════════════

Config.WarrantTypes = {
    { value = 'arrest',        label = 'أمر قبض'       },
    { value = 'investigation', label = 'أمر تحقيق'     },
    { value = 'wanted',        label = 'شخص مطلوب'     },
    { value = 'search',        label = 'أمر تفتيش'     },
}

-- ═══════════════════════════════════════════════════════════════
--  Warrant Danger Levels
-- ═══════════════════════════════════════════════════════════════

Config.DangerLevels = {
    { value = 1, label = 'منخفض',      color = '#22c55e' },
    { value = 2, label = 'متوسط',      color = '#f59e0b' },
    { value = 3, label = 'عالٍ',       color = '#ef4444' },
    { value = 4, label = 'خطير جداً',  color = '#991b1b' },
}

-- ═══════════════════════════════════════════════════════════════
--  Report Types
-- ═══════════════════════════════════════════════════════════════

Config.ReportTypes = {
    { value = 'arrest',    label = 'تقرير اعتقال'    },
    { value = 'incident',  label = 'تقرير حادثة'     },
    { value = 'raid',      label = 'تقرير مداهمة'    },
    { value = 'patrol',    label = 'تقرير دورية'     },
    { value = 'traffic',   label = 'تقرير مروري'     },
    { value = 'general',   label = 'تقرير عام'       },
}

-- ═══════════════════════════════════════════════════════════════
--  Dispatch Priorities
-- ═══════════════════════════════════════════════════════════════

Config.DispatchPriorities = {
    { label = 'عادي',  value = 1, color = '#22c55e' },
    { label = 'متوسط', value = 2, color = '#f59e0b' },
    { label = 'عاجل',  value = 3, color = '#ef4444' },
    { label = 'طوارئ', value = 4, color = '#dc2626' },
}

-- ═══════════════════════════════════════════════════════════════
--  Housing Table Integration
--  Adjust table/column names to match your housing script.
--  Set table = '' to disable (if you don't have loaf_housing).
-- ═══════════════════════════════════════════════════════════════

Config.HousingTable = {
    table    = '',  -- 'loaf_housing' — اتركه فارغاً إذا ما عندك جدول العقارات
    ownerCol = 'owner_identifier',
    nameCol  = 'property_name',
}

-- ═══════════════════════════════════════════════════════════════
--  Audit Log Retention (days, 0 = keep forever)
-- ═══════════════════════════════════════════════════════════════

Config.AuditLogRetentionDays = 30

-- ═══════════════════════════════════════════════════════════════
--  Arabic Notifications
-- ═══════════════════════════════════════════════════════════════

Config.Notifications = {
    -- Citizen
    violationAdded      = '⚠️ تم تسجيل مخالفة مرورية جديدة عليك',
    violationPaid       = '✅ تم دفع المخالفة بنجاح',
    allViolationsPaid   = '✅ تم دفع جميع المخالفات بنجاح',
    noMoney             = '❌ لا يوجد رصيد كافٍ في حسابك البنكي',
    servicesStopped     = '🚫 تم إيقاف خدماتك!',
    servicesBlocked     = '🚫 خدماتك موقوفة، لا يمكنك إتمام هذه العملية',
    criminalAdded       = '⚠️ تم تسجيل تهمة جنائية في سجلك',
    warrantIssued       = '🚨 صدر بحقك أمر قانوني، تواصل مع الجهات المختصة',
    jailed              = '🔒 تم إيداعك في مرفق الاحتجاز',
    vehicleImpounded    = '🚗 تم مصادرة مركبتك',
    -- Officer
    notAuthorized       = '❌ ليس لديك صلاحية لتنفيذ هذا الإجراء',
    targetNotFound      = '❌ اللاعب المطلوب غير متصل حالياً',
    wantedAlert         = '🚨 تنبيه: هذا الشخص مطلوب!',
    rateLimited         = '⏳ تجاوزت الحد الأقصى للطلبات، انتظر لحظة',
    invalidInput        = '❌ البيانات المُدخلة غير صالحة',
    dispatchCreated     = '✅ تم إنشاء البلاغ وإرساله للوحدات',
    vehicleAlreadyImpounded = '⚠️ المركبة مصادرة بالفعل',
    reportCreated       = '✅ تم حفظ التقرير بنجاح',
    jailSuccess         = '✅ تم تنفيذ أمر الاحتجاز',
    licenseRevoked      = '⚠️ تم سحب رخصة السلاح الخاصة بك',
    licenseBought       = '✅ تم إصدار رخصة سلاح بنجاح',
    licenseCooldown     = '⏳ لا يمكنك شراء رخصة حالياً، حاول لاحقاً',
    vehicleWarningAdded = '⚠️ تم تسجيل تنبيه على مركبتك',
    vehicleAutoImpound  = '🚫 تم حجز مركبتك تلقائياً بسبب تكرار المخالفات',
    noCoverage          = '❌ لا توجد تغطية في هذه المنطقة',
    trackCooldown       = '⏳ يجب الانتظار قبل التتبع مرة أخرى',
}

-- ═══════════════════════════════════════════════════════════════
--  Search System
-- ═══════════════════════════════════════════════════════════════

Config.NearestPlayerRadius = 10.0   -- meters

-- ═══════════════════════════════════════════════════════════════
--  Dash Cam System
-- ═══════════════════════════════════════════════════════════════

Config.DashCamItem           = 'bread'
Config.DashCamUpdateInterval = 10000  -- ms between position updates

-- ═══════════════════════════════════════════════════════════════
--  Surveillance Cameras (store robbery alerts)
-- ═══════════════════════════════════════════════════════════════

Config.CameraLogRetention = 72  -- hours

Config.CameraLocations = {
    { id = 'liqour_robbery',    name = 'بقالة الشارع الرئيسي' },
    { id = 'bank_pacific',      name = 'بنك باسيفيك'          },
    { id = 'jewelery_store',    name = 'محل المجوهرات'         },
    { id = 'vangelico',         name = 'فانجيليكو'             },
    { id = 'fleeca_bank',       name = 'بنك فليكا'             },
    { id = 'paleto_bank',       name = 'بنك باليتو'            },
}

Config.CameraGroups = {

    -- ══════════════════════════════════════════════════
    --  A - داون تاون لوس سانتوس (Downtown LS)
    -- ══════════════════════════════════════════════════
    {
        label = 'وسط لوس سانتوس',
        id    = 'downtown',
        cameras = {
            { label = 'تقاطع ركفورد',       x = -103.94, y = -637.27,  z = 38.15,  rx = -25.0, ry = 0.0, rz = 270.0,   canRotate = true },
            { label = 'شارع ويناك',          x = 131.64,  y = -644.99,  z = 44.01,  rx = -25.0, ry = 0.0, rz = 90.0,    canRotate = true },
            { label = 'أمام المحكمة',        x = -513.71, y = -601.38,  z = 34.87,  rx = -25.0, ry = 0.0, rz = 350.0,   canRotate = true },
            { label = 'شارع عمادور',         x = -319.29, y = -684.25,  z = 32.5,   rx = -25.0, ry = 0.0, rz = 180.0,   canRotate = true },
            { label = 'ميدان مازيندا',       x = -420.8,  y = -788.11,  z = 30.5,   rx = -30.0, ry = 0.0, rz = 90.0,    canRotate = true },
            { label = 'برج مازندا',          x = -365.15, y = -841.4,   z = 59.0,   rx = -20.0, ry = 0.0, rz = 45.0,    canRotate = true },
            { label = 'المركز التجاري',      x = -679.81, y = -822.32,  z = 32.0,   rx = -25.0, ry = 0.0, rz = 270.0,   canRotate = true },
            { label = 'شارع بورت مين',       x = -812.45, y = -1046.7,  z = 23.5,   rx = -25.0, ry = 0.0, rz = 180.0,   canRotate = true },
        },
    },

    -- ══════════════════════════════════════════════════
    --  B - البنك المركزي (Maze Bank)
    -- ══════════════════════════════════════════════════
    {
        label = 'البنك المركزي',
        id    = 'bank',
        cameras = {
            { label = 'كاميرا بنك 1',   x = 232.86,  y = 221.46,  z = 107.83, rx = -25.0, ry = 0.0, rz = -140.91, canRotate = true },
            { label = 'كاميرا بنك 2',   x = 257.45,  y = 210.07,  z = 109.08, rx = -25.0, ry = 0.0, rz = 28.05,   canRotate = true },
            { label = 'كاميرا بنك 3',   x = 261.50,  y = 218.08,  z = 107.95, rx = -25.0, ry = 0.0, rz = -149.49, canRotate = true },
            { label = 'كاميرا بنك 4',   x = 241.64,  y = 233.83,  z = 111.48, rx = -35.0, ry = 0.0, rz = 120.46,  canRotate = true },
            { label = 'كاميرا بنك 5',   x = 269.66,  y = 223.67,  z = 113.23, rx = -30.0, ry = 0.0, rz = 111.29,  canRotate = true },
            { label = 'كاميرا بنك 6',   x = 261.98,  y = 217.92,  z = 113.25, rx = -40.0, ry = 0.0, rz = -159.49, canRotate = true },
            { label = 'كاميرا بنك 7',   x = 258.44,  y = 204.97,  z = 113.25, rx = -30.0, ry = 0.0, rz = 10.50,   canRotate = true },
            { label = 'كاميرا بنك 8',   x = 235.53,  y = 227.37,  z = 113.23, rx = -35.0, ry = 0.0, rz = -160.29, canRotate = true },
            { label = 'كاميرا بنك 9',   x = 254.72,  y = 206.06,  z = 113.28, rx = -35.0, ry = 0.0, rz = 44.70,   canRotate = true },
            { label = 'كاميرا بنك 10',  x = 269.89,  y = 223.76,  z = 106.48, rx = -35.0, ry = 0.0, rz = 112.62,  canRotate = true },
            { label = 'كاميرا بنك 11',  x = 252.27,  y = 225.52,  z = 103.99, rx = -35.0, ry = 0.0, rz = -74.87,  canRotate = true },
        },
    },

    -- ══════════════════════════════════════════════════
    --  C - مراكز الشرطة (Police Stations)
    -- ══════════════════════════════════════════════════
    {
        label = 'مراكز الشرطة',
        id    = 'police',
        cameras = {
            { label = 'مركز المدينة 1',       x = 416.744, y = -1009.270, z = 34.08,  rx = -25.0, ry = 0.0, rz = 28.05,  canRotate = true },
            { label = 'مركز المدينة 2',       x = 465.151, y = -994.266,  z = 27.23,  rx = -30.0, ry = 0.0, rz = 100.29, canRotate = true },
            { label = 'مركز المدينة 3',       x = 465.631, y = -997.777,  z = 27.48,  rx = -35.0, ry = 0.0, rz = 90.46,  canRotate = true },
            { label = 'مركز المدينة 4',       x = 465.544, y = -1001.583, z = 27.1,   rx = -25.0, ry = 0.0, rz = 90.01,  canRotate = true },
            { label = 'مركز المدينة 5',       x = 420.241, y = -1009.010, z = 34.95,  rx = -25.0, ry = 0.0, rz = 230.95, canRotate = true },
            { label = 'مركز المدينة 6',       x = 433.249, y = -977.786,  z = 33.456, rx = -40.0, ry = 0.0, rz = 100.49, canRotate = true },
            { label = 'مركز المدينة 7',       x = 449.440, y = -987.639,  z = 33.25,  rx = -30.0, ry = 0.0, rz = 50.50,  canRotate = true },
            { label = 'مركز ساندي شورز',      x = 1872.11, y = 3680.31,   z = 38.45,  rx = -30.0, ry = 0.0, rz = 207.14, canRotate = true },
            { label = 'نقطة بليتو باي',       x = 1385.98, y = 6455.31,   z = 29.85,  rx = -30.0, ry = 0.0, rz = 262.15, canRotate = true },
            { label = 'كراج الرس سانتس',      x = 218.27,  y = -1459.33,  z = 36.14,  rx = -30.0, ry = 0.0, rz = 348.65, canRotate = true },
            { label = 'تنظيف حجر',            x = 273.18,  y = 2836.73,   z = 52.93,  rx = -30.0, ry = 0.0, rz = 323.48, canRotate = true },
            { label = 'مركز ديفيس',           x = 373.87,  y = -1612.08,  z = 29.29,  rx = -25.0, ry = 0.0, rz = 180.0,  canRotate = true },
        },
    },

    -- ══════════════════════════════════════════════════
    --  D - الميناء البحري (Port of LS)
    -- ══════════════════════════════════════════════════
    {
        label = 'الميناء البحري',
        id    = 'seeport',
        cameras = {
            { label = 'تفتيش (G1)',         x = 707.95,  y = -2766.8,   z = 13.21,  rx = -25.0, ry = 0.0, rz = 195.04, canRotate = true  },
            { label = 'تفتيش (T3)',         x = 1267.68, y = -3082.06,  z = 29.81,  rx = -25.0, ry = 0.0, rz = 86.41,  canRotate = true  },
            { label = 'تفتيش (G2)',         x = 1151.94, y = -3337.81,  z = 29.81,  rx = -25.0, ry = 0.0, rz = 83.4,   canRotate = true  },
            { label = 'المستودع العام',      x = 776.63,  y = -3235.38,  z = 17.52,  rx = -25.0, ry = 0.0, rz = 274.24, canRotate = true  },
            { label = 'المركز (C1)',        x = 754.94,  y = -3034.7,   z = 28.3,   rx = -25.0, ry = 0.0, rz = 352.24, canRotate = true  },
            { label = 'نقطة تصدير',         x = 857.36,  y = -2963.77,  z = 28.3,   rx = -25.0, ry = 0.0, rz = 286.23, canRotate = true  },
            { label = 'نقطة التفتيش',       x = 702.08,  y = -2771.74,  z = 9.49,   rx = -25.0, ry = 0.0, rz = 225.45, canRotate = true  },
            { label = 'نقطة المراقبة 1',    x = 720.18,  y = -2855.96,  z = 9.41,   rx = -25.0, ry = 0.0, rz = 351.77, canRotate = false },
            { label = 'نقطة G2',            x = 1020.47, y = -3238.15,  z = 29.99,  rx = -25.0, ry = 0.0, rz = 6.76,   canRotate = true  },
            { label = 'البوابة الرئيسية',   x = 731.77,  y = -2626.97,  z = 21.5,   rx = -25.0, ry = 0.0, rz = 359.54, canRotate = false },
        },
    },

    -- ══════════════════════════════════════════════════
    --  E - المطار الدولي (LSIA)
    -- ══════════════════════════════════════════════════
    {
        label = 'المطار الدولي',
        id    = 'airport',
        cameras = {
            { label = 'المدرج الرئيسي',      x = -1085.0, y = -2821.0,  z = 15.0,  rx = -25.0, ry = 0.0, rz = 270.0,  canRotate = true },
            { label = 'صالة المغادرة',       x = -974.43, y = -2919.06, z = 14.63, rx = -20.0, ry = 0.0, rz = 180.0,  canRotate = true },
            { label = 'البوابة الرئيسية',    x = -1037.0, y = -2738.0,  z = 20.17, rx = -25.0, ry = 0.0, rz = 90.0,   canRotate = true },
            { label = 'منطقة الشحن',         x = -886.53, y = -3015.0,  z = 13.94, rx = -25.0, ry = 0.0, rz = 0.0,    canRotate = true },
            { label = 'موقف السيارات',        x = -850.0,  y = -2839.0,  z = 15.1,  rx = -25.0, ry = 0.0, rz = 270.0,  canRotate = true },
            { label = 'برج المراقبة',        x = -1251.7, y = -2985.7,  z = 20.7,  rx = -20.0, ry = 0.0, rz = 45.0,   canRotate = true },
        },
    },

    -- ══════════════════════════════════════════════════
    --  F - ديفيس / ساوث لوس سانتوس (Davis - South LS)
    -- ══════════════════════════════════════════════════
    {
        label = 'ديفيس وجنوب المدينة',
        id    = 'davis',
        cameras = {
            { label = 'شارع ديفيس',          x = 90.43,   y = -1619.29, z = 29.3,  rx = -25.0, ry = 0.0, rz = 270.0, canRotate = true },
            { label = 'ملعب فوروم',           x = 167.65,  y = -1736.0,  z = 29.5,  rx = -25.0, ry = 0.0, rz = 90.0,  canRotate = true },
            { label = 'وصلة ليتل سيول',      x = -594.91, y = -1354.87, z = 30.6,  rx = -25.0, ry = 0.0, rz = 180.0, canRotate = true },
            { label = 'مستشفى ديل بيرو',      x = -878.48, y = -1468.63, z = 23.93, rx = -25.0, ry = 0.0, rz = 90.0,  canRotate = true },
            { label = 'مصنع فوورتايد',        x = 1188.06, y = -1410.14, z = 35.22, rx = -25.0, ry = 0.0, rz = 270.0, canRotate = true },
            { label = 'كيلي سيتي بلازا',      x = 825.26,  y = -1389.3,  z = 28.37, rx = -25.0, ry = 0.0, rz = 0.0,   canRotate = true },
        },
    },

    -- ══════════════════════════════════════════════════
    --  G - فيسبوتشي / شاطئ المحيط (Vespucci Beach)
    -- ══════════════════════════════════════════════════
    {
        label = 'شاطئ فيسبوتشي',
        id    = 'beach',
        cameras = {
            { label = 'الكورنيش الرئيسي',    x = -1335.13, y = -1278.52, z = 6.73,  rx = -20.0, ry = 0.0, rz = 270.0, canRotate = true },
            { label = 'أمام مركز الإنقاذ',  x = -1200.21, y = -1506.2,  z = 4.95,  rx = -20.0, ry = 0.0, rz = 0.0,   canRotate = true },
            { label = 'مرفأ القوارب',        x = -805.0,   y = -1450.0,  z = 6.0,   rx = -25.0, ry = 0.0, rz = 90.0,  canRotate = true },
            { label = 'شارع ديل بيرو',       x = -700.73,  y = -970.53,  z = 19.22, rx = -25.0, ry = 0.0, rz = 180.0, canRotate = true },
        },
    },

    -- ══════════════════════════════════════════════════
    --  H - ويستون / روكفورد هيلز (Rockford Hills)
    -- ══════════════════════════════════════════════════
    {
        label = 'ركفورد هيلز',
        id    = 'rockford',
        cameras = {
            { label = 'شارع بوهارد',          x = -1283.85, y = -411.37,  z = 36.65, rx = -25.0, ry = 0.0, rz = 0.0,   canRotate = true },
            { label = 'الحي الراقي',           x = -779.47,  y = 303.3,    z = 85.7,  rx = -25.0, ry = 0.0, rz = 270.0, canRotate = true },
            { label = 'شارع آيدلوود',          x = -464.68,  y = 266.0,    z = 81.6,  rx = -25.0, ry = 0.0, rz = 180.0, canRotate = true },
            { label = 'مدخل منطقة فاينوود',    x = -1194.3,  y = -182.44,  z = 44.15, rx = -25.0, ry = 0.0, rz = 90.0,  canRotate = true },
        },
    },

    -- ══════════════════════════════════════════════════
    --  I - بوليس / ميشيكا (Bolingbroke / Banning)
    -- ══════════════════════════════════════════════════
    {
        label = 'ترمينال وبوليغبروك',
        id    = 'terminal',
        cameras = {
            { label = 'مدخل السجن',          x = 1685.82, y = 2580.37, z = 45.56, rx = -25.0, ry = 0.0, rz = 270.0, canRotate = true },
            { label = 'ساحة السجن',          x = 1843.94, y = 2596.19, z = 45.97, rx = -20.0, ry = 0.0, rz = 180.0, canRotate = true },
            { label = 'بوابة خروج السجن',    x = 1845.28, y = 2632.49, z = 45.67, rx = -20.0, ry = 0.0, rz = 0.0,   canRotate = true },
            { label = 'بانينج الصناعية',      x = 649.75,  y = -2385.59, z = 6.0,  rx = -25.0, ry = 0.0, rz = 90.0,  canRotate = true },
            { label = 'محطة تيرمينال',        x = 543.74,  y = -2540.69, z = 6.97, rx = -25.0, ry = 0.0, rz = 270.0, canRotate = true },
        },
    },

    -- ══════════════════════════════════════════════════
    --  J - ساندي شورز / مقاطعة بلاين (Sandy Shores / Blaine County)
    -- ══════════════════════════════════════════════════
    {
        label = 'ساندي شورز',
        id    = 'sandy',
        cameras = {
            { label = 'شارع ساندي الرئيسي',   x = 2011.14, y = 3794.16, z = 32.7,  rx = -25.0, ry = 0.0, rz = 270.0, canRotate = true },
            { label = 'محطة وقود ساندي',      x = 1697.03, y = 4924.52, z = 42.06, rx = -25.0, ry = 0.0, rz = 180.0, canRotate = true },
            { label = 'مطار ساندي',           x = 1766.39, y = 3225.66, z = 41.72, rx = -25.0, ry = 0.0, rz = 0.0,   canRotate = true },
            { label = 'لاساميسا',             x = 2943.19, y = 2820.47, z = 66.29, rx = -25.0, ry = 0.0, rz = 90.0,  canRotate = true },
            { label = 'منطقة تشومباش',        x = 2680.37, y = 3280.94, z = 55.24, rx = -25.0, ry = 0.0, rz = 180.0, canRotate = true },
            { label = 'مشارف بلاين',          x = 3007.68, y = 3663.65, z = 33.7,  rx = -25.0, ry = 0.0, rz = 270.0, canRotate = true },
        },
    },

    -- ══════════════════════════════════════════════════
    --  K - بليتو باي (Paleto Bay)
    -- ══════════════════════════════════════════════════
    {
        label = 'بليتو باي',
        id    = 'paleto',
        cameras = {
            { label = 'شارع بليتو الرئيسي',  x = -288.3,  y = 6245.47, z = 31.47, rx = -25.0, ry = 0.0, rz = 90.0,  canRotate = true },
            { label = 'محطة وقود بليتو',     x = -73.47,  y = 6263.08, z = 31.49, rx = -25.0, ry = 0.0, rz = 0.0,   canRotate = true },
            { label = 'كنيسة بليتو',         x = -489.37, y = 6224.97, z = 31.47, rx = -25.0, ry = 0.0, rz = 270.0, canRotate = true },
            { label = 'مصرف بليتو',          x = -101.34, y = 6472.14, z = 31.63, rx = -25.0, ry = 0.0, rz = 180.0, canRotate = true },
            { label = 'مدخل بليتو الشمالي', x = 163.78,  y = 6626.8,  z = 31.58, rx = -25.0, ry = 0.0, rz = 0.0,   canRotate = true },
        },
    },

    -- ══════════════════════════════════════════════════
    --  L - جبال تشيلياد (Mount Chiliad)
    -- ══════════════════════════════════════════════════
    {
        label = 'جبال تشيلياد',
        id    = 'chiliad',
        cameras = {
            { label = 'قمة الجبل',           x = 501.72,  y = 5603.71, z = 797.92, rx = -20.0, ry = 0.0, rz = 180.0, canRotate = true },
            { label = 'تله التلفريك',        x = 2072.23, y = 5171.53, z = 2.17,   rx = -20.0, ry = 0.0, rz = 270.0, canRotate = true },
            { label = 'كهف تشيلياد',         x = -21.7,   y = 5302.32, z = 159.48, rx = -15.0, ry = 0.0, rz = 180.0, canRotate = true },
            { label = 'طريق الجبل الجنوبي',  x = 427.25,  y = 5374.12, z = 469.83, rx = -25.0, ry = 0.0, rz = 90.0,  canRotate = true },
        },
    },

    -- ══════════════════════════════════════════════════
    --  M - منطقة كايو بيريكو (Cayo Perico)
    -- ══════════════════════════════════════════════════
    {
        label = 'كايو بيريكو',
        id    = 'cayo',
        cameras = {
            { label = 'مدخل الجزيرة',        x = 4929.69, y = -5194.78, z = 5.14,  rx = -20.0, ry = 0.0, rz = 180.0, canRotate = true },
            { label = 'القصر الرئيسي',       x = 4712.83, y = -5135.07, z = 8.27,  rx = -20.0, ry = 0.0, rz = 90.0,  canRotate = true },
            { label = 'المرفأ',              x = 5055.53, y = -5499.44, z = 4.24,  rx = -20.0, ry = 0.0, rz = 0.0,   canRotate = true },
            { label = 'برج الاتصالات',       x = 4573.76, y = -4784.31, z = 66.38, rx = -20.0, ry = 0.0, rz = 270.0, canRotate = true },
        },
    },

    -- ══════════════════════════════════════════════════
    --  N - محطات الوقود والطرق السريعة
    -- ══════════════════════════════════════════════════
    {
        label = 'الطرق السريعة',
        id    = 'highways',
        cameras = {
            { label = 'طريق سريع 1 (شمال)',  x = -2120.88, y = 4299.12, z = 46.67, rx = -25.0, ry = 0.0, rz = 90.0,  canRotate = true },
            { label = 'طريق سريع 1 (جنوب)', x = -2108.5,  y = 2793.57, z = 33.83, rx = -25.0, ry = 0.0, rz = 90.0,  canRotate = true },
            { label = 'طريق 68 — وسط',       x = 986.16,   y = 3582.81, z = 59.28, rx = -25.0, ry = 0.0, rz = 0.0,   canRotate = true },
            { label = 'جسر لوس سانتوس',      x = -1038.16, y = -1696.04, z = 6.56, rx = -20.0, ry = 0.0, rz = 270.0, canRotate = true },
            { label = 'وصلة بين المدن',       x = 2559.72, y = 408.87,   z = 108.6, rx = -25.0, ry = 0.0, rz = 180.0, canRotate = true },
        },
    },
}

-- ═══════════════════════════════════════════════════════════════
--  Shops Table (البقالات) — يظهر في قسم "العنوان الوطني" لأبشر
--
--  ⚠️  عند restart الريسورس سيطبع الكونسول أسماء الأعمدة الفعلية
--     لجدول owned_shops — انسخ الاسم الصحيح هنا في nameCol.
--
--  اتركه فارغاً table = '' لتعطيله إن لم يكن لديك جدول بقالات.
-- ═══════════════════════════════════════════════════════════════

Config.ShopsTable = {
    table     = 'owned_shops',
    ownerCol  = 'identifier',   -- عمود هوية المالك
    nameCol   = 'ShopName',     -- اسم البقالة
}

-- ═══════════════════════════════════════════════════════════════
--  Weapon License System
-- ═══════════════════════════════════════════════════════════════

Config.WeaponLicensePrice    = 100000
Config.WeaponLicenseCooldown = 86400  -- 24 hours in seconds

-- ═══════════════════════════════════════════════════════════════
--  Tablet Animation
-- ═══════════════════════════════════════════════════════════════

Config.TabletAnimDict = 'amb@code_human_in_bus_passenger_idles@female@tablet@base'
Config.TabletAnimName = 'base'
Config.TabletProp     = 'prop_cs_tablet'
Config.TabletBone     = 60309  -- SKEL_R_Hand

-- ═══════════════════════════════════════════════════════════════
--  Wanted Person Tracking
-- ═══════════════════════════════════════════════════════════════

Config.TrackingCooldown      = 60  -- seconds between tracks per officer
Config.TrackingBlipDuration  = 90  -- seconds before the map blip disappears automatically

-- ═══════════════════════════════════════════════════════════════
--  Vehicles Table  (used for plate lookup / vehicle scan)
--  Adjust column names if your ESX framework uses different ones.
-- ═══════════════════════════════════════════════════════════════
Config.VehiclesTable = {
    table    = 'owned_vehicles',
    ownerCol = 'owner',     -- identifier column
    plateCol = 'plate',     -- license plate column
    nameCol  = 'name',      -- display name / label column
}

Config.TrackingCoverageZones = {
    {
        name = 'لوس سانتوس',
        polygon = {
            vector2(5366.62, 887.6909),
            vector2(-3711.224, 892.96),
            vector2(-3744.5549, -3909.158),
            vector2(4021.0032, -3934.0510),
        },
    },
    {
        name = 'ساندي شورز',
        polygon = {
            vector2(5366.62, 887.6909),
            vector2(-3711.224, 892.96),
            vector2(-3242.051, 8333.243),
            vector2(5478.356, 8008.492),
        },
    },
    {
        name = 'باليتو',
        polygon = {
            vector2(225.8359, 7089.1094),
            vector2(-1646.6482, 6060.1533),
            vector2(-493.3616, 5029.7607),
            vector2(773.9641, 6459.2900),
        },
    },
    {
        name = 'ساندي - باليتو',
        polygon = {
            vector2(-798.8937, 5474.1001),
            vector2(-1030.2102, 6320.7490),
            vector2(341.1722, 7585.8545),
            vector2(1416.3209, 6767.1758),
            vector2(3290.6494, 6692.6084),
            vector2(4273.7715, 2125.0244),
            vector2(-364.8018, 2055.5068),
            vector2(-292.4038, 2927.7607),
            vector2(-60.1680, 3819.0576),
            vector2(134.9663, 5100.5059),
        },
    },
    {
        name = 'كايو بيريكو',
        polygon = {
            vector2(2900.3398, -4106.9873),
            vector2(3646.1626, -6156.999),
            vector2(6583.7627, -5482.4258),
            vector2(5105.5293, -3125.8301),
        },
    },
}

-- ═══════════════════════════════════════════════════════════════
--  Vehicle Warning System
-- ═══════════════════════════════════════════════════════════════

Config.VehicleWarningThreshold = 3  -- warnings before auto-impound

Config.VehicleWarningTypes = {
    { id = 'tinting',       label = 'تضليل زجاج'       },
    { id = 'illegal_mod',   label = 'تعديل غير نظامي'   },
    { id = 'exhaust',       label = 'عادم مخالف'        },
    { id = 'no_plate',      label = 'بدون لوحة'         },
    { id = 'damage',        label = 'أضرار خطيرة'       },
    { id = 'expired_reg',   label = 'تسجيل منتهي'       },
    { id = 'other',         label = 'أخرى'              },
}

-- ═══════════════════════════════════════════════════════════════
--  رخص الأسلحة الفردية — كل سلاح يحتاج رخصة مستقلة
--
--  • type   = معرّف الرخصة (مخزون في قاعدة البيانات)
--  • label  = الاسم العربي في الواجهة
--  • price  = السعر بالريال
--  • icon   = أيقونة Font Awesome (بدون fas fa-)
-- ═══════════════════════════════════════════════════════════════

Config.WeaponItemLicenses = {
    { type = 'shotgun',      label = 'شوزن',              price = 90000,  icon = 'gun'        },
    { type = 'sawnoff',      label = 'شوزن مصغر',         price = 80000,  icon = 'gun'        },
    { type = 'drumshot',     label = 'رشاش دروم جون',      price = 125000, icon = 'gun'        },
    { type = 'smg',          label = 'رشاش أس ام جي',      price = 125000, icon = 'gun'        },
    { type = 'huntingrifle', label = 'بندقية صيد',         price = 70000,  icon = 'crosshairs' },
    { type = 'assaultrifle', label = 'رشاش رايفل',         price = 225000, icon = 'gun'        },
    { type = 'carbine',      label = 'رشاش ألي',           price = 225000, icon = 'gun'        },
    { type = 'akm',          label = 'رشاش أي كي ام',      price = 225000, icon = 'gun'        },
    { type = 'combatsmg',    label = 'أس ام جي كومبات',    price = 225000, icon = 'gun'        },
    { type = 'carbine2',     label = 'رشاش كلاش',          price = 225000, icon = 'gun'        },
    { type = 'microsmg',     label = 'مايكو',              price = 160000, icon = 'gun'        },
    { type = 'heavypistol',  label = 'مسدس أبو محالة',     price = 200000, icon = 'gun'        },
    { type = 'sniper',       label = 'بندقية قنص',         price = 375000, icon = 'crosshairs' },
}

-- ═══════════════════════════════════════════════════════════════
--  رخص القيادة — الرخص التي تظهر في باشر وأبشر
--
--  • type  = اسم الرخصة في جدول user_licenses (عمود type)
--  • label = الاسم العربي الذي يظهر في الواجهة
--  • icon  = أيقونة Font Awesome (بدون fas fa-)
--
--  أضف أو احذف حسب الرخص الموجودة في سيرفرك
-- ═══════════════════════════════════════════════════════════════

Config.LicenseTypes = {
    { type = 'drive',    label = 'رخصة قيادة سيارة',     icon = 'car'            },
    { type = 'weapon',    label = 'رخصة حمل سلاح',        icon = 'gun'            },
    { type = 'business',  label = 'رخصة تجارية',           icon = 'store'          },
    { type = 'hunting',   label = 'رخصة صيد بري',          icon = 'bullseye'       },
    { type = 'fishing',   label = 'رخصة صيد سمك',          icon = 'fish'           },
    { type = 'pilot',     label = 'رخصة طيران',            icon = 'plane'          },
    { type = 'boat',      label = 'رخصة قيادة قارب',       icon = 'ship'           },
}


