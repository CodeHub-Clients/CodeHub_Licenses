-- ═══════════════════════════════════════════════════════════════
--  YB MDT  |  Private Server-Side Configuration
--  ⚠️  هذا الملف server_script فقط — لا يصل إليه الكلاينت أبداً
--  ضع هنا أي بيانات حساسة: ويب هوك, توكن, مفاتيح API
-- ═══════════════════════════════════════════════════════════════

-- ─────────────────────────────────────────────────────────────
--  Discord Webhook URLs
--  'general' يُستخدم كـ fallback لو الكاتيجوري فارغ
-- ─────────────────────────────────────────────────────────────
Config.DiscordWebhooks = {
    general    = '',
    violations = '',
    jail       = '',
    warrants   = '',
    impound    = '',
    services   = '',
    reports    = '',
    licenses   = '',
    warnings   = '',
    cameras    = '',
}

Config.DiscordBotName   = 'YB MDT'
Config.DiscordBotAvatar = ''

-- ─────────────────────────────────────────────────────────────
--  Discord Bot Token (لجلب صور البروفايل)
--  اتركه فارغاً لو ما تبي صور ديسكورد
-- ─────────────────────────────────────────────────────────────
Config.DiscordBotToken = ''
