fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'CodeHub Team'
description 'Starter Pack / Onboarding wizard (ESX + ox_inventory)'
version '2.1.0'

shared_scripts {
    'config.lua',
    'shared/framework.lua',
}

client_scripts {
    'editable/client.lua',
    'client/main.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'editable/server.lua',
    'server/promo.lua',
    'server/main.lua',
}

ui_page 'nui/index.html'

files {
    'nui/index.html',
    'nui/**/*',
}

dependencies {
    'oxmysql',
}

escrow_ignore {
    'config.lua',
    'editable/server.lua',
    'editable/client.lua',
    'sql/install.sql',
}
