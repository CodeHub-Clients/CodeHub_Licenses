CREATE TABLE IF NOT EXISTS `starter_pack_claims` (
    `identifier` VARCHAR(64) NOT NULL,
    `claimed` TINYINT(1) NOT NULL DEFAULT 1,
    `vehicles` LONGTEXT NULL,
    `claimed_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `starter_promo_codes` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `code` VARCHAR(50) NOT NULL UNIQUE,
    `creator_name` VARCHAR(100) NOT NULL,
    `extra_cash` INT DEFAULT 0,
    `extra_bank` INT DEFAULT 0,
    `extra_xp` INT DEFAULT 0,
    `custom_vehicle` VARCHAR(50) NULL,
    `custom_item` VARCHAR(50) NULL,
    `item_count` INT DEFAULT 1,
    `vehicle_label` VARCHAR(100) NULL,
    `vehicle_garage` VARCHAR(50) NULL,
    `vehicle_type` VARCHAR(20) NULL,
    `usage_count` INT DEFAULT 0,
    `max_uses` INT DEFAULT -1,
    `is_active` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `starter_code_redemptions` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `code_id` INT NOT NULL,
    `player_identifier` VARCHAR(64) NOT NULL,
    `player_name` VARCHAR(100) NOT NULL,
    `redeemed_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uniq_code_player` (`code_id`, `player_identifier`),
    FOREIGN KEY (`code_id`) REFERENCES `starter_promo_codes`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
