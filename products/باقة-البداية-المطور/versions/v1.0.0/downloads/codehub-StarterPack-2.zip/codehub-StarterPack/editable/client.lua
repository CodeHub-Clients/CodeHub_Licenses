--[[
    Starter Pack — ملف كلاينت مفتوح (لا يُشفَّر)
]]

Editable = Editable or {}

function Editable.Notify(message, nType)
    nType = nType or 'inform'

    if GetResourceState('ox_lib') == 'started' then
        exports.ox_lib:notify({
            description = message,
            type = nType,
        })
        return
    end

    TriggerEvent('esx:showNotification', message)
end
