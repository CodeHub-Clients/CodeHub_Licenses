Editable = Editable or {}

local function identifierOf(player)
    return Framework.GetIdentifier(player)
end

--- فلوس: cash / bank / black_money
function Editable.GiveMoney(src, player, account, amount)
    Framework.AddMoney(player, account, amount)
end

--- أيتم
function Editable.GiveItem(src, player, name, count)
    return Framework.AddItem(src, player, name, count)
end

--- سلاح
function Editable.GiveWeapon(src, player, name, ammo)
    return Framework.AddWeapon(src, player, name, ammo)
end

--- خبرة البداية من Config.Rewards.xp
function Editable.GiveXP(src, player, rewards, xpCfg)
    xpCfg = xpCfg or (rewards and rewards.xp) or {}
    if type(xpCfg) ~= 'table' then
        xpCfg = { enabled = true, amount = tonumber(xpCfg) or 0, addType = 'add' }
    end

    if xpCfg.enabled == false then
        return 0
    end

    local targetXP = tonumber(xpCfg.amount or xpCfg.xp or xpCfg.targetXP) or 0
    local amount = targetXP
    local addType = xpCfg.addType or 'add'

    -- addnoduble: يرفع اللاعب إلى هذا الـ XP / المستوى إذا كان أقل
    if addType == 'addnoduble' or addType == 'addNoduble' or addType == 'noduble' then
        local current = Framework.GetXP(player)
        if current >= targetXP then
            return 0
        end
        amount = targetXP - current
    end

    if amount <= 0 then
        return 0
    end

    local eventName = xpCfg.eventName
    if not eventName or eventName == '' then
        eventName = 'codehub-Level:updateCurrentPlayerXP'
    end

    TriggerEvent(
        eventName,
        src,
        addType,
        amount,
        xpCfg.reason or 'باقة البداية',
        xpCfg.sourceLabel or 'starter_pack'
    )

    return amount
end

--- ضعف الخبرة من خيار buff في Config.Categories
function Editable.GiveDoubleXP(src, player, hours, option)
    hours = tonumber(hours) or 0
    if hours <= 0 then
        return false
    end

    local id = identifierOf(player)
    local minutes = math.floor(hours * 60)

    if GetResourceState('esx_misc') == 'started' then
        exports['esx_misc']:givePlayerDoubleXP(id, minutes)
        return true
    end

    TriggerEvent('codehub-Level:GiveStoreDoubleXP', src, hours)
    return true
end

--- إدخال مركبة لكراج ESX (owned_vehicles)
function Editable.GiveVehicle(src, player, option, plate)
    if not option or not option.model or option.model == '' then
        return nil
    end

    plate = plate or option.plate
    local identifier = identifierOf(player)
    local hash = joaat(option.model)
    local vehicleProps = {
        model = hash,
        plate = plate,
    }
    local vehicleJson = json.encode(vehicleProps)
    local vtype = option.vtype or 'car'
    local job = 'civ'
    local name = option.label or option.name or option.model
    local garage = option.garage or (Config.Garage and Config.Garage.garage) or 'central'
    local stored = (Config.Garage and Config.Garage.stored) or 1

    MySQL.insert.await([[
        INSERT INTO owned_vehicles (owner, plate, vehicle, type, stored, job, name, modelname, garage)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ]], { identifier, plate, vehicleJson, vtype, stored, job, name, option.model, garage })

    return plate
end

--[[
    أي type غير معروف (أو تبي تعالجه بنفسك) يجي هنا.
    مثال في config:
        type = 'vip'
        options = { { id = 'gold', label = 'عضوية ذهبية', days = 30 } }

    function Editable.GiveCustom(src, player, option, optionType)
        if optionType == 'vip' then
            exports['my_vip']:Give(src, option.days)
            return true
        end
        if optionType == 'house' then
            exports['my_housing']:GiveStarter(src, option.house)
            return true
        end
        return false
    end
]]
function Editable.GiveCustom(src, player, option, optionType)
    -- أضف أنواعك هنا
    return false
end

--- نقطة الدخول لكل خيار يختاره اللاعب
function Editable.GiveOption(src, player, option, optionType, plate)
    optionType = optionType or 'vehicle'

    if optionType == 'vehicle' then
        return Editable.GiveVehicle(src, player, option, plate)
    end

    if optionType == 'item' then
        return Editable.GiveItem(src, player, option.name or option.id, option.count or 1)
    end

    if optionType == 'weapon' then
        return Editable.GiveWeapon(src, player, option.name or option.weapon or option.id, option.ammo or option.count or 50)
    end

    if optionType == 'buff' or optionType == 'doublexp' then
        return Editable.GiveDoubleXP(src, player, option.hours or option.duration, option)
    end

    return Editable.GiveCustom(src, player, option, optionType)
end

--- مكافآت كود المبدع / الإحالة (تُستدعى بعد مكافآت الباقة)
function Editable.GivePromoRewards(src, player, promo, plate)
    if type(promo) ~= 'table' then
        return
    end

    local cash = tonumber(promo.extra_cash) or 0
    local bank = tonumber(promo.extra_bank) or 0
    local xp = tonumber(promo.extra_xp) or 0
    local vehicle = promo.custom_vehicle
    local item = promo.custom_item
    local itemCount = tonumber(promo.item_count) or 1

    if cash > 0 then
        Editable.GiveMoney(src, player, 'cash', cash)
    end

    if bank > 0 then
        Editable.GiveMoney(src, player, 'bank', bank)
    end

    if xp > 0 then
        local xpCfg = (Config.Rewards and Config.Rewards.xp) or {}
        local eventName = xpCfg.eventName
        if not eventName or eventName == '' then
            eventName = 'codehub-Level:updateCurrentPlayerXP'
        end

        TriggerEvent(
            eventName,
            src,
            'add',
            xp,
            ('كود مبدع: %s'):format(promo.code or promo.creator_name or ''),
            'starter_promo'
        )
    end

    if type(vehicle) == 'string' and vehicle ~= '' then
        Editable.GiveVehicle(src, player, {
            model = vehicle,
            label = promo.vehicle_label or vehicle,
            vtype = promo.vehicle_type or 'car',
            garage = promo.vehicle_garage,
        }, plate)
    end

    if type(item) == 'string' and item ~= '' then
        Editable.GiveItem(src, player, item, math.max(1, itemCount))
    end
end

--- بعد تسليم كل شيء (لوغ / ديسكورد / رتبة ...)
function Editable.OnClaimed(src, player, chosen)
    -- مثال:
    -- exports['my_logs']:send('starterpack', Framework.GetName(player))
end

--- إعلان الشات للجميع
function Editable.AnnounceClaim(src, player, packLabel)
    local chatCfg = Config.Chat or {}
    local name = Framework.GetName(player)
    local body = (chatCfg.template or 'تم تسليم المواطن ^3%s^0 %s 🎉'):format(name, packLabel)
    local prefix = chatCfg.prefix or ('📦 ' .. ((Config.Brand and Config.Brand.serverName) or 'Server'))
    local color = chatCfg.color or { 186, 82, 17 }
    local eventName = chatCfg.event or 'chatMessage'

    if eventName == 'chatMessage' then
        TriggerClientEvent('chatMessage', -1, prefix, color, body)
        return
    end

    TriggerClientEvent('chat:addMessage', -1, {
        color = color,
        args = { prefix, body },
    })
end

function Editable.Notify(src, message, nType)
    TriggerClientEvent('starter_pack:notify', src, message, nType or 'inform')
end
