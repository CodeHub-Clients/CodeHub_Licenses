Config = {}

Config.Debug = false

--- /starterpack للاعب | /starterpack [id] للأدمن
Config.Command = 'starterpack'
Config.ResetCommand = 'resetstarterpack'
Config.AdminGroups = { 'admin', 'superadmin', 'god' }

--- أكواد المبدعين / الإحالة — الإدارة: /starterpromo
Config.Promo = {
    enabled = true,
    required = false, -- true = لازم كود صالح قبل تأكيد الباقة
    onePerPlayer = true, -- لاعب واحد = كود واحد مدى الحياة
    adminCommand = 'starterpromo',
    minLength = 3,
    maxLength = 50,
    garages = {
        { id = 'central', label = 'كراج الوسط' },
        { id = 'sandy', label = 'كراج ساندي شورز' },
        { id = 'paleto', label = 'كراج بليتو' },
    },
    vehicleTypes = {
        { id = 'car', label = 'سيارة' },
        { id = 'bike', label = 'دراجة' },
        { id = 'boat', label = 'قارب' },
        { id = 'heli', label = 'هليكوبتر' },
    },
}

--- لا يمكن استلام الباقة إلا مرة واحدة لكل شخصية
Config.AllowOnlyOnce = true

--- فتح الواجهة تلقائياً بعد الدخول إذا لم يستلم الباقة
Config.AutoOpenOnJoin = false
Config.AutoOpenDelay = 4000

--- إغلاق الواجهة بـ ESC (يمكن إعادة فتحها بالأمر ما دام لم يستلم)
Config.CloseWithEscape = true

--- إجبار اختيار الحد الأقصى من كل فئة قبل المتابعة
Config.RequireFullSelection = true

Config.UI = {
    logo = 'nui://esx_loadingscreen/web/assets/logo.png', -- مثال: nui://your_loadingscreen/web/assets/logo.png
    locale = 'ar',
    dir = 'rtl',
}

Config.Brand = {
    serverName = 'متجر كود هوب',
    packLabel = 'باقة البداية',
    discord = 'discord.gg/5cc',
}

Config.Welcome = {
    title = 'أهلاً بك في المدينة',
    subtitle = 'أكمل خطوات التسجيل لاستلام باقة البداية ودخول المدينة',
    body = 'نرحّب بك في مجتمعنا. اقرأ القوانين، اختر مركباتك، ثم أكّد تعهدك لتبدأ رحلتك.',
}

Config.Rules = {
    'احترام جميع اللاعبين والإدارة في كل الأوقات.',
    'منع القتل العشوائي (RDM) والدهس العشوائي (VDM).',
    'الالتزام بالرول بلاي الجاد وعدم كسر الأجواء.',
    'منع استغلال الثغرات أو الغش بأي شكل.',
    'الميتا جيمينغ والتدخل في المشاهد دون سبب ممنوعات.',
    'الحسابات المتعددة واستغلال الأنظمة يؤدي للحظر.',
}

Config.Pledge = {
    title = 'تعهد الرول بلاي',
    text = 'أتعهد بالالتزام بقوانين السيرفر، واحترام الرول بلاي الجاد، وعدم الإضرار بتجربة الآخرين أو استخدام الغش أو كسر الأدوار. أفهم أن مخالفة هذا التعهد قد تؤدي لعقوبات تصل إلى الحظر.',
    checkbox = 'أقرأ التعهد وأوافق على الالتزام به',
}

Config.Locale = {
    acceptContinue = 'قبول والمتابعة',
    back = 'رجوع',
    next = 'متابعة',
    confirmEnter = 'تأكيد ودخول المدينة',
    submitting = 'جاري التسليم...',
    select = 'اختيار',
    selected = 'محدد',
    maxReached = 'وصلت للحد الأقصى',
    pickCount = 'اختر %s من %s',
    summaryTitle = 'ملخص الباقة',
    rewardsTitle = 'مكافآت البداية',
    rulesTitle = 'قوانين السيرفر',
    vehiclesTitle = 'المركبات المختارة',
    rpName = 'اسم الشخصية',
    steamName = 'اسم ستيم',
    cash = 'كاش',
    bank = 'بنك',
    black = 'أموال غير شرعية',
    xp = 'خبرة',
    items = 'أغراض',
    weapons = 'أسلحة',
    buffs = 'تعزيزات',
    selectedTitle = 'اختياراتك',
    countLabel = 'الكمية',
    ammoLabel = 'الذخيرة',
    hoursLabel = 'المدة',
    closeHint = 'ESC للإغلاق',
    alreadyClaimed = 'أنت استلمت الباقة مسبقاً.',
    claimFailed = 'تعذر استلام الباقة.',
    claimSuccess = 'تم استلام باقة البداية بنجاح.',
    notAllowed = 'ما عندك صلاحية.',
    playerOffline = 'اللاعب غير متصل.',
    resetSuccess = 'تم إعادة تعيين الباقة.',
    promoTitle = 'كود المبدع / الإحالة',
    promoHint = 'اختياري — أدخل كود المبدع للحصول على مكافآت إضافية',
    promoPlaceholder = 'أدخل الكود',
    promoCheck = 'تحقق',
    promoChecking = 'جاري التحقق...',
    promoValid = 'كود صالح',
    promoInvalid = 'الكود غير صالح أو غير موجود.',
    promoInactive = 'هذا الكود متوقف حالياً.',
    promoMaxed = 'وصل هذا الكود للحد الأقصى من الاستخدام.',
    promoUsed = 'سبق لك استخدام كود إحالة.',
    promoRequired = 'يجب إدخال كود مبدع صالح.',
    promoBonus = 'مكافأة الكود',
    promoCreator = 'المبدع',
    promoVehicle = 'مركبة إضافية',
    promoItem = 'غرض إضافي',
    adminTitle = 'لوحة أكواد المبدعين',
    adminSubtitle = 'إنشاء الأكواد ومتابعة الإحالات',
    adminCodes = 'الأكواد',
    adminCreate = 'إنشاء كود',
    adminSave = 'حفظ',
    adminDelete = 'حذف',
    adminToggle = 'تفعيل / إيقاف',
    adminSearch = 'بحث بالكود أو اسم المبدع',
    adminRedemptions = 'عمليات الاسترداد',
    adminNoCodes = 'لا توجد أكواد بعد',
    adminNoRedemptions = 'لا توجد عمليات استرداد',
    adminActive = 'نشط',
    adminInactive = 'متوقف',
    adminUnlimited = 'غير محدود',
    adminUses = 'الاستخدامات',
    adminMaxUses = 'الحد الأقصى (-1 = غير محدود)',
    adminCode = 'الكود',
    adminCreator = 'اسم المبدع',
    adminExtraCash = 'كاش إضافي',
    adminExtraBank = 'بنك إضافي',
    adminExtraXp = 'خبرة إضافية',
    adminCustomVehicle = 'مركبة مخصصة',
    adminCustomItem = 'غرض مخصص',
    adminItemCount = 'كمية الغرض',
    adminCreated = 'تاريخ الإنشاء',
    adminTotalCodes = 'إجمالي الأكواد',
    adminActiveCodes = 'أكواد نشطة',
    adminTotalRedeems = 'إجمالي الاسترداد',
    adminUniquePlayers = 'لاعبون فريدون',
    adminTopCreators = 'أكثر المبدعين استخداماً',
    adminDaily = 'الاسترداد خلال 14 يوم',
    adminRecent = 'آخر الاستردادات',
    adminSaved = 'تم حفظ الكود.',
    adminDeleted = 'تم حذف الكود.',
    adminExists = 'هذا الكود موجود مسبقاً.',
    adminPickVehicle = 'اختر مركبة',
    adminPickVehicleHint = 'افتح القائمة واختر مركبة المكافأة',
    adminPickItem = 'اختر غرض',
    adminPickItemHint = 'افتح القائمة واختر الغرض الإضافي',
    adminPickGarage = 'اختر الكراج',
    adminPickGarageHint = 'الكراج الذي تُحفظ فيه المركبة',
    adminVehicleLabel = 'اسم المركبة بالكراج',
    adminVehicleLabelHint = 'الاسم الذي يظهر للاعب في الكراج',
    adminVehicleType = 'نوع المركبة',
    adminClear = 'إزالة',
}

--- صفحة الترحيب: فلوس → غير شرعي → بنك → خبرة
--- enabled = false لإيقاف أي مكافأة بدون حذفها
Config.Rewards = {
    cash = { enabled = true, amount = 10000 },
    black = { enabled = true, amount = 0 },
    bank = { enabled = true, amount = 25000 },
    xp = {
        enabled = true,
        levels = 50,
        amount = 448800,
        eventName = 'codehub-Level:updateCurrentPlayerXP',
        addType = 'addnoduble',
        reason = 'باقة البداية',
        sourceLabel = 'starter_pack',
    },
}

Config.Garage = {
    garage = 'central',
    stored = 1,
}

--[[
  الخطوات بعد الترحيب — الترتيب هنا هو ترتيب الصفحات.
  enabled = false لإيقاف الخطوة بدون حذفها.

  type = 'vehicle' | 'item' | 'weapon' | 'buff' أو نوع خاص في editable/server.lua
]]
Config.Categories = {
    {
        id = 'sedan',
        enabled = true,
        type = 'vehicle',
        title = 'اختر مركبة السيدان',
        subtitle = 'اختر مركبة واحدة لبدء رحلتك',
        shortTitle = 'سيدان',
        icon = 'car',
        maxSelect = 1,
        options = {
            { label = 'بريمير', model = 'premier', speed = 78, accel = 64, brake = 62, seats = 4, vtype = 'car' },
            { label = 'أستيروب', model = 'asterope', speed = 80, accel = 66, brake = 63, seats = 4, vtype = 'car' },
            { label = 'ستانير', model = 'stanier', speed = 82, accel = 70, brake = 58, seats = 4, vtype = 'car' },
            { label = 'سلطان', model = 'sultan', speed = 92, accel = 86, brake = 74, seats = 4, vtype = 'car' },
        },
    },
    {
        id = 'suv',
        enabled = true,
        type = 'vehicle',
        title = 'اختر مركبة الجيب',
        subtitle = 'اختر مركبة دفع رباعي',
        shortTitle = 'جيب',
        icon = 'suv',
        maxSelect = 1,
        options = {
            { label = 'بالر', model = 'baller', speed = 76, accel = 62, brake = 68, seats = 4, vtype = 'car' },
            { label = 'غرانجر', model = 'granger', speed = 72, accel = 58, brake = 70, seats = 8, vtype = 'car' },
            { label = 'دوبستا', model = 'dubsta', speed = 82, accel = 72, brake = 70, seats = 4, vtype = 'car' },
            { label = 'غريسلي', model = 'gresley', speed = 78, accel = 66, brake = 66, seats = 4, vtype = 'car' },
        },
    },
    {
        id = 'trucks',
        enabled = true,
        type = 'vehicle',
        title = 'اختر الشاحنة',
        subtitle = 'اختر شاحنة العمل الخاصة بك',
        shortTitle = 'شاحنة',
        icon = 'truck',
        maxSelect = 1,
        options = {
            { label = 'بايسون', model = 'bison', speed = 70, accel = 62, brake = 55, seats = 4, vtype = 'car', trunkkg = 0 },
            { label = 'سادلر', model = 'sadler', speed = 72, accel = 60, brake = 56, seats = 4, vtype = 'car', trunkkg = 0 },
            { label = 'بوبكات', model = 'bobcatxl', speed = 68, accel = 58, brake = 52, seats = 4, vtype = 'car', trunkkg = 0 },
        },
    },

    {
        id = 'items',
        enabled = true,
        type = 'item',
        title = 'اختر أغراض البداية',
        subtitle = 'اختر غرضين لتبدأ بهما',
        shortTitle = 'أغراض',
        icon = 'item',
        maxSelect = 2,
        options = {
            { id = 'water', label = 'ماء', name = 'water', count = 10, description = '10 عبوات ماء' },
            { id = 'bread', label = 'خبز', name = 'bread', count = 10, description = '10 أرغفة' },
            { id = 'phone', label = 'جوال', name = 'phone', count = 1, description = 'هاتف للاتصال' },
            { id = 'bandage', label = 'ضماد', name = 'bandage', count = 5, description = '5 ضمادات' },
        },
    },

    {
        id = 'weapons',
        enabled = true,
        type = 'weapon',
        title = 'اختر سلاح البداية',
        subtitle = 'اختر سلاحاً واحداً',
        shortTitle = 'سلاح',
        icon = 'weapon',
        maxSelect = 1,
        options = {
            { id = 'pistol', label = 'مسدس', name = 'WEAPON_PISTOL', ammo = 50, description = '50 طلقة' },
            { id = 'bat', label = 'مضرب', name = 'WEAPON_BAT', ammo = 0, description = 'سلاح أبيض' },
        },
    },



    {
        id = 'boosts',
        enabled = true,
        type = 'buff',
        title = 'اختر تعزيز البداية',
        subtitle = 'اختر ضعف الخبرة المناسب لك',
        shortTitle = 'تعزيز',
        icon = 'buff',
        maxSelect = 1,
        options = {
            { id = 'xp2h', label = 'ضعف خبرة ساعتين', description = 'مضاعف XP لمدة ساعتين', buff = 'doublexp', hours = 2 },
            { id = 'xp6h', label = 'ضعف خبرة 6 ساعات', description = 'مضاعف XP لمدة 6 ساعات', buff = 'doublexp', hours = 6 },
        },
    },

}

--- توافق مع الاسم القديم
Config.VehicleCategories = Config.Categories

Config.AnnounceClaim = true
Config.Chat = {
    event = 'chatMessage', -- chatMessage | chat:addMessage
    prefix = '📦 متجر كود هوب',
    color = { 186, 82, 17 },
    template = 'تم تسليم المواطن ^3%s^0 %s 🎉',
}
