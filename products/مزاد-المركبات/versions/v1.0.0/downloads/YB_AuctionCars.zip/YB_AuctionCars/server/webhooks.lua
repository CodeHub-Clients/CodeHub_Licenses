--[[
    SERVER-SIDE ONLY — لا يُحمَّل على الكلاينت ولا يظهر في الديمب.
    ضع روابط الديسكورد هنا فقط.
]]

ServerWebhooks = {
    enabled = true,
    sell = 'https://discord.com/api/webhooks/PUT_SELL_WEBHOOK_HERE',
    buy  = 'https://discord.com/api/webhooks/PUT_BUY_WEBHOOK_HERE',
}
