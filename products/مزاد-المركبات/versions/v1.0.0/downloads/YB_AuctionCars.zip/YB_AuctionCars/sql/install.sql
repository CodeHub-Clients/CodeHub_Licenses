-- Optional history table (not used on the hot path)
CREATE TABLE IF NOT EXISTS `mzaad_auction_history` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `auction_id` VARCHAR(36) NOT NULL,
  `plate` VARCHAR(12) NOT NULL,
  `model` VARCHAR(64) NOT NULL,
  `label` VARCHAR(128) NOT NULL,
  `category` VARCHAR(32) NOT NULL,
  `winner_identifier` VARCHAR(64) DEFAULT NULL,
  `winner_name` VARCHAR(64) DEFAULT NULL,
  `final_price` INT NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ended_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_plate` (`plate`),
  KEY `idx_winner` (`winner_identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
