fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'YB_AuctionCars'
author 'CodeHub'
description 'Premium ESX Legacy vehicle auction system'
version '2.0.0'

dependencies {
    'es_extended',
    'oxmysql',
    'ox_lib'
}

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
    'locales/*.lua',
    'shared/*.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/webhooks.lua', -- server-only secrets (never on client)
    'server/persistence.lua',
    'server/permissions.lua',
    'server/money.lua',
    'server/vehicles.lua',
    'server/auction.lua',
    'server/main.lua'
}

client_scripts {
    'client/main.lua',
    'client/admin.lua',
    'client/placement.lua',
    'client/auctions.lua',
    'client/labels.lua',
    'client/interaction.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/assets/*',
    'data/*.json'
}

escrow_ignore {
    'config.lua',
    'server/webhooks.lua',
    'locales/*',
    'data/*',
    'sql/*'
}
