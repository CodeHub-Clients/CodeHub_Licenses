Config = {}

--[[ Framework ]]
Config.Locale = 'ar' -- 'ar' | 'en'
Config.Account = 'bank' -- 'bank' | 'money'
Config.Menu = 'ox_lib'

--[[ Level system (YB_Level) ]]
Config.LevelExport = 'YB_Level'
Config.LevelMethod = 'ESXP_GetRank'

--[[ Admin access ]]
Config.Admin = {
    ace = 'mzaad.admin',
    jobs = { 'admin' },
    command = 'mzaadadmin'
}

--[[ Admin bid bypass ]]
Config.AdminBypassLevel = true  -- الأدمن يتجاوز فحص المستوى عند المزايدة
Config.AdminBypassTicket = true -- الأدمن يتجاوز التذكرة عند المزايدة
Config.AdminBypassJob = true    -- الأدمن يتجاوز قيد الوظيفة عند المزايدة

--[[ Distances / performance ]]
Config.LabelDistance = 25.0
Config.InteractDistance = 3.0
Config.StreamDistance = 100.0
Config.JsonDebounceMs = 2000

--[[ Auction rules ]]
Config.MinBidIncrement = 1000
Config.DefaultDurationMinutes = 60
Config.OnlyOneActiveBid = false -- one concurrent bid per player
Config.AllowLeaveAuction = false -- refund + leave (optional)
Config.MaxPredefinedPositions = 10
--[[ Chat / جريدة ]]
Config.ChatAnnouncements = true
-- سيرفرات CodeHub العربية غالباً تستخدم chatMessage وليس chat:addMessage
Config.Chat = {
    event = 'chatMessage', -- 'chatMessage' | 'chat:addMessage'
    prefix = ' 🚗 المزاد ',
    color = { 255, 200, 50 }, -- RGB للبادئة
}

--[[ Ticket system (optional) ]]
Config.ActiveTicket = true
Config.TicketPrice = 15000
Config.TicketPosition = vec3(-1568.7570, -851.0179, 11.0779)
Config.TicketMarker = {
    enabled = true,
    type = 29,          -- ماركر دولار / تذكرة
    size = vec3(0.9, 0.9, 0.9),
    color = { r = 255, g = 200, b = 50, a = 180 },
    bobUpAndDown = true,
    rotate = true,
    drawDistance = 40.0,
    blip = {
        enabled = true,
        sprite = 280,
        color = 5,
        scale = 0.75,
        label = 'تذكرة المزاد'
    }
}

--[[ Categories ]]
Config.Categories = {
    { id = 'cars',     label = 'سيارات',   labelEn = 'Cars',     marker = 36 },
    { id = 'trucks',   label = 'شاحنات',   labelEn = 'Trucks',   marker = 39 },
    { id = 'boats',    label = 'قوارب',    labelEn = 'Boats',    marker = 35 },
    { id = 'planes',   label = 'طائرات',   labelEn = 'Planes',   marker = 33 },
    { id = 'helicopters', label = 'هليكوبتر', labelEn = 'Helicopters', marker = 34 },
}

--[[ جمهور المزاد: civ = العامة | الباقي = اسم وظيفة ESX ]]
Config.AuctionJobs = {
    { id = 'civ',       label = 'العامة',           labelEn = 'Public / Civilians' },
    { id = 'police',    label = 'الشرطة',           labelEn = 'Police' },
    { id = 'ambulance', label = 'الهلال الأحمر',    labelEn = 'Ambulance' },
    { id = 'mechanic',  label = 'الميكانيكي',       labelEn = 'Mechanic' },
    { id = 'agent',     label = 'أمن المنشآت',      labelEn = 'Agent' },
}

--[[ Discord: الروابط في server/webhooks.lua فقط (سيرفر سايد) ]]
Config.UseDiscordLogs = true

--[[ Debug ]]
Config.Debug = false
