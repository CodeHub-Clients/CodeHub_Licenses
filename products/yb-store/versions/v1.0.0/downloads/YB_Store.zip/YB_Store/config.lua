Config = {}

Config.ResourceName = 'YB_Store'
Config.OpenKey      = 'F9'
Config.ProductsPerPage = 12
Config.Webhook      = '' -- رابط ديسكورد للوغ العمليات (اختياري)

-- واجهة المتجر والوصف (يظهر في NUI)
Config.Store = {
    title   = 'AlRass | محافظة الـرس',
    tagline = 'أتمتة تسليم المنتجات — أكواد، إهداء، إحالة، وربط Tebex/Salla',
    -- (الشات يستخدم بادئة PurchaseBroadcast + السطر فقط — بدون «جريدة/اقتصاد»)
    newspaperTitle = 'جريدة الـرس | الاقتصاد', -- اختياري للواجهة فقط؛ ليس مُدمجاً في سطر chatMessage
    bullets = {
        'تسليم فوري: مركبات، أسلحة، أدوات، وبكجات',
        'أكواد: رصيد عملات أو استلام منتج محدد',
        'إهداء: اشتري لنفسك أو لِلاعب متصل عبر رقمه',
        'إحالة: ادعُ صديقك وخذ مكافأة معه (مرة واحدة لكل حساب)',
        'أفضل الداعمين وآخر المشتريات في لوحة المجتمع',
    },
}

-- إهداء المنتجات للاعبين الآخرين
Config.Gift = {
    enabled = true,
    --- اختبار وحدك: يسمح بإهداء نفسك + زر «DB» في نافذة الهدية. عطّله على السيرفر الحي.
    debugAllowSelfGift = true,
}

-- إعلان كل عملية شراء / إهداء في الشات (جريدة اقتصادية). عطّلها بـ enabled = false
-- الشات: chatClientEvent = 'chatMessage' يطابق الصيغة الشائعة:
--   TriggerClientEvent('chatMessage', -1, prefix, {r,g,b}, body)
-- أو اترك 'chat:addMessage' إن كنت تستخدم شات CFX الافتراضي فقط.
-- إن لم يظهر الإشعار: فعّل useEsxNotifyAll أو راجع مورد الشات عندك.
Config.PurchaseBroadcast = {
    enabled = true,
    useChat = true,
    chatClientEvent = 'chatMessage', -- 'chatMessage' | 'chat:addMessage'
    chatMessagePrefix = ' 📦 متجر الـرس أونلاين ',
    chatMessageColor = { 186, 82, 17 },
    useEsxNotifyAll = false, -- true يكرر النص كإشعار ESX (عطّله إن اكتفيت بـ chatMessage)
    clientNotifyEvent = 'esx:showNotification', -- مثال QB: 'QBCore:Notify' مع تعديل يدوي
    announceGiftsInPaper = true,
    -- اختياري: حدث مخصص على السيرفر: TriggerEvent(event, pInfo, productKey, productLabel, pricePaid, isGift, giftNames)
    event = '',
}

-- كوبونات خصم (جدول SQL: YB_Store_coupons)
Config.Coupons = {
    enabled = true,
    --- الافتراضي لأقصى مرات **لكل لاعب** لكل كوبون (إن كان عمود الكوبون max_uses_per_player = NULL)
    --- nil = بلا حد لكل لاعب (ضمن max_uses الكلي للكوبون فقط) — يسمح باستخدام متكرر
    defaultMaxUsesPerPlayer = nil,
    --- مثال تقييد: defaultMaxUsesPerPlayer = 5
}

-- لوحة إدارة داخل واجهة المتجر (زر «الإدارة») — يظهر فقط لمن في القائمة أو مجموعة ESX
Config.StoreAdmin = {
    enabled  = true,
    --- أضف steam: / char1: / license: كما يظهر عندك في قاعدة users أو FiveM
    allowedIdentifiers   = {
        'steam:11000014dc0e457', -- غيّر لستيمك
    },
    --- اختياري: أسماء مجموعات es_extended تُفتح بها اللوحة
    esxGroups = {},
    --- أو مجموعة واحدة
    -- esxGroup  = 'admin',
}

-- تجربة قيادة قبل الشراء (الإحدافيات: غيّرها لنقطة آمنة عندك)
Config.TestDrive = {
    enabled         = true,
    durationSec     = 45,
    spawn           = vector4(-49.52, -1092.0, 26.42, 70.0),
}

-- مكافأة الإحالة (عملات المتجر) — يستلم الطرفان عند ربط الحساب بكود صديق
Config.Referral = {
    enabled          = false,
    referrerReward   = 15, -- لصاحب الكود
    referredReward   = 10, -- للاعب الجديد الذي أدخل الكود
}

-- لوحة المجتمع (ترتيب حسب إجمالي العملات المُنفقة في المتجر)
Config.Community = {
    enabled              = true,
    topSupportersCount   = 5,
    recentPurchasesCount = 12,
    --- أسماء من users: تخزين المشتريات بـ `license:هكس` بينما ESX قد يستخدم `license2:` أو `char1:license2:`
    showPlayerNames      = true,
    --- اسم جدول المستخدمين (ESX)
    usersTable          = 'users',
    --- إن كان عندك عمود بـ **هكس الروكستار فقط** (بدون license:) يسمّى مثلاً `license` اكتب اسمه
    userRockstarColumn  = nil,
}

-- عند شراء مركبة: توجيه نوع الكراج (حقل job في owned_vehicles)
Config.VehicleJobPresets = {
    { id = 'police',    label = 'الأمن العام',           icon = 'shield' },
    { id = 'agent',     label = 'حرس الحدود',            icon = 'badge' },
    { id = 'ambulance', label = 'هلال أحمر / إسعاف',     icon = 'cross' },
    { id = 'mechanic',  label = 'ميكانيكي',              icon = 'wrench' },
}

-- تبويب «أخرى» يجمع هذه الفئات (slug المنتج في الحقل category)
Config.OtherCategoryKeys = { 'weapons', 'tools', 'features', 'packages' }

-- ═══════════════════════════════════════════════════════
--  نظام العملات التلقائية (كل X دقيقة = Y عملة)
-- ═══════════════════════════════════════════════════════
Config.PassiveCoins = {
    enabled          = true,
    intervalMinutes  = 240,   -- 4 ساعات = 240 دقيقة
    amount           = 1,     -- عدد العملات لكل فترة
    notifyPlayer     = true,
    notifyMessage    = 'حصلت على %d عملة مقابل تواجدك المستمر!'
}

-- ═══════════════════════════════════════════════════════
--  نظام أكواد الاسترداد
-- ═══════════════════════════════════════════════════════
Config.RedeemCodes = {
    enabled         = true,
    maxUsesDefault  = 1,
    commandCreate   = 'createcode',   -- /createcode <amount> [max_uses] [code]  → عملات
    commandDelete   = 'deletecode',   -- /deletecode <code>
    commandRedeem   = 'redeem',       -- /redeem <code>  (عملات أو منتج حسب الكود)

    -- الأشخاص المصرح لهم بإنشاء/حذف الأكواد (identifier أو steam)
    -- فقط هم + الكونسول يقدرون يستخدمون: createcode, createproductcode, createrandomcode, deletecode
    authorizedIdentifiers = {
        'steam:XXXXXXXXXXXXXXXXX',   -- حط الستيم هكس حقك هنا
        -- 'char1:xxxxxxxx',         -- أو الـ identifier حقك
        -- 'steam:YYYYYYYYYYYYYYYYY', -- تقدر تضيف أكثر من شخص
    },

    -- true = يُلغي أوامر إدارة الأكواد (createcode / createproductcode / createrandomcode / deletecode)
    -- ويبقى /redeem للاعبين. الإنشاء/الحذف من «لوحة إدارة المتجر» فقط.
    disableAdminCommands = false,
}

-- ═══════════════════════════════════════════════════════
--  الأقسام الرئيسية والفرعية
-- ═══════════════════════════════════════════════════════
Config.Categories = {
    {
        name  = 'vehicles',
        label = 'المركبات',
        icon  = 'car',
        subCategories = {
            { id = 'sedan',  label = 'سيدان' },
            { id = 'sport',  label = 'سبورت' },
            { id = 'suv',    label = 'جيب' },
            { id = 'pickup', label = 'بيك اب' },
            { id = 'trucks', label = 'حمولات' },
            { id = 'gov',    label = 'مركبات حكومية' },
        },
    },
    {
        name  = 'other',
        label = 'أخرى',
        icon  = 'grid',
    },
    {
        name  = 'plates',
        label = 'اللوحات',
        icon  = 'plate',
    },
    {
        name   = 'sponsorships',
        label  = 'الرعايات',
        icon   = 'megaphone',
        hidden = true,  -- مخفي مؤقتاً
    },
    {
        name  = 'cases',
        label = 'الصناديق',
        icon  = 'box',
    },
}

-- ═══════════════════════════════════════════════════════
--  المنتجات
-- ═══════════════════════════════════════════════════════
Config.Products = {

    -- ╔═══════════════════════════════════════════════╗
    -- ║               سيدان  (sedan)                  ║
    -- ╚═══════════════════════════════════════════════╝
    ['panto']              = { category='sedan', label='تويوتا كرسيدا 1994',       description='', model='crs',              image='https://l.top4top.io/p_3714ig4xa1.png', price=55,  type='vehicle', vehicleType='car', job='civ' },
    ['cad15m']           = { category='sedan', label='كادينزا مخزنة',            description='', model='cad15m',           image='https://h.top4top.io/p_37143zdmo1.png', price=150, type='vehicle', vehicleType='car', job='civ' },
    ['cad15']            = { category='sedan', label='كادينزا',                  description='', model='cad15',            image='https://c.top4top.io/p_3707iwvsz1.png', price=165, type='vehicle', vehicleType='car', job='civ' },
    ['cm25']             = { category='sedan', label='كامري 2025',               description='', model='cm25',             image='https://e.top4top.io/p_37075t0251.png', price=140, type='vehicle', vehicleType='car', job='civ' },
    ['cap13']            = { category='sedan', label='كابرس 2013',               description='', model='cap13',            image='https://b.top4top.io/p_3707gmlle1.png', price=275, type='vehicle', vehicleType='car', job='civ' },
    ['el24s']            = { category='sedan', label='النترا 2024',              description='', model='el24s',            image='https://e.top4top.io/p_370765mt51.png', price=89,  type='vehicle', vehicleType='car', job='civ' },
    ['6rp21']            = { category='sedan', label='كامري 2023',               description='', model='6rp21',            image='https://b.top4top.io/p_3707lfche1.png', price=175, type='vehicle', vehicleType='car', job='civ' },
    ['ac13']             = { category='sedan', label='اكورد 2013',               description='', model='ac13',             image='https://c.top4top.io/p_3707knqhv1.png', price=80,  type='vehicle', vehicleType='car', job='civ' },
    ['op11']             = { category='sedan', label='اوبتيما 2011',             description='', model='op11',             image='https://l.top4top.io/p_37074pq481.png', price=90,  type='vehicle', vehicleType='car', job='civ' },
    ['m4_altima2010']    = { category='sedan', label='التيما 2012',              description='', model='m4_altima2010',    image='https://h.top4top.io/p_370750mzl1.png', price=85,  type='vehicle', vehicleType='car', job='civ' },
    ['tau22tjld']        = { category='sedan', label='تورس 2022',                description='', model='tau22tjld',        image='https://l.top4top.io/p_3707k23mt1.png', price=250, type='vehicle', vehicleType='car', job='civ' },
    ['m4_k52021']        = { category='sedan', label='كي فايف',                  description='', model='m4_k52021',        image='https://i.top4top.io/p_3707ib84u1.png', price=150, type='vehicle', vehicleType='car', job='civ' },
    ['m4_mazda2024']     = { category='sedan', label='مازدا 2023',               description='', model='m4_mazda2024',     image='https://l.top4top.io/p_37075d4gf1.png', price=69,  type='vehicle', vehicleType='car', job='civ' },
    ['m4_cerato2025']    = { category='sedan', label='كي فور 2026',              description='', model='m4_cerato2025',    image='https://l.top4top.io/p_3707v01b41.png', price=140, type='vehicle', vehicleType='car', job='civ' },
    ['6rp76']            = { category='sedan', label='لكسس اي اس 300',           description='', model='6rp76',            image='https://j.top4top.io/p_3707fp7e71.png', price=250, type='vehicle', vehicleType='car', job='civ' },
    ['m4_Cerato2021']    = { category='sedan', label='سيراتو 2024',              description='', model='m4_Cerato2021',    image='https://l.top4top.io/p_3707uotqj1.png', price=66,  type='vehicle', vehicleType='car', job='civ' },
    ['so24lk']           = { category='sedan', label='سوناتا 2024',              description='', model='so24lk',           image='https://i.top4top.io/p_3707m02lt1.png', price=185, type='vehicle', vehicleType='car', job='civ' },
    ['capm5zn']          = { category='sedan', label='كابرس 2013 مخزن',          description='', model='capm5zn',          image='https://e.top4top.io/p_3707in3651.png', price=250, type='vehicle', vehicleType='car', job='civ' },
    ['m4_elantra2020']   = { category='sedan', label='النترا 2020',             description='', model='m4_elantra2020',   image='https://a.top4top.io/p_3707s3z801.png', price=115, type='vehicle', vehicleType='car', job='civ' },
    ['cmr17']            = { category='sedan', label='كامري 2017',               description='', model='cmr17',            image='https://a.top4top.io/p_37077gpsr1.png', price=100, type='vehicle', vehicleType='car', job='civ' },
    ['k525']             = { category='sedan', label='كي فايف 2025',             description='', model='k525',             image='https://e.top4top.io/p_3707mky2m1.png', price=200, type='vehicle', vehicleType='car', job='civ' },
    ['m4_bmw2020']       = { category='sedan', label='بي أم 2020',               description='', model='m4_bmw2020',       image='https://j.top4top.io/p_3707wg04f1.png', price=250, type='vehicle', vehicleType='car', job='civ' },
    ['m4_genesis2020']   = { category='sedan', label='جينيس 2020',              description='', model='m4_genesis2020',   image='https://f.top4top.io/p_3707cmrx31.png', price=199, type='vehicle', vehicleType='car', job='civ' },
    ['m4_rolesrise2019'] = { category='sedan', label='روز رايز رايث',            description='', model='m4_rolesrise2019', image='https://c.top4top.io/p_3707mftbw1.png', price=250, type='vehicle', vehicleType='car', job='civ' },
    ['m4_optima2015']    = { category='sedan', label='اوبتيما 2015',             description='', model='m4_optima2015',    image='https://k.top4top.io/p_3707he0u91.png', price=140, type='vehicle', vehicleType='car', job='civ' },
    ['cm05']             = { category='sedan', label='كامري 2006',               description='', model='cm05',             image='https://i.top4top.io/p_37075iggy1.png', price=45,  type='vehicle', vehicleType='car', job='civ' },
    ['cm03']             = { category='sedan', label='كامري 2004',               description='', model='cm03',             image='https://f.top4top.io/p_37077rv5v1.png', price=45,  type='vehicle', vehicleType='car', job='civ' },
    ['m4_accent2024_33'] = { category='sedan', label='اكسنت 2024',               description='', model='m4_accent2024_33', image='https://b.top4top.io/p_3759rn76p1.png', price=79,  type='vehicle', vehicleType='car', job='civ' },
    ['m4_altima2013_33'] = { category='sedan', label='التيما 2013',               description='', model='m4_altima2013_33', image='https://c.top4top.io/p_3759q2qev1.png', price=99,  type='vehicle', vehicleType='car', job='civ' },
    ['m4_caprice1996_33'] = { category='sedan', label='كابرس 1996',               description='', model='m4_caprice1996_33', image='https://e.top4top.io/p_3762u5rfl1.png', price=120,  type='vehicle', vehicleType='car', job='civ' },
    ['m4_crown2026_33'] = { category='sedan', label='كراون 2026',               description='', model='m4_crown2026_33', image='https://i.top4top.io/p_3762yunby1.png', price=210,  type='vehicle', vehicleType='car', job='civ' },
    ['m4_cruze2013_33'] = { category='sedan', label='كروز 2013',               description='', model='m4_cruze2013_33', image='https://e.top4top.io/p_3762jth1q1.png', price=85,  type='vehicle', vehicleType='car', job='civ' },
    ['m4_elantra2015_33'] = { category='sedan', label='النترا 2015',               description='', model='m4_elantra2015_33', image='https://k.top4top.io/p_376217rji1.png', price=100,  type='vehicle', vehicleType='car', job='civ' },
    ['m4_lexus2017_33'] = { category='sedan', label='لكزس 2017',               description='', model='m4_lexus2017_33', image='https://f.top4top.io/p_3762ssefe1.png', price=140,  type='vehicle', vehicleType='car', job='civ' },
    ['m4_benz1990_33'] = { category='sedan', label='مرسيدس 1990',               description='', model='m4_benz1990_33', image='https://b.top4top.io/p_3762jaw001.png', price=148,  type='vehicle', vehicleType='car', job='civ' },
    ['m4_benz2015_33'] = { category='sedan', label='مرسيدس 2015',               description='', model='m4_benz2015_33', image='https://f.top4top.io/p_3762xlrj41.png', price=160,  type='vehicle', vehicleType='car', job='civ' },
    ['m4_accent2017_33'] = { category='sedan', label='اكسنت قطب 2017',               description='', model='m4_accent2017_33', image='https://h.top4top.io/p_3762dlp9r1.png', price=50,  type='vehicle', vehicleType='car', job='civ' },
    ['m4_lexus2017_33'] = { category='sedan', label='لكزس قطب 2017',               description='', model='m4_lexus2017_33', image='https://b.top4top.io/p_37624ptx91.png', price=66,  type='vehicle', vehicleType='car', job='civ' },
    -- ['m4_spark2016_33'] = { category='sedan', label='سبارك 2016',               description='', model='m4_spark2016_33', image='https://h.top4top.io/p_3762v3w1a1.png', price=70,  type='vehicle', vehicleType='car', job='civ' },
    -- ['m4_mg2023'] = { category='sedan', label='ام جي 2023',               description='', model='m4_mg2023', image='https://i.top4top.io/p_3762f8g2y1.png', price=70,  type='vehicle', vehicleType='car', job='civ' },
    -- ╔═══════════════════════════════════════════════╗
    -- ║               سبورت  (sport)                  ║
    -- ╚═══════════════════════════════════════════════╝
    ['sxt14']            = { category='sport', label='تشارجر 2014',              description='', model='sxt14',            image='https://f.top4top.io/p_37088wrud1.png', price=200, type='vehicle', vehicleType='car', job='civ' },
    ['chargerwking']     = { category='sport', label='تشارجر دايتونا',           description='', model='chargerwking',     image='https://h.top4top.io/p_3708pedke1.png', price=350, type='vehicle', vehicleType='car', job='civ' },
    ['btourbillon24']    = { category='sport', label='بوجاتي توروبيون (اسرع مركبة)', description='', model='btourbillon24', image='https://h.top4top.io/p_3708qnf3z1.png', price=500, type='vehicle', vehicleType='car', job='civ' },
    ['zx280deb']         = { category='sport', label='زد اكس 1982',              description='', model='zx280deb',         image='https://c.top4top.io/p_3708vsxx51.png', price=250, type='vehicle', vehicleType='car', job='civ' },
    ['haya24nbrt']       = { category='sport', label='هايبوزا',                  description='', model='haya24nbrt',       image='https://i.top4top.io/p_3708d72901.png', price=232, type='vehicle', vehicleType='car', job='civ' },
    ['tr22']             = { category='sport', label='تسلا رودستر',              description='', model='tr22',             image='https://c.top4top.io/p_3708yeqfa1.png', price=189, type='vehicle', vehicleType='car', job='civ' },
    ['rmodatlantic']     = { category='sport', label='بوجاتي شيرون',             description='', model='rmodatlantic',     image='https://a.top4top.io/p_3708wcn2k1.png', price=449, type='vehicle', vehicleType='car', job='civ' },
    ['rmodsianr']        = { category='sport', label='لامبرجيني سيان',           description='', model='rmodsianr',        image='https://l.top4top.io/p_3708xn1va1.png', price=349, type='vehicle', vehicleType='car', job='civ' },
    ['gt77']             = { category='sport', label='جيتي سكايلاين 77',         description='', model='gt77',             image='https://j.top4top.io/p_3708k3o641.png', price=195, type='vehicle', vehicleType='car', job='civ' },
    ['m4_bmw2004_3']     = { category='sport', label='بي ام 2004',               description='', model='m4_bmw2004_3',     image='https://e.top4top.io/p_3762xfy511.png', price=276, type='vehicle', vehicleType='car', job='civ' },
  

    -- ╔═══════════════════════════════════════════════╗
    -- ║                 جيب  (suv)                    ║
    -- ╚═══════════════════════════════════════════════╝
    ['vtcst']            = { category='suv', label='فتك ستاندر 2015',            description='', model='vtcst',            image='https://f.top4top.io/p_371494mnx1.png', price=150, type='vehicle', vehicleType='car', job='civ' },
    ['vtcsu']            = { category='suv', label='فتك سوبر سفاري 2022',        description='', model='vtcsu',            image='https://c.top4top.io/p_3714nato21.png', price=150, type='vehicle', vehicleType='car', job='civ' },
    ['6rpVTCs']          = { category='suv', label='نيسان فتك 2021',             description='', model='6rpVTCs',          image='https://g.top4top.io/p_3708mpjhg1.png', price=165, type='vehicle', vehicleType='car', job='civ' },
    ['rb3sl8m']          = { category='suv', label='تويوتا ربع 2014',            description='', model='rb3sl8m',          image='https://i.top4top.io/p_3708qrgy21.png', price=200, type='vehicle', vehicleType='car', job='civ' },
    ['jrpatrol21']       = { category='suv', label='باترول 2021',                description='', model='jrpatrol21',       image='https://e.top4top.io/p_37082j2xp1.png', price=200, type='vehicle', vehicleType='car', job='civ' },
    ['ld99']             = { category='suv', label='لاندكروزر 2021',             description='', model='ld99',             image='https://k.top4top.io/p_3708h1qth1.png', price=220, type='vehicle', vehicleType='car', job='civ' },
    ['pat252dy']         = { category='suv', label='نيسان باترول 2025',          description='', model='pat252dy',         image='https://a.top4top.io/p_37081vm311.png', price=250, type='vehicle', vehicleType='car', job='civ' },
    ['ancullinan']       = { category='suv', label='روز رايز كولينان برابوس',    description='', model='ancullinan',       image='https://g.top4top.io/p_37083b3co1.png', price=399, type='vehicle', vehicleType='car', job='civ' },
    ['m4_sequoia2015']   = { category='suv', label='سكويا',                      description='', model='m4_sequoia2015',   image='https://c.top4top.io/p_3708jwrqk1.png', price=330, type='vehicle', vehicleType='car', job='civ' },
    ['m4_rangrover2022_33'] = { category='suv', label='رنج روفر 2022',               description='', model='m4_rangrover2022_33', image='https://h.top4top.io/p_3762egtz61.png', price=350,  type='vehicle', vehicleType='car', job='civ' },
    ['m4_rb32019_3']     = { category='suv', label='ربع 2019',               description='', model='m4_rb32019_3',     image='https://i.top4top.io/p_3762kzqqj1.png', price=350,  type='vehicle', vehicleType='car', job='civ' },

    -- ╔═══════════════════════════════════════════════╗
    -- ║              بيك اب  (pickup)                 ║
    -- ╚═══════════════════════════════════════════════╝
    ['hlx04m']           = { category='pickup', label='هايلوكس 2005',            description='', model='hlx04m',           image='https://b.top4top.io/p_3709je62t1.png', price=128, type='vehicle', vehicleType='car', job='civ' },
    ['ddsnulu']          = { category='pickup', label='ديسن 2016',               description='', model='ddsnulu',          image='https://f.top4top.io/p_37097tna01.png', price=150, type='vehicle', vehicleType='car', job='civ' },
    ['6rp13']            = { category='pickup', label='بهاني',                   description='', model='6rp13',            image='https://a.top4top.io/p_3709unftw1.png', price=350, type='vehicle', vehicleType='car', job='civ' },
    ['sierra25sle']      = { category='pickup', label='سيريا 2023-2025',         description='', model='sierra25sle',      image='https://d.top4top.io/p_3709pne161.png', price=300, type='vehicle', vehicleType='car', job='civ' },
    ['f150nzlh']         = { category='pickup', label='اف 150',                  description='', model='f150nzlh',         image='https://d.top4top.io/p_3709a41ti1.png', price=300, type='vehicle', vehicleType='car', job='civ' },
    ['hlx09']            = { category='pickup', label='هايلوكس غمارتين 2009-2011', description='', model='hlx09',          image='https://f.top4top.io/p_3709f9ii91.png', price=120, type='vehicle', vehicleType='car', job='civ' },
    ['hlx15-m']          = { category='pickup', label='هايلوكس غمارة 2012-2015',  description='', model='hlx15-m',         image='https://c.top4top.io/p_37097r2eo1.png', price=120, type='vehicle', vehicleType='car', job='civ' },
    ['jrs2016sl8']       = { category='pickup', label='هايلوكس غمارة 2010-2017',  description='', model='jrs2016sl8',      image='https://j.top4top.io/p_370963dnk1.png', price=175, type='vehicle', vehicleType='car', job='civ' },
    ['silv']             = { category='pickup', label='سلفرادو 2025',            description='', model='silv',             image='https://j.top4top.io/p_37091505b1.png', price=219, type='vehicle', vehicleType='car', job='civ' },
    ['sha921p']          = { category='pickup', label='شاص وارد البريمي',        description='', model='sha921p',          image='https://b.top4top.io/p_3709zhvlp1.png', price=145, type='vehicle', vehicleType='car', job='civ' },
    ['hlx15s']           = { category='pickup', label='هايلوكس استعراض',          description='', model='hlx15s',           image='https://l.top4top.io/p_3709acfxr1.png', price=189, type='vehicle', vehicleType='car', job='civ' },

    -- ╔═══════════════════════════════════════════════╗
    -- ║           حمولات / شاحنات (trucks)            ║
    -- ╚═══════════════════════════════════════════════╝
    ['lb6x']             = { category='trucks', label='إل بي سقس [620]',         description='', model='lb6x',             image='https://d.top4top.io/p_3709ka9xq1.png', price=550, type='vehicle', vehicleType='truck', job='civ' },
    ['boz1']             = { category='trucks', label='وايت بوز سقس حمولة [620]', description='', model='boz1',            image='https://h.top4top.io/p_370965s8z1.png', price=550, type='vehicle', vehicleType='truck', job='civ' },
    ['boz2']             = { category='trucks', label='بوز نقل [450]',            description='', model='boz2',            image='https://c.top4top.io/p_37098fv5g1.png', price=400, type='vehicle', vehicleType='truck', job='civ' },
    ['boz3']             = { category='trucks', label='بوز قلاب [400]',           description='', model='boz3',            image='https://a.top4top.io/p_370983fwi1.png', price=360, type='vehicle', vehicleType='truck', job='civ' },
    ['bozx']             = { category='trucks', label='رأس شاحنة كبير [160]',    description='', model='bozx',             image='https://h.top4top.io/p_3709gsg9i1.png', price=140, type='vehicle', vehicleType='truck', job='civ' },
    ['lbx1']             = { category='trucks', label='راس شاحنة حمولة [130]',   description='', model='lbx1',             image='https://l.top4top.io/p_3709dxv8f1.png', price=121, type='vehicle', vehicleType='truck', job='civ' },
    ['benz']             = { category='trucks', label='شاحنة حمولة [250]',       description='', model='benz',             image='https://c.top4top.io/p_3709psaw71.png', price=249, type='vehicle', vehicleType='truck', job='civ' },
    ['benz1']            = { category='trucks', label='رأس حمولة [100]',         description='', model='benz1',            image='https://l.top4top.io/p_3709d5ob11.png', price=128, type='vehicle', vehicleType='truck', job='civ' },

    -- ╔═══════════════════════════════════════════════╗
    -- ║          مركبات حكومية  (gov)                 ║
    -- ╚═══════════════════════════════════════════════╝
    ['bcso2sry']         = { category='gov', label='كابرس سري شرطة',             description='', model='bcso2sry',         image='https://l.top4top.io/p_3710qxk3n1.png', price=125, type='vehicle', vehicleType='car', job='police' },
    ['zmawk127']         = { category='gov', label='التيما سري شرطة',            description='', model='zmawk127',         image='https://h.top4top.io/p_3710m43ui1.png', price=85,  type='vehicle', vehicleType='car', job='police' },
    ['om29']             = { category='gov', label='مرسيدس GT63 سري شرطة',       description='', model='om29',             image='https://i.top4top.io/p_371062egr1.png', price=189, type='vehicle', vehicleType='car', job='police' },
    ['om19']             = { category='gov', label='جي تي ار سري شرطة',          description='', model='om19',             image='https://a.top4top.io/p_3710eyhx91.png', price=219, type='vehicle', vehicleType='car', job='police' },
    ['abumznhsry2']      = { category='gov', label='كامري سري شرطة',             description='', model='abumznhsry2',      image='https://h.top4top.io/p_3710tbmmj1.png', price=85,  type='vehicle', vehicleType='car', job='police' },

    -- ╔═══════════════════════════════════════════════╗
    -- ║              أسلحة  (weapons)                 ║
    -- ╚═══════════════════════════════════════════════╝
    --[[ ══ مخفي مؤقتاً: أسلحة + أدوات ══
    ['weapon_combatpistol']  = { category='weapons', label='مسدس كومبات + 100 رصاصة',      description='مسدس متوسط المدى مناسب للدفاع الشخصي.', weaponName='weapon_combatpistol',  ammo=100, image='https://cdn.sky-systems.net/weapons/combatpistol_7.png',    price=15,  type='weapon' },
    ['weapon_heavypistol']   = { category='weapons', label='مسدس ثقيل + 100 رصاصة',        description='مسدس قوي ودقيق.',                       weaponName='weapon_heavypistol',   ammo=100, image='https://cdn.sky-systems.net/weapons/combatpistol_7.png',    price=20,  type='weapon' },
    ['weapon_smg']           = { category='weapons', label='رشاش SMG + 150 رصاصة',          description='رشاش خفيف سريع الإطلاق.',               weaponName='weapon_smg',           ammo=150, image='https://cdn.sky-systems.net/weapons/specialcarbine_7.png',  price=35,  type='weapon' },
    ['weapon_specialcarbine']= { category='weapons', label='سبيشل كاربين + 200 رصاصة',      description='بندقية هجومية متعددة الاستخدامات.',      weaponName='weapon_specialcarbine',ammo=200, image='https://cdn.sky-systems.net/weapons/specialcarbine_7.png',  price=50,  type='weapon' },
    ['weapon_assaultrifle']  = { category='weapons', label='بندقية هجومية + 200 رصاصة',     description='بندقية قوية وسريعة.',                    weaponName='weapon_assaultrifle',  ammo=200, image='https://cdn.sky-systems.net/weapons/specialcarbine_7.png',  price=55,  type='weapon' },
    ['weapon_pumpshotgun']   = { category='weapons', label='شوتقن + 50 رصاصة',              description='قوة تدميرية عالية من مسافة قريبة.',      weaponName='weapon_pumpshotgun',   ammo=50,  image='https://cdn.sky-systems.net/weapons/combatpistol_7.png',    price=30,  type='weapon' },
    ['weapon_heavysniper']   = { category='weapons', label='قناصة ثقيلة + 30 رصاصة',        description='دقة عالية من مسافات بعيدة.',             weaponName='weapon_heavysniper',   ammo=30,  image='https://cdn.sky-systems.net/weapons/specialcarbine_7.png',  price=80,  type='weapon' },
    ['weapon_combatmg']      = { category='weapons', label='رشاش ثقيل + 300 رصاصة',         description='رشاش ثقيل للمعارك الكبيرة.',             weaponName='weapon_combatmg',      ammo=300, image='https://cdn.sky-systems.net/weapons/specialcarbine_7.png',  price=70,  type='weapon' },

    -- ╔═══════════════════════════════════════════════╗
    -- ║          أدوات وايتمات  (tools)               ║
    -- ╚═══════════════════════════════════════════════╝
    -- غيّر أسماء الايتمات (itemName) حسب سكربتاتك
    ['item_fixkit']    = { category='tools', label='طقم إصلاح × 5',       description='خمس قطع إصلاح للمركبات.',  itemName='fixkit',    amount=5, image='https://cdn.sky-systems.net/items/id_card_1.png', price=10, type='item' },
    ['item_medkit']    = { category='tools', label='حقيبة إسعافات × 5',   description='للعلاج الميداني السريع.',    itemName='medikit',   amount=5, image='https://cdn.sky-systems.net/items/id_card_1.png', price=10, type='item' },
    ['item_armor']     = { category='tools', label='درع واقي × 3',        description='حماية إضافية للجسم.',       itemName='armour',    amount=3, image='https://cdn.sky-systems.net/items/id_card_1.png', price=15, type='item' },
    ['item_lockpick']  = { category='tools', label='أداة فتح × 3',       description='لفتح الأقفال.',             itemName='lockpick',  amount=3, image='https://cdn.sky-systems.net/items/id_card_1.png', price=12, type='item' },
    ['item_phone']     = { category='tools', label='هاتف',               description='هاتف جوال.',                itemName='phone',     amount=1, image='https://cdn.sky-systems.net/items/id_card_1.png', price=5,  type='item' },
    ['item_binoculars']= { category='tools', label='منظار',              description='للمراقبة من بعيد.',          itemName='binoculars',amount=1, image='https://cdn.sky-systems.net/items/id_card_1.png', price=8,  type='item' },
    ]]

    -- ╔═══════════════════════════════════════════════╗
    -- ║             الخصائص  (features)               ║
    -- ╚═══════════════════════════════════════════════╝
    ['feature_plate'] = {
        category    = 'plates',
        label       = 'لوحة مميزة (تصميم)',
        description = '3 أحرف إنجليزية + 3 أرقام. تحقق من التوفر ثم الشراء.',
        image       = 'https://cdn.sky-systems.net/items/id_card_1.png',
        price       = 350,
        type        = 'feature',
        plateDesigner = true,
        actions     = {
            { type = 'event', event = 'YB_Store:applyCustomPlate' }
        }
    },
    --[[ ══ مخفي مؤقتاً: خصائص أخرى (أبقينا فقط فك السجن + اللوحات) ══
    ['feature_phone'] = {
        category    = 'features',
        label       = 'رقم هاتف مميز',
        description = 'احصل على رقم هاتف مميز من اختيارك.',
        image       = 'https://cdn.sky-systems.net/items/id_card_1.png',
        price       = 30,
        type        = 'feature',
        requireInput = true,
        inputPlaceholder = 'اكتب الرقم المميز...',
        inputMaxLength   = 10,
        actions     = {
            { type = 'event', event = 'YB_Store:applyCustomPhone' }
        }
    },
    ['feature_clear_records'] = {
        category    = 'features',
        label       = 'حذف السجلات الجنائية',
        description = 'يمسح جميع سوابقك من قاعدة البيانات.',
        image       = 'https://cdn.sky-systems.net/items/pile_of_banknotes_1.png',
        price       = 60,
        type        = 'feature',
        actions     = {
            { type = 'event', event = 'YB_Store:clearPlayerRecord' }
        }
    },
    ]]
    ['feature_jail_reduce_200'] = {
        category    = 'features',
        label       = 'تخفيف عقوبة — 200',
        description = 'يخصم 200 من مدة سجنك الحالية (لا يفك السجن كاملاً إذا بقي وقت).',
        image       = 'https://cdn.sky-systems.net/items/id_card_1.png',
        price       = 50,
        type        = 'feature',
        actions     = {
            { type = 'event', event = 'YB_Store:applyJailProduct', jailMinutes = 200 },
        },
    },
    ['feature_jail_reduce_500'] = {
        category    = 'features',
        label       = 'تخفيف عقوبة — 500',
        description = 'يخصم 500 من مدة سجنك الحالية.',
        image       = 'https://cdn.sky-systems.net/items/id_card_1.png',
        price       = 75,
        type        = 'feature',
        actions     = {
            { type = 'event', event = 'YB_Store:applyJailProduct', jailMinutes = 500 },
        },
    },
    ['feature_unjail'] = {
        category    = 'features',
        label       = 'فك السجن الفوري (كامل)',
        description = 'يخرجك من السجن فوراً — يصفّر المدة المتبقية بالكامل.',
        image       = 'https://cdn.sky-systems.net/items/id_card_1.png',
        price       = 120,
        type        = 'feature',
        actions     = {
            { type = 'event', event = 'YB_Store:applyJailProduct', full = true },
        },
    },

    --[[ ══ مخفي مؤقتاً: باقي الخصائص + رعايات + بكجات ══
    ['feature_moneywash'] = {
        category    = 'features',
        label       = 'غسيل أموال',
        description = 'يحوّل 100,000$ من الكاش الأسود إلى حسابك البنكي.',
        image       = 'https://cdn.sky-systems.net/items/pile_of_banknotes.png',
        price       = 40,
        type        = 'feature',
        actions     = {
            { type = 'event', event = 'YB_Store:moneyWash' }
        }
    },
    ['feature_vip'] = {
        category    = 'features',
        label       = 'عضوية VIP (7 أيام)',
        description = 'صلاحيات VIP لمدة أسبوع كامل.',
        image       = 'https://cdn.sky-systems.net/items/id_card_1.png',
        price       = 200,
        type        = 'feature',
        actions     = {
            { type = 'event', event = 'YB_Store:grantVIP' }
        }
    },
    ['feature_xp_boost'] = {
        category    = 'features',
        label       = 'ضعف الخبرة (مؤقت)',
        description = 'مضاعفة XP لمدة محددة — اربط الحدث يدوياً مع سكربت المستوى.',
        image       = 'https://cdn.sky-systems.net/items/id_card_1.png',
        price       = 45,
        type        = 'feature',
        actions     = {
            { type = 'event', event = 'YB_Store:grantXPBoost' }
        }
    },
    ['feature_salary_boost'] = {
        category    = 'features',
        label       = 'ضعف الأجر (مؤقت)',
        description = 'مضاعفة راتب الوظيفة مؤقتاً — اربط الحدث مع نظام الرواتب.',
        image       = 'https://cdn.sky-systems.net/items/id_card_1.png',
        price       = 55,
        type        = 'feature',
        actions     = {
            { type = 'event', event = 'YB_Store:grantSalaryBoost' }
        }
    },
    ['feature_cash_bank'] = {
        category    = 'features',
        label       = 'أموال شرعية (بنك)',
        description = 'إيداع 75,000$ في الحساب البنكي.',
        image       = 'https://cdn.sky-systems.net/items/pile_of_banknotes_1.png',
        price       = 35,
        type        = 'feature',
        actions     = {
            { type = 'money', account = 'bank', amount = 75000 }
        }
    },
    ['feature_cash_black'] = {
        category    = 'features',
        label       = 'أموال غير شرعية',
        description = '25,000$ كاش أسود (للأغراض المخصصة في سيرفرك).',
        image       = 'https://cdn.sky-systems.net/items/pile_of_banknotes.png',
        price       = 30,
        type        = 'feature',
        actions     = {
            { type = 'money', account = 'black_money', amount = 25000 }
        }
    },

    -- ╔═══════════════════════════════════════════════╗
    -- ║          رعايات وعروض  (sponsorships)        ║
    -- ╚═══════════════════════════════════════════════╝
    ['sponsor_pack_streamer'] = {
        category    = 'sponsorships',
        label       = 'بكج رعاية — ستريمر / إعلان',
        description = 'بكج ترويجي: عملات إضافية + مبلغ بنكي — خصص العرض في الإدارة.',
        image       = 'https://cdn.sky-systems.net/items/case_1.png',
        price       = 120,
        type        = 'pack',
        actions     = {
            { type = 'coins', amount = 20 },
            { type = 'money', account = 'bank', amount = 100000 },
        }
    },
    ['sponsor_pack_vip_line'] = {
        category    = 'sponsorships',
        label       = 'عرض خط VIP مخصص',
        description = 'للعرض في المتجر أو ديسكورد — عدّل المحتوى حسب اتفاقك مع الراعي.',
        image       = 'https://cdn.sky-systems.net/items/case_1.png',
        price       = 400,
        type        = 'pack',
        actions     = {
            { type = 'money', account = 'bank', amount = 250000 },
            { type = 'coins', amount = 80 },
        }
    },

    -- ╔═══════════════════════════════════════════════╗
    -- ║             البكجات  (packages)               ║
    -- ╚═══════════════════════════════════════════════╝
    ['pack_starter'] = {
        category    = 'packages',
        label       = 'بكج المبتدئ',
        description = 'كامري 2006 + مسدس كومبات (50 طلقة) + 50,000$',
        image       = 'https://cdn.sky-systems.net/items/case_1.png',
        price       = 100,
        type        = 'pack',
        actions     = {
            { type = 'vehicle', model = 'cm05' },
            { type = 'weapon',  name  = 'weapon_combatpistol', count = 50 },
            { type = 'money',   account = 'bank', amount = 50000 },
        }
    },
    ['pack_premium'] = {
        category    = 'packages',
        label       = 'بكج المميز',
        description = 'تشارجر 2014 + هايلوكس 2005 + سبيشل كاربين (100 طلقة) + 200,000$ + 10 عملات',
        image       = 'https://cdn.sky-systems.net/items/case_1.png',
        price       = 300,
        type        = 'pack',
        actions     = {
            { type = 'vehicle', model = 'sxt14' },
            { type = 'vehicle', model = 'hlx04m' },
            { type = 'weapon',  name  = 'weapon_specialcarbine', count = 100 },
            { type = 'money',   account = 'bank', amount = 200000 },
            { type = 'coins',   amount = 10 },
        }
    },
    ['pack_ultimate'] = {
        category    = 'packages',
        label       = 'بكج الأسطوري',
        description = 'روز رايز رايث + شاحنة [250] + قناصة (50 طلقة) + رشاش (200 طلقة) + 500,000$ + 50 عملة',
        image       = 'https://cdn.sky-systems.net/items/case_1.png',
        price       = 600,
        type        = 'pack',
        actions     = {
            { type = 'vehicle', model = 'm4_rolesrise2019' },
            { type = 'vehicle', model = 'benz' },
            { type = 'weapon',  name  = 'weapon_heavysniper', count = 50 },
            { type = 'weapon',  name  = 'weapon_combatmg',    count = 200 },
            { type = 'money',   account = 'bank', amount = 500000 },
            { type = 'coins',   amount = 50 },
        }
    },
    ]]

    -- ╔═══════════════════════════════════════════════╗
    -- ║             الصناديق  (cases)                 ║
    -- ╚═══════════════════════════════════════════════╝

    ['blue_case'] = {
        category    = 'cases',
        label       = 'الصندوق الأزرق',
        description = 'صندوق عادي بجوائز متنوعة — حظ سعيد!',
        image       = 'https://cdn.sky-systems.net/items/case_1.png',
        price       = 22,
        type        = 'case',
        rewards     = {
            { label = 'بوجاتي توروبيون',           sort = 'vehicle', name = 'btourbillon24',       amount = 1,      img = 'https://h.top4top.io/p_3708qnf3z1.png', weight = 1  },
            { label = 'لامبرجيني سيان',             sort = 'vehicle', name = 'rmodsianr',           amount = 1,      img = 'https://l.top4top.io/p_3708xn1va1.png', weight = 2  },
            { label = 'مسدس كومبات + 100 طلقة',     sort = 'weapon',  name = 'weapon_combatpistol', amount = 100,    img = 'https://cdn.sky-systems.net/weapons/combatpistol_7.png', weight = 5 },
            { label = 'سبيشل كاربين + 150 طلقة',    sort = 'weapon',  name = 'weapon_specialcarbine',amount = 150,   img = 'https://cdn.sky-systems.net/weapons/specialcarbine_7.png', weight = 5 },
            { label = '100,000$ في البنك',           sort = 'cash',    name = 'bank',                amount = 100000, img = 'https://cdn.sky-systems.net/items/pile_of_banknotes_1.png', weight = 7 },
            { label = '50,000$ في البنك',            sort = 'cash',    name = 'bank',                amount = 50000,  img = 'https://cdn.sky-systems.net/items/pile_of_banknotes.png',   weight = 15 },
            { label = '20 عملة إضافية',             sort = 'coins',   name = '',                    amount = 20,     img = 'https://cdn.sky-systems.net/items/cash_stack_1.png',        weight = 20 },
            { label = '10,000$ في البنك',            sort = 'cash',    name = 'bank',                amount = 10000,  img = 'https://cdn.sky-systems.net/items/pile_of_banknotes.png',   weight = 45 },
        }
    },

    ['gold_case'] = {
        category    = 'cases',
        label       = 'الصندوق الذهبي',
        description = 'صندوق نادر بجوائز أفضل — هل تجرؤ؟',
        image       = 'https://cdn.sky-systems.net/items/case_1.png',
        price       = 50,
        type        = 'case',
        rewards     = {
            { label = 'روز رايز كولينان برابوس',    sort = 'vehicle', name = 'ancullinan',          amount = 1,      img = 'https://g.top4top.io/p_37083b3co1.png', weight = 1  },
            { label = 'تسلا رودستر',                sort = 'vehicle', name = 'tr22',                amount = 1,      img = 'https://c.top4top.io/p_3708yeqfa1.png', weight = 3  },
            { label = 'تشارجر دايتونا',             sort = 'vehicle', name = 'chargerwking',        amount = 1,      img = 'https://h.top4top.io/p_3708pedke1.png', weight = 5  },
            { label = 'قناصة ثقيلة + 50 رصاصة',     sort = 'weapon',  name = 'weapon_heavysniper',  amount = 50,     img = 'https://cdn.sky-systems.net/weapons/specialcarbine_7.png', weight = 8 },
            { label = 'بندقية هجومية + 200 رصاصة',  sort = 'weapon',  name = 'weapon_assaultrifle', amount = 200,    img = 'https://cdn.sky-systems.net/weapons/specialcarbine_7.png', weight = 8 },
            { label = '200,000$ في البنك',           sort = 'cash',    name = 'bank',                amount = 200000, img = 'https://cdn.sky-systems.net/items/pile_of_banknotes_1.png', weight = 10 },
            { label = '100,000$ في البنك',           sort = 'cash',    name = 'bank',                amount = 100000, img = 'https://cdn.sky-systems.net/items/pile_of_banknotes.png',   weight = 15 },
            { label = '50 عملة إضافية',             sort = 'coins',   name = '',                    amount = 50,     img = 'https://cdn.sky-systems.net/items/cash_stack_1.png',        weight = 20 },
            { label = '25,000$ في البنك',            sort = 'cash',    name = 'bank',                amount = 25000,  img = 'https://cdn.sky-systems.net/items/pile_of_banknotes.png',   weight = 30 },
        }
    },

    ['diamond_case'] = {
        category    = 'cases',
        label       = 'الصندوق الماسي',
        description = 'أفضل صندوق في المتجر — جوائز أسطورية!',
        image       = 'https://cdn.sky-systems.net/items/case_1.png',
        price       = 100,
        type        = 'case',
        rewards     = {
            { label = 'بوجاتي شيرون',               sort = 'vehicle', name = 'rmodatlantic',        amount = 1,      img = 'https://a.top4top.io/p_3708wcn2k1.png', weight = 1  },
            { label = 'بوجاتي توروبيون',            sort = 'vehicle', name = 'btourbillon24',       amount = 1,      img = 'https://h.top4top.io/p_3708qnf3z1.png', weight = 2  },
            { label = 'سكويا',                      sort = 'vehicle', name = 'm4_sequoia2015',      amount = 1,      img = 'https://c.top4top.io/p_3708jwrqk1.png', weight = 4  },
            { label = '500,000$ في البنك',           sort = 'cash',    name = 'bank',                amount = 500000, img = 'https://cdn.sky-systems.net/items/pile_of_banknotes_1.png', weight = 8 },
            { label = 'رشاش ثقيل + 300 رصاصة',      sort = 'weapon',  name = 'weapon_combatmg',     amount = 300,    img = 'https://cdn.sky-systems.net/weapons/specialcarbine_7.png', weight = 10 },
            { label = '250,000$ في البنك',           sort = 'cash',    name = 'bank',                amount = 250000, img = 'https://cdn.sky-systems.net/items/pile_of_banknotes_1.png', weight = 15 },
            { label = '100 عملة إضافية',            sort = 'coins',   name = '',                    amount = 100,    img = 'https://cdn.sky-systems.net/items/cash_stack_1.png',        weight = 25 },
            { label = '50,000$ في البنك',            sort = 'cash',    name = 'bank',                amount = 50000,  img = 'https://cdn.sky-systems.net/items/pile_of_banknotes.png',   weight = 35 },
        }
    },
}
