fx_version 'cerulean'
game 'gta5'

name 'YB_Store'
author 'CodeHub'
description 'CH Store — Premium In-Game Shop for ESX Legacy'
version '3.0.0'

lua54 'yes'

ui_page 'nui/index.html'

files {
    'nui/index.html',
    'nui/assets/*',
}

shared_scripts {
    '@es_extended/imports.lua',
    'config.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/coins.lua',
    'server/logs.lua',
    'server/plates.lua',
    'server/coupons.lua',
    'server/purchase.lua',
    'server/redeem.lua',
    'server/community.lua',
    'server/referral.lua',
    'server/admin.lua',
    'server/main.lua'
}

client_scripts {
    'client/main.lua'
}

escrow_ignore {
    'config.lua',
    'server/logs.lua',

}

dependency '/assetpacks'