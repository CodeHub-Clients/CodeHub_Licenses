-- ═══════════════════════════════════════════════════════
--  CH Store — Database Schema
-- ═══════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS YB_Store_coins (
    license        VARCHAR(64) PRIMARY KEY,
    coins          INT NOT NULL DEFAULT 0,
    referral_code  VARCHAR(10) NULL,
    referred_by    VARCHAR(64) NULL,
    updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_referral_code (referral_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS YB_Store_transactions (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    license     VARCHAR(64) NOT NULL,
    tx_id       VARCHAR(100) NOT NULL UNIQUE,
    amount      INT NOT NULL,
    source      VARCHAR(30) NOT NULL,
    note        VARCHAR(255) NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_license (license)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS YB_Store_purchases (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    license         VARCHAR(64) NOT NULL,
    product_key     VARCHAR(80) NOT NULL,
    price           INT NOT NULL,
    payload         JSON NULL,
    esx_identifier  VARCHAR(100) NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_license (license)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS YB_Store_playtime (
    license         VARCHAR(64) PRIMARY KEY,
    total_minutes   INT NOT NULL DEFAULT 0,
    last_reward_at  TIMESTAMP NULL,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS YB_Store_redeem_codes (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    code            VARCHAR(20) NOT NULL UNIQUE,
    coins_amount    INT NOT NULL DEFAULT 0,
    reward_type     VARCHAR(16) NOT NULL DEFAULT 'coins',
    product_key     VARCHAR(80) NULL,
    max_uses        INT NOT NULL DEFAULT 1,
    current_uses    INT NOT NULL DEFAULT 0,
    created_by      VARCHAR(64) NULL,
    expires_at      TIMESTAMP NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS YB_Store_redeem_usage (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    code_id     INT NOT NULL,
    license     VARCHAR(64) NOT NULL,
    redeemed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_code_user (code_id, license),
    INDEX idx_license (license)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS YB_Store_coupons (
    id                    INT AUTO_INCREMENT PRIMARY KEY,
    code                  VARCHAR(32) NOT NULL UNIQUE,
    percent_off           TINYINT UNSIGNED NOT NULL DEFAULT 10,
    max_uses              INT NULL,
    max_uses_per_player   INT NULL,
    used_count            INT NOT NULL DEFAULT 0,
    expires_at            TIMESTAMP NULL,
    active                TINYINT(1) NOT NULL DEFAULT 1,
    created_by            VARCHAR(100) NULL,
    note                  VARCHAR(160) NULL,
    created_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS YB_Store_coupon_usage (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    code_id     INT NOT NULL,
    license     VARCHAR(64) NOT NULL,
    tx_id       VARCHAR(120) NULL,
    used_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_code (code_id),
    INDEX idx_lic (license),
    INDEX idx_code_lic (code_id, license)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
