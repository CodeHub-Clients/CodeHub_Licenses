-- YB_Store v3 — للترقية من إصدارة سابقة (تشغيل يدوي مرة واحدة)
-- إذا ظهر خطأ Duplicate column name فالعمود موجود مسبقاً — تجاهل ذلك السطر.

ALTER TABLE YB_Store_coins ADD COLUMN referral_code VARCHAR(10) NULL;
ALTER TABLE YB_Store_coins ADD COLUMN referred_by VARCHAR(64) NULL;

ALTER TABLE YB_Store_coins ADD UNIQUE KEY uq_referral_code (referral_code);

ALTER TABLE YB_Store_redeem_codes ADD COLUMN reward_type VARCHAR(16) NOT NULL DEFAULT 'coins';
ALTER TABLE YB_Store_redeem_codes ADD COLUMN product_key VARCHAR(80) NULL;
