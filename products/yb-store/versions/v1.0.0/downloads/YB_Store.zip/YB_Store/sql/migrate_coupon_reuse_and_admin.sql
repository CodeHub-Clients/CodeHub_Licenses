-- تشغيل مرة واحدة على قواعد قديمة:
-- 1) إزالة منع تكرار (نفس اللاعب + نفس الكوبون) ليسمح بعدة مشتريات بنفس الكود
-- 2) أعمدة إدارة الكوبون
--
-- إن ظهر: Unknown key 'uq_code_license' → المفتاح غير موجود (تجاهل).
-- إن ظهر: Duplicate column → الأعمدة مضافة (تجاهل).

ALTER TABLE YB_Store_coupon_usage DROP INDEX uq_code_license;

ALTER TABLE YB_Store_coupons
    ADD COLUMN max_uses_per_player INT NULL AFTER max_uses;

ALTER TABLE YB_Store_coupons
    ADD COLUMN created_by VARCHAR(100) NULL AFTER active;

ALTER TABLE YB_Store_coupons
    ADD COLUMN note VARCHAR(160) NULL AFTER created_by;
