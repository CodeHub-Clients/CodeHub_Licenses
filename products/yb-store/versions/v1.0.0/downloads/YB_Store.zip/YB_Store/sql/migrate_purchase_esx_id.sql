-- ربط المشتري بجدول users: يحفظ نفس `identifier` الظاهر في ESX (غالباً steam: أو char1:license2:)
-- مهم: `license:هكس` من FiveM لا يساوي `users.identifier` في كثير من السيرفرات.

ALTER TABLE YB_Store_purchases
    ADD COLUMN esx_identifier VARCHAR(100) NULL;
