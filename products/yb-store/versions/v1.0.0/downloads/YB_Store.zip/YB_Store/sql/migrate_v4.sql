-- v4: كوبونات خصم
CREATE TABLE IF NOT EXISTS YB_Store_coupons (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    code          VARCHAR(32) NOT NULL UNIQUE,
    percent_off   TINYINT UNSIGNED NOT NULL DEFAULT 10,
    max_uses      INT NULL,
    used_count    INT NOT NULL DEFAULT 0,
    expires_at    TIMESTAMP NULL,
    active        TINYINT(1) NOT NULL DEFAULT 1,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS YB_Store_coupon_usage (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    code_id     INT NOT NULL,
    license     VARCHAR(64) NOT NULL,
    tx_id       VARCHAR(120) NULL,
    used_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_code (code_id),
    INDEX idx_lic (license),
    UNIQUE KEY uq_code_license (code_id, license)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
