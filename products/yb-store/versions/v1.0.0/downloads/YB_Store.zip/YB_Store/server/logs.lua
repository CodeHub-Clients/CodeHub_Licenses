-- ═══════════════════════════════════════════════════════
--  YB Store — Webhooks & Logging
--  غيّر الروابط هنا فقط، باقي الملفات تستخدمها تلقائياً
-- ═══════════════════════════════════════════════════════

-- ┌─────────────────────────────────────────────────────┐
-- │                  روابط الويب هوك                    │
-- └─────────────────────────────────────────────────────┘

WEBHOOK_VEHICLES    = ''
WEBHOOK_CASES       = ''
WEBHOOK_OTHER       = ''
WEBHOOK_REDEEM      = ''
WEBHOOK_CODE_CREATE = ''

-- ┌─────────────────────────────────────────────────────┐
-- │             دالة مساعدة داخلية                      │
-- └─────────────────────────────────────────────────────┘

local function sendEmbed(webhook, username, embed)
    if not webhook or webhook == '' then return end
    PerformHttpRequest(webhook, function() end, 'POST', json.encode({
        username = username,
        embeds   = { embed },
    }), { ['Content-Type'] = 'application/json' })
end

local function timestamp()
    return {
        footer    = { text = 'YB Store • ' .. os.date('%Y-%m-%d %H:%M:%S') },
        timestamp = os.date('!%Y-%m-%dT%H:%M:%SZ'),
    }
end

-- ┌─────────────────────────────────────────────────────┐
-- │           لوق شراء منتج (مركبات / صناديق / أخرى)   │
-- └─────────────────────────────────────────────────────┘

function LogPurchase(product, productKey, price, newCoins, src, deliverSrc, extraPayload)
    local pType   = product.type or 'unknown'
    local webhook = WEBHOOK_OTHER
    local color   = 3447003
    local title   = '🛒 عملية شراء جديدة'

    if pType == 'vehicle' then
        webhook = WEBHOOK_VEHICLES
        color   = 3066993
        title   = '🚗 شراء مركبة'
    elseif pType == 'case' then
        webhook = WEBHOOK_CASES
        color   = 15844367
        title   = '📦 فتح صندوق'
    end

    local fields = FormatPlayerFields(GetPlayerFullInfo(src))

    table.insert(fields, { name = '─────────────', value = '**تفاصيل العملية**', inline = false })
    table.insert(fields, { name = '🏷️ المنتج',    value = (product.label or productKey), inline = true })
    table.insert(fields, { name = '📂 النوع',      value = pType,                         inline = true })
    table.insert(fields, { name = '💰 السعر',      value = tostring(price) .. ' عملة',    inline = true })
    table.insert(fields, { name = '💳 الرصيد بعد', value = tostring(newCoins) .. ' عملة', inline = true })

    if deliverSrc ~= src then
        table.insert(fields, { name = '─────────────', value = '**المُستلم (هدية)**', inline = false })
        for _, f in ipairs(FormatPlayerFields(GetPlayerFullInfo(deliverSrc))) do
            table.insert(fields, f)
        end
    end

    if pType == 'case' and extraPayload and extraPayload.caseReward then
        local r = extraPayload.caseReward
        table.insert(fields, { name = '─────────────', value = '**نتيجة الصندوق**', inline = false })
        table.insert(fields, { name = '🎰 الجائزة',    value = r.label or '???',             inline = true })
        table.insert(fields, { name = '📦 الصنف',       value = r.sort  or '?',              inline = true })
        if r.name then
            table.insert(fields, { name = '🔧 المعرّف', value = '`' .. r.name .. '`',        inline = true })
        end
    end

    local ts = timestamp()
    sendEmbed(webhook, 'YB Store — Purchase Log', {
        title     = title,
        color     = color,
        fields    = fields,
        footer    = ts.footer,
        timestamp = ts.timestamp,
    })
end

-- ┌─────────────────────────────────────────────────────┐
-- │              لوق استرداد كود                        │
-- └─────────────────────────────────────────────────────┘

function LogRedeem(src, code, rewardText, coinsAmount, newBalance)
    local fields = FormatPlayerFields(GetPlayerFullInfo(src))

    table.insert(fields, { name = '─────────────', value = '**تفاصيل الاسترداد**',                    inline = false })
    table.insert(fields, { name = '🎟️ الكود',     value = '`' .. code .. '`',                         inline = true  })
    table.insert(fields, { name = '🎁 المكافأة',   value = rewardText,                                 inline = true  })
    table.insert(fields, { name = '💰 القيمة',     value = tostring(coinsAmount or 0) .. ' عملة',      inline = true  })
    table.insert(fields, { name = '💳 الرصيد بعد', value = tostring(newBalance or '—') .. ' عملة',     inline = true  })

    local ts = timestamp()
    sendEmbed(WEBHOOK_REDEEM, 'YB Store — Redeem Log', {
        title     = '✅ تم استرداد كود',
        color     = 3066993,
        fields    = fields,
        footer    = ts.footer,
        timestamp = ts.timestamp,
    })
end

-- ┌─────────────────────────────────────────────────────┐
-- │       لوق إدارة كود (إنشاء فردي / حذف)              │
-- └─────────────────────────────────────────────────────┘

function LogCodeAdmin(title, color, fields)
    local ts = timestamp()
    sendEmbed(WEBHOOK_CODE_CREATE, 'YB Store — Code Admin', {
        title     = title,
        color     = color,
        fields    = fields,
        footer    = ts.footer,
        timestamp = ts.timestamp,
    })
end

-- ┌─────────────────────────────────────────────────────┐
-- │            لوق إنشاء أكواد (createrandomcode)       │
-- └─────────────────────────────────────────────────────┘

function LogCodeCreate(src, generatedCodes, coinsVal)
    local infoFields = {}
    if src ~= 0 then
        infoFields = FormatPlayerFields(GetPlayerFullInfo(src))
    else
        table.insert(infoFields, { name = '👤 المُنشئ', value = 'Console (Server)', inline = false })
    end

    table.insert(infoFields, { name = '─────────────',    value = '**تفاصيل العملية**',                             inline = false })
    table.insert(infoFields, { name = '📊 عدد الأكواد',   value = tostring(#generatedCodes),                          inline = true  })
    table.insert(infoFields, { name = '💰 قيمة كل كود',  value = tostring(coinsVal) .. ' عملة',                     inline = true  })
    table.insert(infoFields, { name = '💎 القيمة الكلية', value = tostring(#generatedCodes * coinsVal) .. ' عملة',   inline = true  })

    local ts = timestamp()
    sendEmbed(WEBHOOK_CODE_CREATE, 'YB Store — Code Generator', {
        title     = '📋 إنشاء أكواد جماعية',
        color     = 5814783,
        fields    = infoFields,
        footer    = ts.footer,
        timestamp = ts.timestamp,
    })

    -- إرسال الأكواد على دفعات (25 كود لكل embed)
    local BATCH = 25
    local totalBatches = math.ceil(#generatedCodes / BATCH)

    for b = 1, totalBatches do
        local startI = (b - 1) * BATCH + 1
        local endI   = math.min(b * BATCH, #generatedCodes)
        local lines  = {}
        for i = startI, endI do
            table.insert(lines, ('`%s`'):format(generatedCodes[i]))
        end

        local embedTitle = totalBatches > 1
            and ('📋 الأكواد — جزء %d/%d'):format(b, totalBatches)
            or  '📋 الأكواد المُنشأة'

        Wait(300)
        sendEmbed(WEBHOOK_CODE_CREATE, 'YB Store — Code Generator', {
            title       = embedTitle,
            description = table.concat(lines, '\n'),
            color       = 5814783,
            footer      = ts.footer,
            timestamp   = ts.timestamp,
        })
    end
end
