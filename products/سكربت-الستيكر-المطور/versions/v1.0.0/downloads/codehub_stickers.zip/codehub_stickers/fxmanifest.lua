fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'CodeHub'
description 'Forza-style vehicle vinyl editor with projected decals'
version '2.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    '@es_extended/imports.lua',
    'config.lua'
}

-- main.lua defines the Vinyl table both front-ends call into, so order matters.
-- Both editors load; each returns immediately unless Config.UI selects it.
client_scripts {
    'client/main.lua',
    'client/editor.lua',
    'client/editor_ox.lua',
    'client/locations.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua'
}

ui_page 'web/index.html'

files {
    'web/*.html',
    'web/css/*.css',
    'web/js/*.js',
    'web/fonts/*.woff2',
    -- Flag artwork for the designs CSS cannot draw. Both the editor page and the decal
    -- DUI load from here, so the glob has to cover subfolders.
    'web/img/**/*.png',
    -- Explicit as well as the recursive glob: some builds do not expand ** in files{}.
    'web/img/flags/*.png'
}

dependencies {
    'es_extended',
    'oxmysql',
    'ox_lib'
}
