'use strict';
const resource = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'zash_vinyl';
const app = document.getElementById('app');
const $ = id => document.getElementById(id);

let catalogue = [];
let categories = [];
let activeCategory = 'text';
let state = { layers: [], selected: 0, cap: 10, mirror: false, canUndo: false, canRedo: false };
let dirty = false;

// The panel derives soft/outline tints from the accent at runtime rather than
// hardcoding them, so changing Config.AccentColor restyles the whole UI.
function setAccent(hex) {
  const root = document.documentElement;
  root.style.setProperty('--accent', hex);
  const match = /^#?([\da-f]{2})([\da-f]{2})([\da-f]{2})$/i.exec(hex.trim());
  if (!match) return;
  const [r, g, b] = match.slice(1).map(v => parseInt(v, 16));
  root.style.setProperty('--accent-soft', `rgba(${r},${g},${b},.14)`);
  root.style.setProperty('--accent-line', `rgba(${r},${g},${b},.42)`);
}

// Inline SVG rather than an icon font: NUI's CSP blocks external stylesheets and
// fonts, and emoji render as whatever the client OS happens to have. Paths are stroked
// with currentColor so they inherit hover and active states for free.
const ICONS = {
  eye:     'M2 12s3.6-6.4 10-6.4S22 12 22 12s-3.6 6.4-10 6.4S2 12 2 12z|M12 9.4a2.6 2.6 0 100 5.2 2.6 2.6 0 000-5.2z',
  eyeOff:  'M4 4l16 16|M9.8 5.6A10.4 10.4 0 0112 5.4c6.4 0 10 6.6 10 6.6a17.5 17.5 0 01-3.5 4.2M6.6 7.9A16.8 16.8 0 002 12s3.6 6.4 10 6.4c1.3 0 2.4-.2 3.4-.5',
  lock:    'M6 11h12v9H6z|M8.6 11V7.8a3.4 3.4 0 016.8 0V11',
  unlock:  'M6 11h12v9H6z|M8.6 11V7.8a3.4 3.4 0 016.6-1.6',
  copy:    'M9.5 9.5h10v10h-10z|M4.5 14.5v-10h10',
  flip:    'M12 3v18|M9.5 7.5L5 12l4.5 4.5|M14.5 7.5L19 12l-4.5 4.5',
  trash:   'M4 7h16|M9.5 7V4h5v3|M6.5 7l1 13h9l1-13|M10 10.5v6M14 10.5v6',
  undo:    'M4.5 9.5h11a5 5 0 010 10H9|M4.5 9.5l4-4M4.5 9.5l4 4',
  redo:    'M19.5 9.5h-11a5 5 0 000 10H15|M19.5 9.5l-4-4M19.5 9.5l-4 4',
  mirror:  'M12 3v18|M3 8.5l5.5 3.5L3 15.5z|M21 8.5L15.5 12 21 15.5z',
  close:   'M6.5 6.5l11 11M17.5 6.5l-11 11',
  plus:    'M12 5v14M5 12h14'
};

function icon(name) {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('class', 'icon');
  (ICONS[name] || '').split('|').forEach(d => {
    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute('d', d);
    svg.appendChild(path);
  });
  return svg;
}

function iconButton(name, title, onClick, active) {
  const button = document.createElement('button');
  button.type = 'button';
  button.title = title;
  if (active) button.className = 'on';
  button.appendChild(icon(name));
  button.addEventListener('click', ev => { ev.stopPropagation(); onClick(); });
  return button;
}

function post(name, data = {}) {
  return fetch(`https://${resource}/${name}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data)
  }).catch(() => {});
}

// Favourites are pure UI preference with nowhere to live in the vinyl schema, so they
// stay in the browser's own storage rather than forcing a migration.
const store = {
  read(key, fallback) {
    try { return JSON.parse(localStorage.getItem('zash_vinyl_' + key)) || fallback; }
    catch (e) { return fallback; }
  },
  write(key, value) {
    try { localStorage.setItem('zash_vinyl_' + key, JSON.stringify(value)); } catch (e) {}
  }
};
let favourites = store.read('fav', []);

//---------------------------------------------------------------------------
// Catalogue
//---------------------------------------------------------------------------

function entryOf(id) { return catalogue.find(e => e.id === id); }

function makeTile(entry, mini) {
  const tile = document.createElement('button');
  tile.type = 'button';
  tile.className = 'tile';
  tile.title = entry.label;

  if (entry.image) {
    // Falls back to the label if the PNG is absent, so a missing asset reads as
    // "you have not added this file yet" instead of an unexplained empty square.
    const img = document.createElement('img');
    img.className = 'thumb-img';
    img.src = entry.image;
    img.alt = entry.label;
    img.addEventListener('error', () => {
      img.remove();
      const label = document.createElement('b');
      label.className = 'missing';
      label.textContent = entry.label;
      tile.appendChild(label);
    });
    tile.appendChild(img);
  } else if (entry.kind === 'shape') {
    const thumb = document.createElement('div');
    thumb.className = 'thumb t-' + entry.id;
    thumb.appendChild(document.createElement('i'));
    thumb.appendChild(document.createElement('b'));
    tile.appendChild(thumb);
  } else {
    const label = document.createElement('b');
    label.textContent = entry.preset || entry.label;
    tile.appendChild(label);
  }

  if (!mini) {
    const fav = document.createElement('span');
    fav.className = 'fav' + (favourites.includes(entry.id) ? ' on' : '');
    fav.textContent = '★';
    fav.addEventListener('click', ev => {
      ev.stopPropagation();
      favourites = favourites.includes(entry.id)
        ? favourites.filter(f => f !== entry.id)
        : favourites.concat(entry.id);
      store.write('fav', favourites);
      renderCatalogue();
    });
    tile.appendChild(fav);
  }

  tile.addEventListener('click', () => post('addLayer', { vinyl: entry.id }));
  return tile;
}

function renderRows() {
  const favRow = $('favouritesRow'), favGrid = $('favourites');
  favGrid.replaceChildren();
  favourites.map(entryOf).filter(Boolean).forEach(e => favGrid.appendChild(makeTile(e, true)));
  favRow.hidden = favGrid.childElementCount === 0;
}

function renderCatalogue() {
  const query = $('search').value.trim().toLowerCase();
  const grid = $('grid');
  grid.replaceChildren();
  catalogue
    .filter(e => (query ? true : e.category === activeCategory))
    .filter(e => !query || e.label.toLowerCase().includes(query) || e.id.includes(query))
    .forEach(e => grid.appendChild(makeTile(e, false)));
  renderRows();
}

// Built from Config.Fonts so the dropdown, the renderer and the server whitelist
// cannot drift apart. Each option previews in the face it selects.
let fonts = [];

function renderFonts(list) {
  fonts = Array.isArray(list) ? list : [];
  const select = $('fFont');
  select.replaceChildren();
  fonts.forEach(font => {
    const option = document.createElement('option');
    option.value = font.id;
    option.textContent = font.label || font.id;
    option.style.fontFamily = `"${font.family}", Cairo, sans-serif`;
    option.style.fontWeight = String(font.weight || 500);
    select.appendChild(option);
  });
}

function renderCategories() {
  const nav = $('categories');
  nav.replaceChildren();
  categories.forEach(cat => {
    const button = document.createElement('button');
    button.type = 'button';
    button.textContent = cat.label;
    button.className = cat.id === activeCategory ? 'on' : '';
    button.addEventListener('click', () => { activeCategory = cat.id; renderCategories(); renderCatalogue(); });
    nav.appendChild(button);
  });
}

//---------------------------------------------------------------------------
// Layers
//---------------------------------------------------------------------------

function renderLayers() {
  const list = $('layers');
  list.replaceChildren();
  $('layerCount').textContent = `${state.layers.length}/${state.cap}`;
  $('undo').disabled = !state.canUndo;
  $('redo').disabled = !state.canRedo;
  $('mirror').classList.toggle('on', state.mirror === true);

  // Top layer first, matching how the list reads.
  state.layers.slice().reverse().forEach(layer => {
    const li = document.createElement('li');
    li.className = layer.index === state.selected ? 'sel' : '';

    const act = a => post('layerAction', { action: a, index: layer.index });

    const name = document.createElement('span');
    name.className = 'name';
    name.dir = 'auto';
    name.textContent = layer.kind === 'text' ? (layer.text || layer.label) : layer.label;

    // Per-row actions. They used to sit in a shared strip under the list, which meant
    // acting on a layer took two steps - select it, then reach for the button.
    const tools = document.createElement('div');
    tools.className = 'row-tools';
    tools.append(
      iconButton(layer.hidden ? 'eyeOff' : 'eye', 'إظهار / إخفاء', () => act('hide'), !layer.hidden),
      iconButton(layer.locked ? 'lock' : 'unlock', 'قفل', () => act('lock'), layer.locked),
      iconButton('copy', 'تكرار', () => act('duplicate')),
      iconButton('flip', 'قلب', () => act('flip')),
      iconButton('trash', 'حذف', () => act('delete'))
    );
    tools.lastChild.classList.add('danger');

    li.append(name, tools);
    // No drag-to-reorder: decals have no z-order in GTA, so reordering the list could
    // never change what you see. Selection only.
    li.addEventListener('click', () => post('select', { index: layer.index }));
    list.appendChild(li);
  });
}

function current() { return state.layers.find(l => l.index === state.selected); }

// Every numeric property is scrolled, not typed. Each row shows its live value and
// becomes the wheel's target when clicked.
const TARGETS = [
  { id: 'size',     label: 'الحجم',      read: l => `${l.width.toFixed(2)} × ${l.height.toFixed(2)}` },
  { id: 'width',    label: 'العرض',      read: l => l.width.toFixed(2) },
  { id: 'height',   label: 'الارتفاع',   read: l => l.height.toFixed(2) },
  { id: 'rotation', label: 'الدوران',    read: l => Math.round(l.rotation || 0) + '°' },
  { id: 'opacity',  label: 'الشفافية',   read: l => l.opacity + '%' },
  { id: 'font',     label: 'حجم الخط',   read: l => l.size + 'px' },
  { id: 'depth',    label: 'العمق',      read: l => Number(l.depth || 0.02).toFixed(3) }
];

function renderTargets(layer) {
  const box = $('targets');
  box.replaceChildren();
  TARGETS.forEach(target => {
    if (target.id === 'font' && layer.kind !== 'text') return;
    const button = document.createElement('button');
    button.type = 'button';
    button.className = state.scrollTarget === target.id ? 'on' : '';
    const name = document.createElement('span');
    name.textContent = target.label;
    const value = document.createElement('i');
    value.textContent = target.read(layer);
    button.append(name, value);
    button.addEventListener('click', () => post('scrollTarget', { target: target.id }));
    box.appendChild(button);
  });
}

function renderProps() {
  const layer = current();
  $('props').hidden = !layer;
  if (!layer) return;
  $('textRow').hidden = layer.kind !== 'text';
  $('fText').value = layer.text || '';
  $('fColor').value = layer.color || '#ffffff';
  // A font id no longer in Config.Fonts (removed from the config, older saved layer)
  // would leave the select blank and then write that blank back on the next edit.
  // Fall back to the first configured font instead.
  const fontId = layer.font || (fonts[0] && fonts[0].id) || 'Cairo';
  $('fFont').value = fonts.some(f => f.id === fontId)
    ? fontId
    : ((fonts[0] && fonts[0].id) || 'Cairo');
  $('fOutline').checked = layer.outline === true;
  renderTargets(layer);
}

//---------------------------------------------------------------------------
// Field wiring - only the non-numeric fields remain
//---------------------------------------------------------------------------

const fieldMap = { fText: 'text', fColor: 'color', fFont: 'font', fOutline: 'outline' };
Object.keys(fieldMap).forEach(id => {
  const el = $(id);
  const event = (el.type === 'color' || el.type === 'checkbox') ? 'input' : 'change';
  el.addEventListener(event, () => {
    const value = el.type === 'checkbox' ? el.checked : el.value;
    post('setField', { field: fieldMap[id], value });
  });
});

// Header controls carry the same SVG set as the rows.
$('undo').appendChild(icon('undo'));
$('redo').appendChild(icon('redo'));
$('mirror').appendChild(icon('mirror'));
$('close').appendChild(icon('close'));
$('undo').addEventListener('click', () => post('history', { action: 'undo' }));
$('redo').addEventListener('click', () => post('history', { action: 'redo' }));
$('mirror').addEventListener('click', () => post('layerAction', { action: 'mirror' }));
$('search').addEventListener('input', renderCatalogue);

// window.confirm() paints a native OS dialog over the game and steals focus from NUI,
// so the prompt is an in-page modal instead.
let pendingConfirm = null;

function askConfirm(text, onYes) {
  $('modalText').textContent = text;
  pendingConfirm = onYes;
  $('modal').hidden = false;
}

function closeConfirm(accepted) {
  $('modal').hidden = true;
  const action = pendingConfirm;
  pendingConfirm = null;
  if (accepted && action) action();
}

$('modalYes').addEventListener('click', () => closeConfirm(true));
$('modalNo').addEventListener('click', () => closeConfirm(false));

function requestClose(save) {
  if (!save && dirty) {
    askConfirm('لديك تعديلات غير محفوظة. الخروج بدون حفظ؟', () => post('close', { save: false }));
    return;
  }
  post('close', { save });
}
$('save').addEventListener('click', () => requestClose(true));
$('discard').addEventListener('click', () => requestClose(false));
$('close').addEventListener('click', () => requestClose(false));

//---------------------------------------------------------------------------
// Scene input
//
// Only press/release cross into Lua. The drag itself is tracked there by reading the
// cursor each frame, so moving the mouse costs no NUI traffic.
//---------------------------------------------------------------------------

const scene = $('scene');
let overUI = false;

scene.addEventListener('mousedown', ev => {
  ev.preventDefault();
  post('grab', { button: ev.button, shift: ev.shiftKey });
});
window.addEventListener('mouseup', () => post('release'));
scene.addEventListener('contextmenu', ev => ev.preventDefault());

// Bind only to the top-level rails and bar. mouseenter/mouseleave do not fire when
// moving between descendants, so nesting the shots and hints inside the bar is safe -
// binding the children too would report "left the UI" on every internal move.
document.querySelectorAll('.panel, #modal').forEach(panel => {
  panel.addEventListener('mouseenter', () => { overUI = true; post('hover', { over: true }); });
  panel.addEventListener('mouseleave', () => { overUI = false; post('hover', { over: false }); });
});

// Wheel comes from the page, not a polled control: with NUI focus the page reliably
// receives it and the game may not, and an event only costs anything when it fires.
window.addEventListener('wheel', ev => {
  if (typing()) return;
  post('scroll', {
    dir: ev.deltaY < 0 ? 1 : -1,
    shift: ev.shiftKey, ctrl: ev.ctrlKey,
    overUI, zoom: !current()
  });
}, { passive: true });

//---------------------------------------------------------------------------
// Keyboard
//---------------------------------------------------------------------------

function typing() {
  const el = document.activeElement;
  return el && (el.tagName === 'INPUT' || el.tagName === 'SELECT' || el.tagName === 'TEXTAREA');
}

const arrows = { ArrowUp: [0, 1], ArrowDown: [0, -1], ArrowLeft: [-1, 0], ArrowRight: [1, 0] };

let snapHeld = false;
function setSnap(held) {
  if (held === snapHeld) return;   // keydown repeats; only tell Lua on a change
  snapHeld = held;
  post('snap', { held });
}

window.addEventListener('keydown', ev => {
  if (ev.altKey) setSnap(true);

  if (typing()) {
    if (ev.key === 'Escape') document.activeElement.blur();
    return;
  }

  // While the modal is up, Escape dismisses it rather than re-asking.
  if (ev.key === 'Escape') {
    if (pendingConfirm) closeConfirm(false); else requestClose(false);
    return;
  }
  if (ev.ctrlKey && ev.key.toLowerCase() === 'z') { ev.preventDefault(); post('history', { action: 'undo' }); return; }
  if (ev.ctrlKey && ev.key.toLowerCase() === 'y') { ev.preventDefault(); post('history', { action: 'redo' }); return; }
  if (ev.key === 'Delete') { post('layerAction', { action: 'delete' }); return; }

  if (arrows[ev.key]) {
    ev.preventDefault();
    const [dx, dy] = arrows[ev.key];
    post('nudge', { dx, dy, coarse: ev.shiftKey });
    return;
  }

  const digit = Number(ev.key);
  if (digit >= 1 && digit <= 9) {
    const shot = (window.__shots || [])[digit - 1];
    if (shot) post('camShot', { key: shot.key });
  }
});

window.addEventListener('keyup', ev => { if (!ev.altKey) setSnap(false); });
window.addEventListener('blur', () => setSnap(false));

//---------------------------------------------------------------------------
// Messages from Lua
//---------------------------------------------------------------------------

function renderShots(shots) {
  window.__shots = shots || [];
  const bar = $('shots');
  bar.replaceChildren();
  window.__shots.forEach((shot, i) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.textContent = shot.label;
    const key = document.createElement('i');
    key.textContent = i + 1;
    button.appendChild(key);
    button.addEventListener('click', () => post('camShot', { key: shot.key }));
    bar.appendChild(button);
  });
}

window.addEventListener('message', event => {
  const message = event.data || {};

  if (message.action === 'open') {
    setAccent(message.accent || '#c9ced6');
    catalogue = Array.isArray(message.catalogue) ? message.catalogue : [];
    categories = Array.isArray(message.categories) ? message.categories : [];
    activeCategory = categories.length ? categories[0].id : 'text';
    $('plate').textContent = message.plate || '—';
    $('fText').maxLength = message.maxLength || 48;
    renderFonts(message.fonts);
    dirty = false;
    renderCategories();
    renderCatalogue();
    renderShots(message.shots);
    app.hidden = false;
  } else if (message.action === 'close') {
    app.hidden = true;
    dirty = false;
  } else if (message.action === 'state') {
    // An empty Lua table arrives as {} rather than [], so never assume an array.
    state = {
      layers: Array.isArray(message.layers) ? message.layers : [],
      selected: message.selected || 0,
      scrollTarget: message.scrollTarget || 'size',
      cap: message.cap || 10,
      mirror: message.mirror === true,
      canUndo: message.canUndo === true,
      canRedo: message.canRedo === true
    };
    dirty = message.dirty === true;
    // While a save is in flight the editor stays open; lock the actions so the player
    // cannot fire a second save into the cooldown and get it rejected.
    const saving = message.saving === true;
    $('save').disabled = saving;
    $('discard').disabled = saving;
    $('save').textContent = saving ? 'جارٍ الحفظ...' : 'حفظ التصميم';
    renderLayers();
    renderProps();
  }
});
