'use strict';
const vinyl = document.getElementById('vinyl');
const shape = document.getElementById('shape');

let isText = true;

// No aspect compensation. It used to apply scaleY(W/H / 4), but the H in that term
// cancels the H of the decal box: world text height came out proportional to width
// alone, so the height control changed an invisible rectangle and nothing else.
// The texture now simply fills the box, which makes width and height both do what
// their labels say. Config.Defaults.height is set to width/4 to match the canvas so
// the starting shape is still undistorted, and uniform 'size' keeps it that way.
function fit() {
  if (!isText) {
    shape.style.transform = '';
    return;
  }
  vinyl.style.transform = '';
  const available = document.body.clientWidth;
  // getBoundingClientRect is fractional; scrollWidth rounds down, which leaves the
  // trailing glyph a sub-pixel over the edge and clipped by the body's overflow.
  const width = vinyl.getBoundingClientRect().width;
  if (width > 0 && width > available) {
    vinyl.style.transform = `scale(${(available / width) * 0.98})`;
  }
}

function apply(data) {
  const id = String(data.vinyl || 'text');
  const color = data.color || '#ffffff';
  const outline = data.outline === true;

  // Numbers are catalogue entries of kind 'text' carrying a preset string, so the
  // only real distinction here is whether there is text to draw.
  isText = typeof data.text === 'string' && data.text.length > 0;

  vinyl.classList.toggle('hidden', !isText);
  shape.classList.toggle('hidden', isText);

  if (isText) {
    vinyl.textContent = data.text;
    vinyl.style.color = color;
    // Opacity is applied by AddDecal, not baked in - doing both compounds.
    vinyl.style.fontSize = Math.max(18, Math.min(80, Number(data.size) || 42)) + 'px';
    // Family and weight both arrive resolved from Config.Fonts. This used to be a
    // ternary on the id that only ever changed the weight, so the two entries in
    // Config.Fonts were one typeface in regular and bold.
    vinyl.style.fontFamily =
      (data.fontFamily || 'Cairo') + ", Tahoma, 'Segoe UI', Arial, sans-serif";
    vinyl.style.fontWeight = String(data.fontWeight || 500);
    vinyl.classList.toggle('outline', outline);
  } else {
    // Three persistent children: the field, an emblem overlay for flags needing a
    // star or crest, and an image for the ones CSS cannot draw honestly.
    if (!shape.firstChild) {
      shape.appendChild(document.createElement('i'));
      shape.appendChild(document.createElement('b'));
      shape.appendChild(document.createElement('img'));
    }
    const img = shape.querySelector('img');
    const src = typeof data.image === 'string' ? data.image : '';

    shape.className = 's-' + id.replace(/[^a-z0-9]/gi, '') + (src ? ' img' : '');
    shape.classList.toggle('outline', outline);
    shape.style.color = color;
    if (src) {
      if (img.getAttribute('src') !== src) {
        // If the PNG has not been added yet, drop back to the CSS field rather than
        // rendering an empty decal.
        img.onerror = () => shape.classList.remove('img');
        img.setAttribute('src', src);
      }
    } else {
      img.removeAttribute('src');
    }
  }
  fit();
}

window.addEventListener('message', event => {
  const message = event.data || {};
  if (message.action !== 'vinyl') return;
  // The image path lives on the catalogue entry, not the saved layer, so Lua resolves
  // it and sends it alongside.
  const data = message.data || {};
  if (message.image) data.image = message.image;
  // Font family/weight are resolved Lua-side and ride alongside the layer, not inside
  // it, so they have to be folded in the same way the image path is.
  if (message.fontFamily) data.fontFamily = message.fontFamily;
  if (message.fontWeight) data.fontWeight = message.fontWeight;
  apply(data);

  // With one bundled font, waiting on document.fonts.ready once was enough. With
  // several, a family can still be unloaded when its first layer is drawn: the swap
  // then changes the glyph metrics after fit() has already measured, leaving the text
  // over- or under-scaled until something else forces a repaint. Re-fit once the
  // specific face resolves.
  if (data.fontFamily && document.fonts && document.fonts.load) {
    const face = `${data.fontWeight || 500} 42px "${data.fontFamily}"`;
    document.fonts.load(face, data.text || 'ا').then(fit).catch(() => {});
  }
});

// Metrics measured before the webfont resolves are wrong, so re-fit afterwards.
if (document.fonts && document.fonts.ready) document.fonts.ready.then(fit);
