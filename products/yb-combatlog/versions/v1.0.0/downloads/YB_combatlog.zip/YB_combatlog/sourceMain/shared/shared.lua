return {
    AllowedJobs = { police=true, agent=true, sheriff=true, admin = true },
    AllowJobGradeForJail = {police = 7, agent = 7, sheriff = 7, admin = 2},
    AllowJobGradeForConfiscate = {police = 7, agent = 7, sheriff = 7, admin = 2},

    cacheGhostTime = 5, -- وقت إنتهاء الكاش الخاص بالفصل بالدقائق
    canActionAt= 3, -- الوقت الي يقدر فيه يتفاعل بالسجن والكاش بالدقائق
}