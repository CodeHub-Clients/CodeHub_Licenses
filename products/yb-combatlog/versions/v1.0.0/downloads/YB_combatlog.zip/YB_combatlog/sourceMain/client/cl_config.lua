return {
    AlertZoneSettings = {
        enabled = true,
        inAnyZone = true,
        AlertZones = {

            -- مثال:
            -- { label = 'مقر الشرطة - لوس سانتوس', coords = vector3(441.2, -981.9, 30.7), radius = 80.0 },
            -- { label = 'السيناريو - البنك المركزي', coords = vector3(250.0, 225.0, 101.9), radius = 120.0 },
        }
    }
}