return {
    ReasonList = {
        ['game crashed'] = 'Head Popped',
        ['timed out'] = 'Head Popped',
        ['exiting'] = 'F8 Quit',
        ['you were kicked for being afk'] = 'Kicked for AFK',
        ['banned'] = 'Banned. Ggs. Get shit on.',
        ['exploit'] = 'Exploiting',
        ['kicked'] = 'Kicked',
    },

    Logs = {
        JoinWebhook             = 'https://discord.com/api/webhooks/1308841105625841778/zYECCf7tpxzP9xvuDa8STRZ9f8pexe_FLUyCWPbEnGUdTFiT2N06G8HfxjWXIv3IfzzJ',
        DisconnectWebhook       = 'https://discord.com/api/webhooks/1309230894632144947/71q_xVGguzpbprTKypJPfY_CSwMeYsSB6zq2_37RQqKEPwRBNV2qCD5uiyjgN9ZajkJ1',
        jailOffline             = 'https://discord.com/api/webhooks/1458698260683165858/2xEeRB8x98G3Y7KQhGlJvifRTBUz463vsjq-Z6iuJNc6-BgDV-CN6XZwa72DVfPwj-xm',
        confiscateBlackMoney    = 'https://discord.com/api/webhooks/1458698453696778290/23NxEsbCHQ_GRwd3pV10_qR9mKn5o2vmXdG9vjQpM1FtgPAnnCDm7HGmQJpC6Fu9I-wy',
    },

    LogsSettings = {
        icon_url    = "",
        thumbnail   = "",
        avatar_url  = "",
    },

    JobDiscordAllowed = {
        ["police"]  = 1305901031615500339,
        ["agent"]   = 1305901110544044133,
        ["sheriff"] = 1405986640073068544,
        ["admin"]   = 1305900962992492645,
    },

    antiCheatSettings = {
        enabled         = true,
        antiCheatType   = "fiveguard",
        antiCheatName   = "D7ME",
        antiCheatReason = "مغفل يحاول يسجن لاعب وهو ما معه صلاحية او رتبة بالديسكورد",
    },

    jailSettings = {
        enabled     = true,
        jailReason  = "فصل اثناء سيناريو",
        jailTime    = 60,
        chatSettings = {
            enabled      = true,
            chatMessages = {
                ["admin"]   = {color = {255, 0  ,   0}, label = " ⭐ الرقابة و التفتيش " },
                ["police"]  = {color = {17,  69 , 191}, label = " إدارة الشرطة 👮 | " },
                ["agent"]   = {color = {78,  198,  78}, label = " حرس الحدود  💂 | " },
                ["sheriff"] = {color = {153,76,0}, label = " الأمن البيئي  🕵️‍♂️ | " },
            }
        },
        queryData = { sqlQuery = "UPDATE users SET jail = @newJailTime, jail_reason = @reason, jailed_by = @jailedBy WHERE identifier = @identifier", }
    },

    confiscateSettings = {
        enabled = true,
        commissionPercent = 100,
        moneyType = "black_money"
    }

}