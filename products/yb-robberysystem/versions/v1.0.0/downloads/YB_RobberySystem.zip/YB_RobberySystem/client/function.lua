RegisterNetEvent('YB_RobberySystem:client:PoliceAlertBlip')
AddEventHandler('YB_RobberySystem:client:PoliceAlertBlip', function(coords)
    -- blip for the cops
    AlertAtm = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(AlertAtm, Config.Blips[1]['sprite'])
    SetBlipScale(AlertAtm, Config.Blips[1]['size'])
    SetBlipColour(AlertAtm, Config.Blips[1]['colour'])
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(Config.Blips[1]['label'])
    EndTextCommandSetBlipName(AlertAtm)

    Citizen.Wait(1000*60*Config.BlipTime)
    RemoveBlip(AlertAtm)
end)




function YB_ShowNotification(message)
    ESX.ShowNotification(message)
end