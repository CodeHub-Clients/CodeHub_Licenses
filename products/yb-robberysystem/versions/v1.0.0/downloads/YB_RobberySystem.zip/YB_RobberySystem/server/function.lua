ESX = exports.es_extended:getSharedObject()

function onRobberyStarted(player, marker, onlinePolice, onlineCriminals)
    -- player - معرف اللاعب الذي بدأ السرقة
    -- marker - معرف العلامة التي تم بدء السرقة عندها       
    -- onlinePolice - عدد الشرطة المتواجدين
    -- onlineCriminals - عدد المجرمين المتواجدين    

    local robbery = Config.RobberyPostion[marker]
    local coords = vector3(
        robbery.Markers[1].x,
        robbery.Markers[1].y,
        robbery.Markers[1].z
    )

    -- إرسال إشعار وخريطة للشرطة
    for _, id in ipairs(GetPlayers()) do
        local xPlayer = ESX.GetPlayerFromId(tonumber(id))
        if xPlayer and Config.Leojobs[xPlayer.job.name] then
            TriggerClientEvent('esx:showNotification', id, "<font color='#00bfff'>بلاغ من النظام</font><br>هناك سرقة جارية في " .. robbery.RobberyName)
            TriggerClientEvent("YB_RobberySystem:client:PoliceAlertBlip", id, coords)
        end
    end
    
end



function YB_ShowNotification(source, message)
    TriggerClientEvent('esx:showNotification', source, message)
end

function YB_BanPlayer(source, reason)
    -- Ban player with a reason
    print(string.format("Banning player %d for reason: %s", source, reason))
    -- Call the anti-cheat script's ban function
    -- if Config.fiveguard["enabled"] then
    --     exports[Config.fiveguard["name"]]:fg_BanPlayer(source, reason, true)
    -- else
    --     DropPlayer(source, reason)
    -- end
end