Locales['en'] = {
    ['starthacking'] = "🔐 Starting the hacking process...",
    ['hackfailed'] = "❌ Hacking failed!",
    ['cannotstartrobbery'] = "🚨 You cannot start the robbery now.",
    ['robberystarted'] = "🚨 Robbery started at: %s",
    ['robberyneedcops'] = "🚓 You need at least %d police officers to start this robbery.",
    ['robberyneedcriminals'] = "🧨 You need at least %d criminals nearby.",
    ['robberyrecentlystolen'] = "⌛ This location was recently robbed. Please wait: %s",
    ['robberyneeditem'] = "❌ You do not have the required item: %s",
}