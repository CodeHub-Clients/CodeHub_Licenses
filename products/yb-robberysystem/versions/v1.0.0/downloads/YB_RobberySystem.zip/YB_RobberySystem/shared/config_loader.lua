Config = Config or {}
ConfigRaw = ConfigRaw or {}

local RESOURCE = GetCurrentResourceName()
local CONFIG_PATH = 'config.json'

local function vec3FromTable(t)
    if not t then return nil end
    return vector3(tonumber(t.x) or 0, tonumber(t.y) or 0, tonumber(t.z) or 0)
end

local function applyParsedConfig(data)
    if not data then return false end
    ConfigRaw = data
    local g = data.global or {}

    Config.ScriptlevelName = g.ScriptlevelName or 'YB_Level'
    Config.useLevel = g.useLevel ~= false
    Config.antiLeojobRob = g.antiLeojobRob ~= false
    Config.fiveguard = g.fiveguard or { enabled = false, name = 'D7ME' }
    Config.Debug = g.Debug == true
    Config.Locale = g.Locale or 'ar'
    Config.Leojobs = g.Leojobs or {}
    Config.BlipTime = tonumber(g.BlipTime) or 2
    Config.Blips = g.Blips or {}
    Config.antiRob = g.antiRob ~= false
    Config.antiRobCallbacks = g.antiRobCallbacks or 'esx_misc:getPromotionstatus'
    Config.antiRobWaterMark = g.antiRobWaterMark or 'stopRob'
    Config.antiRobTime = tonumber(g.antiRobTime) or 30
    Config.robWaiting = tonumber(g.robWaiting) or 5
    Config.ui = g.ui or {
        startMarkerType = 1,
        startMarkerZOffset = -0.75,
        startMarkerScale = 1.35,
        placementMarkerZOffset = -0.55,
        lootMarkerType = 20,
        lootMarkerZOffset = -0.02,
        lootMarkerScale = 0.65,
    }
    Config.adminPanel = data.adminPanel or { command = 'robberyadmin', allowedGroups = { 'admin' } }
    Config.minigameTypes = data.minigameTypes or {}

    Config.markers = {}
    for _, m in ipairs(data.markers or {}) do
        local coords = vec3FromTable(m.coords)
        if coords then
            table.insert(Config.markers, {
                TheftName = m.TheftName,
                enabled = m.enabled ~= false,
                coords = coords,
                blipID = tonumber(m.blipID) or 1,
                blipColor = tonumber(m.blipColor) or 1,
                blipLabel = m.blipLabel or m.TheftName,
            })
        end
    end

    Config.RobberyPostion = {}
    for name, rob in pairs(data.robberies or {}) do
        local markers = {}
        for _, c in ipairs(rob.Markers or {}) do
            table.insert(markers, vec3FromTable(c) or vector3(0, 0, 0))
        end

        local needItem = rob.needItemToRob
        local requireDrunk = rob.requireDrunk
        -- ترحيل القديم: beer = سكر فقط (بدون آيتم)
        if requireDrunk == nil then
            if needItem == 'beer' then
                requireDrunk = true
                needItem = ''
            else
                requireDrunk = false
            end
        elseif needItem == 'beer' and requireDrunk then
            needItem = ''
        end
        local drunkPercent = tonumber(rob.drunkPercent) or 25
        local drunkMinValue = tonumber(rob.drunkMinValue) or math.floor(drunkPercent * 500)

        Config.RobberyPostion[name] = {
            enabled = rob.enabled ~= false,
            minigame = rob.minigame or 'utk',
            minigameParams = rob.minigameParams or {},
            needItemToRob = needItem,
            requireDrunk = requireDrunk == true,
            drunkPercent = drunkPercent,
            drunkMinValue = drunkMinValue,
            level = tonumber(rob.level) or 0,
            Police = tonumber(rob.Police) or 0,
            Criminal = tonumber(rob.Criminal) or 0,
            rewards = rob.rewards or {},
            TimeToNewRobbery = tonumber(rob.TimeToNewRobbery) or 7200,
            RobberyName = rob.RobberyName or name,
            Markers = markers,
        }
    end

    return true
end

function LoadConfigFromJson()
    local raw = LoadResourceFile(RESOURCE, CONFIG_PATH)
    if not raw or raw == '' then
        print(('^1[%s] config.json not found or empty^0'):format(RESOURCE))
        return false
    end

    local ok, data = pcall(json.decode, raw)
    if not ok or not data then
        print(('^1[%s] Failed to parse config.json^0'):format(RESOURCE))
        return false
    end

    return applyParsedConfig(data)
end

--- يحوّل Config الحالي إلى JSON (للحفظ من لوحة الإدارة)
function ConfigToJsonTable()
    local out = {
        global = {
            ScriptlevelName = Config.ScriptlevelName,
            useLevel = Config.useLevel,
            antiLeojobRob = Config.antiLeojobRob,
            fiveguard = Config.fiveguard,
            Debug = Config.Debug,
            Locale = Config.Locale,
            Leojobs = Config.Leojobs,
            BlipTime = Config.BlipTime,
            Blips = Config.Blips,
            antiRob = Config.antiRob,
            antiRobCallbacks = Config.antiRobCallbacks,
            antiRobWaterMark = Config.antiRobWaterMark,
            antiRobTime = Config.antiRobTime,
            robWaiting = Config.robWaiting,
            ui = Config.ui,
        },
        adminPanel = Config.adminPanel or ConfigRaw.adminPanel,
        markers = {},
        robberies = {},
        minigameTypes = Config.minigameTypes or ConfigRaw.minigameTypes or {},
    }

    for _, m in ipairs(Config.markers or {}) do
        table.insert(out.markers, {
            TheftName = m.TheftName,
            enabled = m.enabled ~= false,
            coords = { x = m.coords.x, y = m.coords.y, z = m.coords.z },
            blipID = m.blipID,
            blipColor = m.blipColor,
            blipLabel = m.blipLabel,
        })
    end

    for name, rob in pairs(Config.RobberyPostion or {}) do
        local markers = {}
        for _, c in ipairs(rob.Markers or {}) do
            local x, y, z = c.x, c.y, c.z
            if type(c) == 'vector3' or (c.x and c.y and c.z) then
                table.insert(markers, { x = x, y = y, z = z })
            end
        end
        out.robberies[name] = {
            enabled = rob.enabled ~= false,
            minigame = rob.minigame,
            minigameParams = rob.minigameParams or {},
            needItemToRob = rob.needItemToRob,
            requireDrunk = rob.requireDrunk == true,
            drunkPercent = rob.drunkPercent or 25,
            drunkMinValue = rob.drunkMinValue or 12500,
            level = rob.level,
            Police = rob.Police,
            Criminal = rob.Criminal,
            rewards = rob.rewards or {},
            TimeToNewRobbery = rob.TimeToNewRobbery,
            RobberyName = rob.RobberyName,
            Markers = markers,
        }
    end

    return out
end

--- تطبيق إعدادات من JSON (من السيرفر أو NUI)
function ApplyConfigTable(data)
    return applyParsedConfig(data)
end

function IsRobberyEnabled(robberyName)
    local rob = Config.RobberyPostion and Config.RobberyPostion[robberyName]
    if rob and rob.enabled == false then return false end
    for _, m in ipairs(Config.markers or {}) do
        if m.TheftName == robberyName then
            return m.enabled ~= false
        end
    end
    return rob ~= nil
end

function GetConfigForNui()
    return ConfigToJsonTable()
end

LoadConfigFromJson()
