CREATE TABLE IF NOT EXISTS `items` (
  `name` varchar(50) NOT NULL,
  `label` varchar(50) NOT NULL,
  `weight` int(11) NOT NULL DEFAULT 1,
  `rare` tinyint(4) NOT NULL DEFAULT 0,
  `can_remove` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT IGNORE INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES
('clothes_r', 'ملابس مسروقة', 2, 0, 1),
('weapon_r', 'اسلحة مسروقة', 2, 0, 1),
('doagn_r', 'دواجن مسروقة', 1, 0, 1),
('scrap_p', 'قطع سيارات مسروقة', 2, 0, 1);

