fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'YBv10'
description 'this script is a creator a robbery system for FiveM'
version '1.4.0'

shared_scripts {
    '@es_extended/imports.lua',
    '@es_extended/locale.lua',
    'locales/*.lua',
    'shared/config_loader.lua',
}

client_scripts {
    'client/hud.lua',
    'client/main.lua',
    'client/function.lua',
    'client/admin.lua',
    'client/admin_placement.lua',
}

server_scripts {
    'webhooks.lua',
    'server/anticrime.lua',
    'server/main.lua',
    'server/function.lua',
    'server/admin.lua',
}

ui_page 'web/admin/dist/index.html'

files {
    'config.json',
    'web/admin/dist/index.html',
    'web/admin/dist/**/*',
}

escrow_ignore {
    'config.json',
    'config.lua',
    'shared/config_loader.lua',
    'webhooks.lua',
    'server/function.lua',
    'client/function.lua',
    'locales/*.lua',
    'web/admin/**/*',
    '[SQL]',
}

dependency '/assetpacks'
