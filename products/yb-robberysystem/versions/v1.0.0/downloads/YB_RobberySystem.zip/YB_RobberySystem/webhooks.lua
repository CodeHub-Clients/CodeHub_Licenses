Config_S = {}
Config_S.webhooks_R = "" -- لوج السرقات

