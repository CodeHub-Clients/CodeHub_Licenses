-- في حال مش موجودة عندك بـ esx_misc
-- server side
-- ضيف الكود هذا فقط
ESX.RegisterServerCallback('esx_misc:getPromotionstatus', function(source, cb, name)
    print(json.encode(NoCrimetime_Data[name]))
    if NoCrimetime_Data[name].state then
        cb(true)
    else
        cb(false)
    end
end)